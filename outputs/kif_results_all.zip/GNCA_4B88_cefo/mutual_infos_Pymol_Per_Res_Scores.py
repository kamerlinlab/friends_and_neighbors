# You can run me in several ways, perhaps the easiest way is to:
# 1. Load the PDB file of your system in PyMOL.
# 2. Type: @[FILE_NAME.py] in the command line.
# 3. Make sure the .py file is in the same directory as the pdb.
set sphere_color, red
# The lines below are suggestions for potentially nicer figures.
# You can comment them in if you want.
# bg_color white
# set cartoon_color, grey90
# set ray_opaque_background, 0
# set antialias, 2
# set ray_shadows, 0
show spheres, resi 188 and name CA
set sphere_scale, 1.0000, resi 188 and name CA
show spheres, resi 104 and name CA
set sphere_scale, 0.9876, resi 104 and name CA
show spheres, resi 206 and name CA
set sphere_scale, 0.8965, resi 206 and name CA
show spheres, resi 45 and name CA
set sphere_scale, 0.8346, resi 45 and name CA
show spheres, resi 192 and name CA
set sphere_scale, 0.6747, resi 192 and name CA
show spheres, resi 102 and name CA
set sphere_scale, 0.5773, resi 102 and name CA
show spheres, resi 232 and name CA
set sphere_scale, 0.5527, resi 232 and name CA
show spheres, resi 186 and name CA
set sphere_scale, 0.4895, resi 186 and name CA
show spheres, resi 217 and name CA
set sphere_scale, 0.4843, resi 217 and name CA
show spheres, resi 207 and name CA
set sphere_scale, 0.4821, resi 207 and name CA
show spheres, resi 138 and name CA
set sphere_scale, 0.4386, resi 138 and name CA
show spheres, resi 44 and name CA
set sphere_scale, 0.4215, resi 44 and name CA
show spheres, resi 215 and name CA
set sphere_scale, 0.4176, resi 215 and name CA
show spheres, resi 20 and name CA
set sphere_scale, 0.3869, resi 20 and name CA
show spheres, resi 214 and name CA
set sphere_scale, 0.3468, resi 214 and name CA
show spheres, resi 162 and name CA
set sphere_scale, 0.3450, resi 162 and name CA
show spheres, resi 193 and name CA
set sphere_scale, 0.3330, resi 193 and name CA
show spheres, resi 46 and name CA
set sphere_scale, 0.3314, resi 46 and name CA
show spheres, resi 205 and name CA
set sphere_scale, 0.3267, resi 205 and name CA
show spheres, resi 101 and name CA
set sphere_scale, 0.3228, resi 101 and name CA
show spheres, resi 245 and name CA
set sphere_scale, 0.3227, resi 245 and name CA
show spheres, resi 246 and name CA
set sphere_scale, 0.3203, resi 246 and name CA
show spheres, resi 209 and name CA
set sphere_scale, 0.3182, resi 209 and name CA
show spheres, resi 260 and name CA
set sphere_scale, 0.3168, resi 260 and name CA
show spheres, resi 125 and name CA
set sphere_scale, 0.3119, resi 125 and name CA
show spheres, resi 194 and name CA
set sphere_scale, 0.3086, resi 194 and name CA
show spheres, resi 220 and name CA
set sphere_scale, 0.3074, resi 220 and name CA
show spheres, resi 129 and name CA
set sphere_scale, 0.2946, resi 129 and name CA
show spheres, resi 78 and name CA
set sphere_scale, 0.2898, resi 78 and name CA
show spheres, resi 216 and name CA
set sphere_scale, 0.2844, resi 216 and name CA
show spheres, resi 179 and name CA
set sphere_scale, 0.2839, resi 179 and name CA
show spheres, resi 100 and name CA
set sphere_scale, 0.2661, resi 100 and name CA
show spheres, resi 155 and name CA
set sphere_scale, 0.2645, resi 155 and name CA
show spheres, resi 76 and name CA
set sphere_scale, 0.2611, resi 76 and name CA
show spheres, resi 256 and name CA
set sphere_scale, 0.2609, resi 256 and name CA
show spheres, resi 134 and name CA
set sphere_scale, 0.2588, resi 134 and name CA
show spheres, resi 143 and name CA
set sphere_scale, 0.2538, resi 143 and name CA
show spheres, resi 98 and name CA
set sphere_scale, 0.2533, resi 98 and name CA
show spheres, resi 228 and name CA
set sphere_scale, 0.2525, resi 228 and name CA
show spheres, resi 208 and name CA
set sphere_scale, 0.2510, resi 208 and name CA
show spheres, resi 176 and name CA
set sphere_scale, 0.2414, resi 176 and name CA
show spheres, resi 120 and name CA
set sphere_scale, 0.2341, resi 120 and name CA
show spheres, resi 142 and name CA
set sphere_scale, 0.2331, resi 142 and name CA
show spheres, resi 108 and name CA
set sphere_scale, 0.2328, resi 108 and name CA
show spheres, resi 141 and name CA
set sphere_scale, 0.2309, resi 141 and name CA
show spheres, resi 166 and name CA
set sphere_scale, 0.2295, resi 166 and name CA
show spheres, resi 233 and name CA
set sphere_scale, 0.2295, resi 233 and name CA
show spheres, resi 99 and name CA
set sphere_scale, 0.2288, resi 99 and name CA
show spheres, resi 103 and name CA
set sphere_scale, 0.2288, resi 103 and name CA
show spheres, resi 218 and name CA
set sphere_scale, 0.2286, resi 218 and name CA
show spheres, resi 77 and name CA
set sphere_scale, 0.2222, resi 77 and name CA
show spheres, resi 2 and name CA
set sphere_scale, 0.2218, resi 2 and name CA
show spheres, resi 53 and name CA
set sphere_scale, 0.2171, resi 53 and name CA
show spheres, resi 230 and name CA
set sphere_scale, 0.2165, resi 230 and name CA
show spheres, resi 105 and name CA
set sphere_scale, 0.2164, resi 105 and name CA
show spheres, resi 159 and name CA
set sphere_scale, 0.2133, resi 159 and name CA
show spheres, resi 9 and name CA
set sphere_scale, 0.2128, resi 9 and name CA
show spheres, resi 231 and name CA
set sphere_scale, 0.2110, resi 231 and name CA
show spheres, resi 171 and name CA
set sphere_scale, 0.2089, resi 171 and name CA
show spheres, resi 212 and name CA
set sphere_scale, 0.2062, resi 212 and name CA
show spheres, resi 111 and name CA
set sphere_scale, 0.2022, resi 111 and name CA
show spheres, resi 136 and name CA
set sphere_scale, 0.2003, resi 136 and name CA
show spheres, resi 252 and name CA
set sphere_scale, 0.1974, resi 252 and name CA
show spheres, resi 16 and name CA
set sphere_scale, 0.1923, resi 16 and name CA
show spheres, resi 80 and name CA
set sphere_scale, 0.1876, resi 80 and name CA
show spheres, resi 203 and name CA
set sphere_scale, 0.1767, resi 203 and name CA
show spheres, resi 165 and name CA
set sphere_scale, 0.1760, resi 165 and name CA
show spheres, resi 13 and name CA
set sphere_scale, 0.1755, resi 13 and name CA
show spheres, resi 131 and name CA
set sphere_scale, 0.1710, resi 131 and name CA
show spheres, resi 50 and name CA
set sphere_scale, 0.1663, resi 50 and name CA
show spheres, resi 39 and name CA
set sphere_scale, 0.1661, resi 39 and name CA
show spheres, resi 223 and name CA
set sphere_scale, 0.1660, resi 223 and name CA
show spheres, resi 156 and name CA
set sphere_scale, 0.1623, resi 156 and name CA
show spheres, resi 110 and name CA
set sphere_scale, 0.1609, resi 110 and name CA
show spheres, resi 191 and name CA
set sphere_scale, 0.1596, resi 191 and name CA
show spheres, resi 132 and name CA
set sphere_scale, 0.1557, resi 132 and name CA
show spheres, resi 183 and name CA
set sphere_scale, 0.1545, resi 183 and name CA
show spheres, resi 97 and name CA
set sphere_scale, 0.1530, resi 97 and name CA
show spheres, resi 161 and name CA
set sphere_scale, 0.1522, resi 161 and name CA
show spheres, resi 259 and name CA
set sphere_scale, 0.1506, resi 259 and name CA
show spheres, resi 107 and name CA
set sphere_scale, 0.1502, resi 107 and name CA
show spheres, resi 40 and name CA
set sphere_scale, 0.1471, resi 40 and name CA
show spheres, resi 30 and name CA
set sphere_scale, 0.1448, resi 30 and name CA
show spheres, resi 114 and name CA
set sphere_scale, 0.1364, resi 114 and name CA
show spheres, resi 94 and name CA
set sphere_scale, 0.1361, resi 94 and name CA
show spheres, resi 234 and name CA
set sphere_scale, 0.1355, resi 234 and name CA
show spheres, resi 249 and name CA
set sphere_scale, 0.1354, resi 249 and name CA
show spheres, resi 47 and name CA
set sphere_scale, 0.1313, resi 47 and name CA
show spheres, resi 236 and name CA
set sphere_scale, 0.1275, resi 236 and name CA
show spheres, resi 75 and name CA
set sphere_scale, 0.1275, resi 75 and name CA
show spheres, resi 250 and name CA
set sphere_scale, 0.1263, resi 250 and name CA
show spheres, resi 255 and name CA
set sphere_scale, 0.1263, resi 255 and name CA
show spheres, resi 139 and name CA
set sphere_scale, 0.1256, resi 139 and name CA
show spheres, resi 184 and name CA
set sphere_scale, 0.1247, resi 184 and name CA
show spheres, resi 197 and name CA
set sphere_scale, 0.1241, resi 197 and name CA
show spheres, resi 19 and name CA
set sphere_scale, 0.1235, resi 19 and name CA
show spheres, resi 123 and name CA
set sphere_scale, 0.1208, resi 123 and name CA
show spheres, resi 48 and name CA
set sphere_scale, 0.1202, resi 48 and name CA
show spheres, resi 68 and name CA
set sphere_scale, 0.1116, resi 68 and name CA
show spheres, resi 237 and name CA
set sphere_scale, 0.1101, resi 237 and name CA
show spheres, resi 140 and name CA
set sphere_scale, 0.1095, resi 140 and name CA
show spheres, resi 239 and name CA
set sphere_scale, 0.1086, resi 239 and name CA
show spheres, resi 190 and name CA
set sphere_scale, 0.1082, resi 190 and name CA
show spheres, resi 109 and name CA
set sphere_scale, 0.1075, resi 109 and name CA
show spheres, resi 43 and name CA
set sphere_scale, 0.1070, resi 43 and name CA
show spheres, resi 175 and name CA
set sphere_scale, 0.1070, resi 175 and name CA
show spheres, resi 248 and name CA
set sphere_scale, 0.1028, resi 248 and name CA
show spheres, resi 37 and name CA
set sphere_scale, 0.1027, resi 37 and name CA
show spheres, resi 81 and name CA
set sphere_scale, 0.0984, resi 81 and name CA
show spheres, resi 17 and name CA
set sphere_scale, 0.0971, resi 17 and name CA
show spheres, resi 36 and name CA
set sphere_scale, 0.0929, resi 36 and name CA
show spheres, resi 31 and name CA
set sphere_scale, 0.0926, resi 31 and name CA
show spheres, resi 211 and name CA
set sphere_scale, 0.0920, resi 211 and name CA
show spheres, resi 195 and name CA
set sphere_scale, 0.0918, resi 195 and name CA
show spheres, resi 8 and name CA
set sphere_scale, 0.0899, resi 8 and name CA
show spheres, resi 221 and name CA
set sphere_scale, 0.0890, resi 221 and name CA
show spheres, resi 152 and name CA
set sphere_scale, 0.0866, resi 152 and name CA
show spheres, resi 21 and name CA
set sphere_scale, 0.0864, resi 21 and name CA
show spheres, resi 149 and name CA
set sphere_scale, 0.0840, resi 149 and name CA
show spheres, resi 202 and name CA
set sphere_scale, 0.0832, resi 202 and name CA
show spheres, resi 117 and name CA
set sphere_scale, 0.0827, resi 117 and name CA
show spheres, resi 169 and name CA
set sphere_scale, 0.0813, resi 169 and name CA
show spheres, resi 83 and name CA
set sphere_scale, 0.0801, resi 83 and name CA
show spheres, resi 6 and name CA
set sphere_scale, 0.0794, resi 6 and name CA
show spheres, resi 63 and name CA
set sphere_scale, 0.0782, resi 63 and name CA
show spheres, resi 226 and name CA
set sphere_scale, 0.0774, resi 226 and name CA
show spheres, resi 244 and name CA
set sphere_scale, 0.0766, resi 244 and name CA
show spheres, resi 52 and name CA
set sphere_scale, 0.0761, resi 52 and name CA
show spheres, resi 33 and name CA
set sphere_scale, 0.0759, resi 33 and name CA
show spheres, resi 25 and name CA
set sphere_scale, 0.0756, resi 25 and name CA
show spheres, resi 55 and name CA
set sphere_scale, 0.0751, resi 55 and name CA
show spheres, resi 254 and name CA
set sphere_scale, 0.0746, resi 254 and name CA
show spheres, resi 121 and name CA
set sphere_scale, 0.0743, resi 121 and name CA
show spheres, resi 150 and name CA
set sphere_scale, 0.0733, resi 150 and name CA
show spheres, resi 229 and name CA
set sphere_scale, 0.0733, resi 229 and name CA
show spheres, resi 5 and name CA
set sphere_scale, 0.0728, resi 5 and name CA
show spheres, resi 113 and name CA
set sphere_scale, 0.0709, resi 113 and name CA
show spheres, resi 86 and name CA
set sphere_scale, 0.0705, resi 86 and name CA
show spheres, resi 154 and name CA
set sphere_scale, 0.0694, resi 154 and name CA
show spheres, resi 213 and name CA
set sphere_scale, 0.0682, resi 213 and name CA
show spheres, resi 187 and name CA
set sphere_scale, 0.0676, resi 187 and name CA
show spheres, resi 35 and name CA
set sphere_scale, 0.0662, resi 35 and name CA
show spheres, resi 51 and name CA
set sphere_scale, 0.0655, resi 51 and name CA
show spheres, resi 257 and name CA
set sphere_scale, 0.0652, resi 257 and name CA
show spheres, resi 106 and name CA
set sphere_scale, 0.0639, resi 106 and name CA
show spheres, resi 180 and name CA
set sphere_scale, 0.0637, resi 180 and name CA
show spheres, resi 167 and name CA
set sphere_scale, 0.0634, resi 167 and name CA
show spheres, resi 127 and name CA
set sphere_scale, 0.0633, resi 127 and name CA
show spheres, resi 49 and name CA
set sphere_scale, 0.0612, resi 49 and name CA
show spheres, resi 238 and name CA
set sphere_scale, 0.0611, resi 238 and name CA
show spheres, resi 235 and name CA
set sphere_scale, 0.0596, resi 235 and name CA
show spheres, resi 11 and name CA
set sphere_scale, 0.0584, resi 11 and name CA
show spheres, resi 23 and name CA
set sphere_scale, 0.0580, resi 23 and name CA
show spheres, resi 56 and name CA
set sphere_scale, 0.0577, resi 56 and name CA
show spheres, resi 79 and name CA
set sphere_scale, 0.0534, resi 79 and name CA
show spheres, resi 22 and name CA
set sphere_scale, 0.0518, resi 22 and name CA
show spheres, resi 91 and name CA
set sphere_scale, 0.0476, resi 91 and name CA
show spheres, resi 199 and name CA
set sphere_scale, 0.0451, resi 199 and name CA
show spheres, resi 54 and name CA
set sphere_scale, 0.0450, resi 54 and name CA
show spheres, resi 219 and name CA
set sphere_scale, 0.0445, resi 219 and name CA
show spheres, resi 227 and name CA
set sphere_scale, 0.0433, resi 227 and name CA
show spheres, resi 87 and name CA
set sphere_scale, 0.0413, resi 87 and name CA
show spheres, resi 164 and name CA
set sphere_scale, 0.0408, resi 164 and name CA
show spheres, resi 92 and name CA
set sphere_scale, 0.0392, resi 92 and name CA
show spheres, resi 67 and name CA
set sphere_scale, 0.0373, resi 67 and name CA
show spheres, resi 148 and name CA
set sphere_scale, 0.0343, resi 148 and name CA
show spheres, resi 3 and name CA
set sphere_scale, 0.0341, resi 3 and name CA
show spheres, resi 4 and name CA
set sphere_scale, 0.0333, resi 4 and name CA
show spheres, resi 157 and name CA
set sphere_scale, 0.0331, resi 157 and name CA
show spheres, resi 170 and name CA
set sphere_scale, 0.0325, resi 170 and name CA
show spheres, resi 241 and name CA
set sphere_scale, 0.0325, resi 241 and name CA
show spheres, resi 12 and name CA
set sphere_scale, 0.0315, resi 12 and name CA
show spheres, resi 90 and name CA
set sphere_scale, 0.0314, resi 90 and name CA
show spheres, resi 153 and name CA
set sphere_scale, 0.0298, resi 153 and name CA
show spheres, resi 251 and name CA
set sphere_scale, 0.0279, resi 251 and name CA
show spheres, resi 144 and name CA
set sphere_scale, 0.0274, resi 144 and name CA
show spheres, resi 38 and name CA
set sphere_scale, 0.0272, resi 38 and name CA
show spheres, resi 14 and name CA
set sphere_scale, 0.0269, resi 14 and name CA
show spheres, resi 258 and name CA
set sphere_scale, 0.0261, resi 258 and name CA
show spheres, resi 222 and name CA
set sphere_scale, 0.0235, resi 222 and name CA
show spheres, resi 28 and name CA
set sphere_scale, 0.0228, resi 28 and name CA
show spheres, resi 160 and name CA
set sphere_scale, 0.0224, resi 160 and name CA
show spheres, resi 172 and name CA
set sphere_scale, 0.0220, resi 172 and name CA
show spheres, resi 24 and name CA
set sphere_scale, 0.0211, resi 24 and name CA
show spheres, resi 130 and name CA
set sphere_scale, 0.0203, resi 130 and name CA
show spheres, resi 93 and name CA
set sphere_scale, 0.0195, resi 93 and name CA
show spheres, resi 240 and name CA
set sphere_scale, 0.0187, resi 240 and name CA
show spheres, resi 124 and name CA
set sphere_scale, 0.0181, resi 124 and name CA
show spheres, resi 168 and name CA
set sphere_scale, 0.0174, resi 168 and name CA
show spheres, resi 128 and name CA
set sphere_scale, 0.0161, resi 128 and name CA
show spheres, resi 163 and name CA
set sphere_scale, 0.0150, resi 163 and name CA
show spheres, resi 181 and name CA
set sphere_scale, 0.0146, resi 181 and name CA
show spheres, resi 126 and name CA
set sphere_scale, 0.0129, resi 126 and name CA
show spheres, resi 135 and name CA
set sphere_scale, 0.0126, resi 135 and name CA
show spheres, resi 210 and name CA
set sphere_scale, 0.0107, resi 210 and name CA
show spheres, resi 196 and name CA
set sphere_scale, 0.0106, resi 196 and name CA
show spheres, resi 58 and name CA
set sphere_scale, 0.0105, resi 58 and name CA
show spheres, resi 174 and name CA
set sphere_scale, 0.0104, resi 174 and name CA
show spheres, resi 177 and name CA
set sphere_scale, 0.0104, resi 177 and name CA
show spheres, resi 73 and name CA
set sphere_scale, 0.0077, resi 73 and name CA
show spheres, resi 243 and name CA
set sphere_scale, 0.0074, resi 243 and name CA
show spheres, resi 69 and name CA
set sphere_scale, 0.0068, resi 69 and name CA
show spheres, resi 61 and name CA
set sphere_scale, 0.0067, resi 61 and name CA
show spheres, resi 7 and name CA
set sphere_scale, 0.0000, resi 7 and name CA
show spheres, resi 10 and name CA
set sphere_scale, 0.0000, resi 10 and name CA
show spheres, resi 15 and name CA
set sphere_scale, 0.0000, resi 15 and name CA
show spheres, resi 18 and name CA
set sphere_scale, 0.0000, resi 18 and name CA
show spheres, resi 26 and name CA
set sphere_scale, 0.0000, resi 26 and name CA
show spheres, resi 27 and name CA
set sphere_scale, 0.0000, resi 27 and name CA
show spheres, resi 29 and name CA
set sphere_scale, 0.0000, resi 29 and name CA
show spheres, resi 32 and name CA
set sphere_scale, 0.0000, resi 32 and name CA
show spheres, resi 34 and name CA
set sphere_scale, 0.0000, resi 34 and name CA
show spheres, resi 41 and name CA
set sphere_scale, 0.0000, resi 41 and name CA
show spheres, resi 42 and name CA
set sphere_scale, 0.0000, resi 42 and name CA
show spheres, resi 57 and name CA
set sphere_scale, 0.0000, resi 57 and name CA
show spheres, resi 59 and name CA
set sphere_scale, 0.0000, resi 59 and name CA
show spheres, resi 60 and name CA
set sphere_scale, 0.0000, resi 60 and name CA
show spheres, resi 62 and name CA
set sphere_scale, 0.0000, resi 62 and name CA
show spheres, resi 64 and name CA
set sphere_scale, 0.0000, resi 64 and name CA
show spheres, resi 65 and name CA
set sphere_scale, 0.0000, resi 65 and name CA
show spheres, resi 66 and name CA
set sphere_scale, 0.0000, resi 66 and name CA
show spheres, resi 70 and name CA
set sphere_scale, 0.0000, resi 70 and name CA
show spheres, resi 71 and name CA
set sphere_scale, 0.0000, resi 71 and name CA
show spheres, resi 72 and name CA
set sphere_scale, 0.0000, resi 72 and name CA
show spheres, resi 74 and name CA
set sphere_scale, 0.0000, resi 74 and name CA
show spheres, resi 82 and name CA
set sphere_scale, 0.0000, resi 82 and name CA
show spheres, resi 84 and name CA
set sphere_scale, 0.0000, resi 84 and name CA
show spheres, resi 85 and name CA
set sphere_scale, 0.0000, resi 85 and name CA
show spheres, resi 88 and name CA
set sphere_scale, 0.0000, resi 88 and name CA
show spheres, resi 89 and name CA
set sphere_scale, 0.0000, resi 89 and name CA
show spheres, resi 95 and name CA
set sphere_scale, 0.0000, resi 95 and name CA
show spheres, resi 96 and name CA
set sphere_scale, 0.0000, resi 96 and name CA
show spheres, resi 112 and name CA
set sphere_scale, 0.0000, resi 112 and name CA
show spheres, resi 115 and name CA
set sphere_scale, 0.0000, resi 115 and name CA
show spheres, resi 116 and name CA
set sphere_scale, 0.0000, resi 116 and name CA
show spheres, resi 118 and name CA
set sphere_scale, 0.0000, resi 118 and name CA
show spheres, resi 119 and name CA
set sphere_scale, 0.0000, resi 119 and name CA
show spheres, resi 122 and name CA
set sphere_scale, 0.0000, resi 122 and name CA
show spheres, resi 133 and name CA
set sphere_scale, 0.0000, resi 133 and name CA
show spheres, resi 137 and name CA
set sphere_scale, 0.0000, resi 137 and name CA
show spheres, resi 145 and name CA
set sphere_scale, 0.0000, resi 145 and name CA
show spheres, resi 146 and name CA
set sphere_scale, 0.0000, resi 146 and name CA
show spheres, resi 147 and name CA
set sphere_scale, 0.0000, resi 147 and name CA
show spheres, resi 151 and name CA
set sphere_scale, 0.0000, resi 151 and name CA
show spheres, resi 158 and name CA
set sphere_scale, 0.0000, resi 158 and name CA
show spheres, resi 173 and name CA
set sphere_scale, 0.0000, resi 173 and name CA
show spheres, resi 178 and name CA
set sphere_scale, 0.0000, resi 178 and name CA
show spheres, resi 182 and name CA
set sphere_scale, 0.0000, resi 182 and name CA
show spheres, resi 185 and name CA
set sphere_scale, 0.0000, resi 185 and name CA
show spheres, resi 189 and name CA
set sphere_scale, 0.0000, resi 189 and name CA
show spheres, resi 198 and name CA
set sphere_scale, 0.0000, resi 198 and name CA
show spheres, resi 200 and name CA
set sphere_scale, 0.0000, resi 200 and name CA
show spheres, resi 201 and name CA
set sphere_scale, 0.0000, resi 201 and name CA
show spheres, resi 204 and name CA
set sphere_scale, 0.0000, resi 204 and name CA
show spheres, resi 224 and name CA
set sphere_scale, 0.0000, resi 224 and name CA
show spheres, resi 225 and name CA
set sphere_scale, 0.0000, resi 225 and name CA
show spheres, resi 242 and name CA
set sphere_scale, 0.0000, resi 242 and name CA
show spheres, resi 247 and name CA
set sphere_scale, 0.0000, resi 247 and name CA
show spheres, resi 253 and name CA
set sphere_scale, 0.0000, resi 253 and name CA
sele All_Spheres, resi 188+104+206+45+192+102+232+186+217+207+138+44+215+20+214+162+193+46+205+101+245+246+209+260+125+194+220+129+78+216+179+100+155+76+256+134+143+98+228+208+176+120+142+108+141+166+233+99+103+218+77+2+53+230+105+159+9+231+171+212+111+136+252+16+80+203+165+13+131+50+39+223+156+110+191+132+183+97+161+259+107+40+30+114+94+234+249+47+236+75+250+255+139+184+197+19+123+48+68+237+140+239+190+109+43+175+248+37+81+17+36+31+211+195+8+221+152+21+149+202+117+169+83+6+63+226+244+52+33+25+55+254+121+150+229+5+113+86+154+213+187+35+51+257+106+180+167+127+49+238+235+11+23+56+79+22+91+199+54+219+227+87+164+92+67+148+3+4+157+170+241+12+90+153+251+144+38+14+258+222+28+160+172+24+130+93+240+124+168+128+163+181+126+135+210+196+58+174+177+73+243+69+61+7+10+15+18+26+27+29+32+34+41+42+57+59+60+62+64+65+66+70+71+72+74+82+84+85+88+89+95+96+112+115+116+118+119+122+133+137+145+146+147+151+158+173+178+182+185+189+198+200+201+204+224+225+242+247+253 and name CA
