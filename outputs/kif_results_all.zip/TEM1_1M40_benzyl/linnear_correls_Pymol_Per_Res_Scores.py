# You can run me in several ways, perhaps the easiest way is to:
# 1. Load the PDB file of your system in PyMOL.
# 2. Type: @[FILE_NAME.py] in the command line.
# 3. Make sure the .py file is in the same directory as the pdb.
set sphere_color, red
# The lines below are suggestions for potentially nicer figures.
# You can comment them in if you want.
# bg_color white
# set cartoon_color, grey90
# set ray_opaque_background, 0
# set antialias, 2
# set ray_shadows, 0
show spheres, resi 197 and name CA
set sphere_scale, 1.0000, resi 197 and name CA
show spheres, resi 196 and name CA
set sphere_scale, 0.9887, resi 196 and name CA
show spheres, resi 123 and name CA
set sphere_scale, 0.7962, resi 123 and name CA
show spheres, resi 103 and name CA
set sphere_scale, 0.7902, resi 103 and name CA
show spheres, resi 137 and name CA
set sphere_scale, 0.7361, resi 137 and name CA
show spheres, resi 48 and name CA
set sphere_scale, 0.7182, resi 48 and name CA
show spheres, resi 40 and name CA
set sphere_scale, 0.6851, resi 40 and name CA
show spheres, resi 47 and name CA
set sphere_scale, 0.6615, resi 47 and name CA
show spheres, resi 51 and name CA
set sphere_scale, 0.6520, resi 51 and name CA
show spheres, resi 209 and name CA
set sphere_scale, 0.6357, resi 209 and name CA
show spheres, resi 113 and name CA
set sphere_scale, 0.5897, resi 113 and name CA
show spheres, resi 114 and name CA
set sphere_scale, 0.5850, resi 114 and name CA
show spheres, resi 50 and name CA
set sphere_scale, 0.5734, resi 50 and name CA
show spheres, resi 168 and name CA
set sphere_scale, 0.5384, resi 168 and name CA
show spheres, resi 188 and name CA
set sphere_scale, 0.5262, resi 188 and name CA
show spheres, resi 260 and name CA
set sphere_scale, 0.5226, resi 260 and name CA
show spheres, resi 18 and name CA
set sphere_scale, 0.5064, resi 18 and name CA
show spheres, resi 102 and name CA
set sphere_scale, 0.4909, resi 102 and name CA
show spheres, resi 126 and name CA
set sphere_scale, 0.4906, resi 126 and name CA
show spheres, resi 117 and name CA
set sphere_scale, 0.4904, resi 117 and name CA
show spheres, resi 199 and name CA
set sphere_scale, 0.4885, resi 199 and name CA
show spheres, resi 253 and name CA
set sphere_scale, 0.4860, resi 253 and name CA
show spheres, resi 195 and name CA
set sphere_scale, 0.4681, resi 195 and name CA
show spheres, resi 215 and name CA
set sphere_scale, 0.4588, resi 215 and name CA
show spheres, resi 141 and name CA
set sphere_scale, 0.4567, resi 141 and name CA
show spheres, resi 165 and name CA
set sphere_scale, 0.4518, resi 165 and name CA
show spheres, resi 145 and name CA
set sphere_scale, 0.4507, resi 145 and name CA
show spheres, resi 58 and name CA
set sphere_scale, 0.4482, resi 58 and name CA
show spheres, resi 218 and name CA
set sphere_scale, 0.4312, resi 218 and name CA
show spheres, resi 54 and name CA
set sphere_scale, 0.4249, resi 54 and name CA
show spheres, resi 116 and name CA
set sphere_scale, 0.4220, resi 116 and name CA
show spheres, resi 135 and name CA
set sphere_scale, 0.4150, resi 135 and name CA
show spheres, resi 179 and name CA
set sphere_scale, 0.4131, resi 179 and name CA
show spheres, resi 221 and name CA
set sphere_scale, 0.4063, resi 221 and name CA
show spheres, resi 46 and name CA
set sphere_scale, 0.4060, resi 46 and name CA
show spheres, resi 224 and name CA
set sphere_scale, 0.4032, resi 224 and name CA
show spheres, resi 19 and name CA
set sphere_scale, 0.4000, resi 19 and name CA
show spheres, resi 101 and name CA
set sphere_scale, 0.3878, resi 101 and name CA
show spheres, resi 223 and name CA
set sphere_scale, 0.3856, resi 223 and name CA
show spheres, resi 147 and name CA
set sphere_scale, 0.3846, resi 147 and name CA
show spheres, resi 233 and name CA
set sphere_scale, 0.3795, resi 233 and name CA
show spheres, resi 189 and name CA
set sphere_scale, 0.3749, resi 189 and name CA
show spheres, resi 190 and name CA
set sphere_scale, 0.3667, resi 190 and name CA
show spheres, resi 186 and name CA
set sphere_scale, 0.3629, resi 186 and name CA
show spheres, resi 182 and name CA
set sphere_scale, 0.3601, resi 182 and name CA
show spheres, resi 106 and name CA
set sphere_scale, 0.3588, resi 106 and name CA
show spheres, resi 220 and name CA
set sphere_scale, 0.3577, resi 220 and name CA
show spheres, resi 110 and name CA
set sphere_scale, 0.3572, resi 110 and name CA
show spheres, resi 112 and name CA
set sphere_scale, 0.3454, resi 112 and name CA
show spheres, resi 198 and name CA
set sphere_scale, 0.3416, resi 198 and name CA
show spheres, resi 207 and name CA
set sphere_scale, 0.3416, resi 207 and name CA
show spheres, resi 214 and name CA
set sphere_scale, 0.3400, resi 214 and name CA
show spheres, resi 234 and name CA
set sphere_scale, 0.3398, resi 234 and name CA
show spheres, resi 156 and name CA
set sphere_scale, 0.3297, resi 156 and name CA
show spheres, resi 139 and name CA
set sphere_scale, 0.3254, resi 139 and name CA
show spheres, resi 107 and name CA
set sphere_scale, 0.3160, resi 107 and name CA
show spheres, resi 109 and name CA
set sphere_scale, 0.3141, resi 109 and name CA
show spheres, resi 241 and name CA
set sphere_scale, 0.3106, resi 241 and name CA
show spheres, resi 210 and name CA
set sphere_scale, 0.3084, resi 210 and name CA
show spheres, resi 105 and name CA
set sphere_scale, 0.3013, resi 105 and name CA
show spheres, resi 252 and name CA
set sphere_scale, 0.2931, resi 252 and name CA
show spheres, resi 99 and name CA
set sphere_scale, 0.2906, resi 99 and name CA
show spheres, resi 43 and name CA
set sphere_scale, 0.2880, resi 43 and name CA
show spheres, resi 237 and name CA
set sphere_scale, 0.2860, resi 237 and name CA
show spheres, resi 22 and name CA
set sphere_scale, 0.2853, resi 22 and name CA
show spheres, resi 55 and name CA
set sphere_scale, 0.2800, resi 55 and name CA
show spheres, resi 236 and name CA
set sphere_scale, 0.2759, resi 236 and name CA
show spheres, resi 146 and name CA
set sphere_scale, 0.2752, resi 146 and name CA
show spheres, resi 49 and name CA
set sphere_scale, 0.2736, resi 49 and name CA
show spheres, resi 205 and name CA
set sphere_scale, 0.2716, resi 205 and name CA
show spheres, resi 192 and name CA
set sphere_scale, 0.2687, resi 192 and name CA
show spheres, resi 194 and name CA
set sphere_scale, 0.2667, resi 194 and name CA
show spheres, resi 169 and name CA
set sphere_scale, 0.2587, resi 169 and name CA
show spheres, resi 174 and name CA
set sphere_scale, 0.2586, resi 174 and name CA
show spheres, resi 97 and name CA
set sphere_scale, 0.2578, resi 97 and name CA
show spheres, resi 36 and name CA
set sphere_scale, 0.2573, resi 36 and name CA
show spheres, resi 222 and name CA
set sphere_scale, 0.2547, resi 222 and name CA
show spheres, resi 127 and name CA
set sphere_scale, 0.2540, resi 127 and name CA
show spheres, resi 185 and name CA
set sphere_scale, 0.2495, resi 185 and name CA
show spheres, resi 12 and name CA
set sphere_scale, 0.2490, resi 12 and name CA
show spheres, resi 155 and name CA
set sphere_scale, 0.2479, resi 155 and name CA
show spheres, resi 26 and name CA
set sphere_scale, 0.2457, resi 26 and name CA
show spheres, resi 239 and name CA
set sphere_scale, 0.2452, resi 239 and name CA
show spheres, resi 249 and name CA
set sphere_scale, 0.2386, resi 249 and name CA
show spheres, resi 158 and name CA
set sphere_scale, 0.2353, resi 158 and name CA
show spheres, resi 81 and name CA
set sphere_scale, 0.2341, resi 81 and name CA
show spheres, resi 15 and name CA
set sphere_scale, 0.2295, resi 15 and name CA
show spheres, resi 162 and name CA
set sphere_scale, 0.2242, resi 162 and name CA
show spheres, resi 248 and name CA
set sphere_scale, 0.2238, resi 248 and name CA
show spheres, resi 255 and name CA
set sphere_scale, 0.2177, resi 255 and name CA
show spheres, resi 206 and name CA
set sphere_scale, 0.2157, resi 206 and name CA
show spheres, resi 134 and name CA
set sphere_scale, 0.2097, resi 134 and name CA
show spheres, resi 24 and name CA
set sphere_scale, 0.2049, resi 24 and name CA
show spheres, resi 230 and name CA
set sphere_scale, 0.2041, resi 230 and name CA
show spheres, resi 42 and name CA
set sphere_scale, 0.2005, resi 42 and name CA
show spheres, resi 159 and name CA
set sphere_scale, 0.1988, resi 159 and name CA
show spheres, resi 183 and name CA
set sphere_scale, 0.1986, resi 183 and name CA
show spheres, resi 151 and name CA
set sphere_scale, 0.1983, resi 151 and name CA
show spheres, resi 66 and name CA
set sphere_scale, 0.1873, resi 66 and name CA
show spheres, resi 144 and name CA
set sphere_scale, 0.1854, resi 144 and name CA
show spheres, resi 111 and name CA
set sphere_scale, 0.1841, resi 111 and name CA
show spheres, resi 257 and name CA
set sphere_scale, 0.1833, resi 257 and name CA
show spheres, resi 258 and name CA
set sphere_scale, 0.1823, resi 258 and name CA
show spheres, resi 37 and name CA
set sphere_scale, 0.1810, resi 37 and name CA
show spheres, resi 200 and name CA
set sphere_scale, 0.1795, resi 200 and name CA
show spheres, resi 167 and name CA
set sphere_scale, 0.1777, resi 167 and name CA
show spheres, resi 124 and name CA
set sphere_scale, 0.1739, resi 124 and name CA
show spheres, resi 238 and name CA
set sphere_scale, 0.1700, resi 238 and name CA
show spheres, resi 39 and name CA
set sphere_scale, 0.1636, resi 39 and name CA
show spheres, resi 152 and name CA
set sphere_scale, 0.1632, resi 152 and name CA
show spheres, resi 250 and name CA
set sphere_scale, 0.1593, resi 250 and name CA
show spheres, resi 41 and name CA
set sphere_scale, 0.1586, resi 41 and name CA
show spheres, resi 7 and name CA
set sphere_scale, 0.1578, resi 7 and name CA
show spheres, resi 68 and name CA
set sphere_scale, 0.1526, resi 68 and name CA
show spheres, resi 178 and name CA
set sphere_scale, 0.1497, resi 178 and name CA
show spheres, resi 254 and name CA
set sphere_scale, 0.1484, resi 254 and name CA
show spheres, resi 173 and name CA
set sphere_scale, 0.1477, resi 173 and name CA
show spheres, resi 132 and name CA
set sphere_scale, 0.1452, resi 132 and name CA
show spheres, resi 208 and name CA
set sphere_scale, 0.1439, resi 208 and name CA
show spheres, resi 175 and name CA
set sphere_scale, 0.1423, resi 175 and name CA
show spheres, resi 216 and name CA
set sphere_scale, 0.1422, resi 216 and name CA
show spheres, resi 4 and name CA
set sphere_scale, 0.1419, resi 4 and name CA
show spheres, resi 235 and name CA
set sphere_scale, 0.1406, resi 235 and name CA
show spheres, resi 27 and name CA
set sphere_scale, 0.1404, resi 27 and name CA
show spheres, resi 94 and name CA
set sphere_scale, 0.1397, resi 94 and name CA
show spheres, resi 217 and name CA
set sphere_scale, 0.1394, resi 217 and name CA
show spheres, resi 251 and name CA
set sphere_scale, 0.1389, resi 251 and name CA
show spheres, resi 160 and name CA
set sphere_scale, 0.1385, resi 160 and name CA
show spheres, resi 191 and name CA
set sphere_scale, 0.1358, resi 191 and name CA
show spheres, resi 172 and name CA
set sphere_scale, 0.1346, resi 172 and name CA
show spheres, resi 166 and name CA
set sphere_scale, 0.1335, resi 166 and name CA
show spheres, resi 100 and name CA
set sphere_scale, 0.1324, resi 100 and name CA
show spheres, resi 23 and name CA
set sphere_scale, 0.1308, resi 23 and name CA
show spheres, resi 154 and name CA
set sphere_scale, 0.1290, resi 154 and name CA
show spheres, resi 9 and name CA
set sphere_scale, 0.1287, resi 9 and name CA
show spheres, resi 78 and name CA
set sphere_scale, 0.1269, resi 78 and name CA
show spheres, resi 242 and name CA
set sphere_scale, 0.1258, resi 242 and name CA
show spheres, resi 8 and name CA
set sphere_scale, 0.1255, resi 8 and name CA
show spheres, resi 170 and name CA
set sphere_scale, 0.1245, resi 170 and name CA
show spheres, resi 211 and name CA
set sphere_scale, 0.1228, resi 211 and name CA
show spheres, resi 245 and name CA
set sphere_scale, 0.1200, resi 245 and name CA
show spheres, resi 11 and name CA
set sphere_scale, 0.1176, resi 11 and name CA
show spheres, resi 232 and name CA
set sphere_scale, 0.1163, resi 232 and name CA
show spheres, resi 212 and name CA
set sphere_scale, 0.1153, resi 212 and name CA
show spheres, resi 108 and name CA
set sphere_scale, 0.1148, resi 108 and name CA
show spheres, resi 231 and name CA
set sphere_scale, 0.1095, resi 231 and name CA
show spheres, resi 120 and name CA
set sphere_scale, 0.1094, resi 120 and name CA
show spheres, resi 259 and name CA
set sphere_scale, 0.1087, resi 259 and name CA
show spheres, resi 71 and name CA
set sphere_scale, 0.1073, resi 71 and name CA
show spheres, resi 163 and name CA
set sphere_scale, 0.1063, resi 163 and name CA
show spheres, resi 56 and name CA
set sphere_scale, 0.1055, resi 56 and name CA
show spheres, resi 64 and name CA
set sphere_scale, 0.1011, resi 64 and name CA
show spheres, resi 136 and name CA
set sphere_scale, 0.1010, resi 136 and name CA
show spheres, resi 121 and name CA
set sphere_scale, 0.0998, resi 121 and name CA
show spheres, resi 181 and name CA
set sphere_scale, 0.0965, resi 181 and name CA
show spheres, resi 201 and name CA
set sphere_scale, 0.0895, resi 201 and name CA
show spheres, resi 57 and name CA
set sphere_scale, 0.0868, resi 57 and name CA
show spheres, resi 262 and name CA
set sphere_scale, 0.0867, resi 262 and name CA
show spheres, resi 5 and name CA
set sphere_scale, 0.0837, resi 5 and name CA
show spheres, resi 187 and name CA
set sphere_scale, 0.0836, resi 187 and name CA
show spheres, resi 84 and name CA
set sphere_scale, 0.0821, resi 84 and name CA
show spheres, resi 95 and name CA
set sphere_scale, 0.0813, resi 95 and name CA
show spheres, resi 90 and name CA
set sphere_scale, 0.0804, resi 90 and name CA
show spheres, resi 60 and name CA
set sphere_scale, 0.0796, resi 60 and name CA
show spheres, resi 122 and name CA
set sphere_scale, 0.0765, resi 122 and name CA
show spheres, resi 88 and name CA
set sphere_scale, 0.0758, resi 88 and name CA
show spheres, resi 3 and name CA
set sphere_scale, 0.0735, resi 3 and name CA
show spheres, resi 21 and name CA
set sphere_scale, 0.0732, resi 21 and name CA
show spheres, resi 184 and name CA
set sphere_scale, 0.0729, resi 184 and name CA
show spheres, resi 243 and name CA
set sphere_scale, 0.0693, resi 243 and name CA
show spheres, resi 164 and name CA
set sphere_scale, 0.0687, resi 164 and name CA
show spheres, resi 25 and name CA
set sphere_scale, 0.0685, resi 25 and name CA
show spheres, resi 80 and name CA
set sphere_scale, 0.0683, resi 80 and name CA
show spheres, resi 128 and name CA
set sphere_scale, 0.0596, resi 128 and name CA
show spheres, resi 240 and name CA
set sphere_scale, 0.0584, resi 240 and name CA
show spheres, resi 13 and name CA
set sphere_scale, 0.0580, resi 13 and name CA
show spheres, resi 247 and name CA
set sphere_scale, 0.0573, resi 247 and name CA
show spheres, resi 244 and name CA
set sphere_scale, 0.0569, resi 244 and name CA
show spheres, resi 153 and name CA
set sphere_scale, 0.0566, resi 153 and name CA
show spheres, resi 83 and name CA
set sphere_scale, 0.0561, resi 83 and name CA
show spheres, resi 10 and name CA
set sphere_scale, 0.0543, resi 10 and name CA
show spheres, resi 180 and name CA
set sphere_scale, 0.0530, resi 180 and name CA
show spheres, resi 133 and name CA
set sphere_scale, 0.0525, resi 133 and name CA
show spheres, resi 115 and name CA
set sphere_scale, 0.0520, resi 115 and name CA
show spheres, resi 142 and name CA
set sphere_scale, 0.0506, resi 142 and name CA
show spheres, resi 93 and name CA
set sphere_scale, 0.0494, resi 93 and name CA
show spheres, resi 246 and name CA
set sphere_scale, 0.0490, resi 246 and name CA
show spheres, resi 16 and name CA
set sphere_scale, 0.0490, resi 16 and name CA
show spheres, resi 79 and name CA
set sphere_scale, 0.0473, resi 79 and name CA
show spheres, resi 14 and name CA
set sphere_scale, 0.0462, resi 14 and name CA
show spheres, resi 130 and name CA
set sphere_scale, 0.0454, resi 130 and name CA
show spheres, resi 63 and name CA
set sphere_scale, 0.0436, resi 63 and name CA
show spheres, resi 171 and name CA
set sphere_scale, 0.0414, resi 171 and name CA
show spheres, resi 35 and name CA
set sphere_scale, 0.0411, resi 35 and name CA
show spheres, resi 70 and name CA
set sphere_scale, 0.0404, resi 70 and name CA
show spheres, resi 261 and name CA
set sphere_scale, 0.0403, resi 261 and name CA
show spheres, resi 219 and name CA
set sphere_scale, 0.0393, resi 219 and name CA
show spheres, resi 29 and name CA
set sphere_scale, 0.0387, resi 29 and name CA
show spheres, resi 30 and name CA
set sphere_scale, 0.0384, resi 30 and name CA
show spheres, resi 148 and name CA
set sphere_scale, 0.0383, resi 148 and name CA
show spheres, resi 87 and name CA
set sphere_scale, 0.0371, resi 87 and name CA
show spheres, resi 96 and name CA
set sphere_scale, 0.0360, resi 96 and name CA
show spheres, resi 143 and name CA
set sphere_scale, 0.0335, resi 143 and name CA
show spheres, resi 33 and name CA
set sphere_scale, 0.0328, resi 33 and name CA
show spheres, resi 177 and name CA
set sphere_scale, 0.0315, resi 177 and name CA
show spheres, resi 89 and name CA
set sphere_scale, 0.0315, resi 89 and name CA
show spheres, resi 226 and name CA
set sphere_scale, 0.0309, resi 226 and name CA
show spheres, resi 229 and name CA
set sphere_scale, 0.0309, resi 229 and name CA
show spheres, resi 31 and name CA
set sphere_scale, 0.0308, resi 31 and name CA
show spheres, resi 69 and name CA
set sphere_scale, 0.0301, resi 69 and name CA
show spheres, resi 138 and name CA
set sphere_scale, 0.0289, resi 138 and name CA
show spheres, resi 86 and name CA
set sphere_scale, 0.0280, resi 86 and name CA
show spheres, resi 104 and name CA
set sphere_scale, 0.0270, resi 104 and name CA
show spheres, resi 77 and name CA
set sphere_scale, 0.0263, resi 77 and name CA
show spheres, resi 34 and name CA
set sphere_scale, 0.0251, resi 34 and name CA
show spheres, resi 150 and name CA
set sphere_scale, 0.0249, resi 150 and name CA
show spheres, resi 59 and name CA
set sphere_scale, 0.0226, resi 59 and name CA
show spheres, resi 118 and name CA
set sphere_scale, 0.0215, resi 118 and name CA
show spheres, resi 72 and name CA
set sphere_scale, 0.0207, resi 72 and name CA
show spheres, resi 65 and name CA
set sphere_scale, 0.0196, resi 65 and name CA
show spheres, resi 131 and name CA
set sphere_scale, 0.0175, resi 131 and name CA
show spheres, resi 140 and name CA
set sphere_scale, 0.0155, resi 140 and name CA
show spheres, resi 82 and name CA
set sphere_scale, 0.0147, resi 82 and name CA
show spheres, resi 73 and name CA
set sphere_scale, 0.0145, resi 73 and name CA
show spheres, resi 76 and name CA
set sphere_scale, 0.0145, resi 76 and name CA
show spheres, resi 193 and name CA
set sphere_scale, 0.0135, resi 193 and name CA
show spheres, resi 28 and name CA
set sphere_scale, 0.0131, resi 28 and name CA
show spheres, resi 2 and name CA
set sphere_scale, 0.0130, resi 2 and name CA
show spheres, resi 32 and name CA
set sphere_scale, 0.0120, resi 32 and name CA
show spheres, resi 53 and name CA
set sphere_scale, 0.0108, resi 53 and name CA
show spheres, resi 74 and name CA
set sphere_scale, 0.0092, resi 74 and name CA
show spheres, resi 62 and name CA
set sphere_scale, 0.0087, resi 62 and name CA
show spheres, resi 129 and name CA
set sphere_scale, 0.0074, resi 129 and name CA
show spheres, resi 176 and name CA
set sphere_scale, 0.0069, resi 176 and name CA
show spheres, resi 125 and name CA
set sphere_scale, 0.0054, resi 125 and name CA
show spheres, resi 91 and name CA
set sphere_scale, 0.0052, resi 91 and name CA
show spheres, resi 263 and name CA
set sphere_scale, 0.0040, resi 263 and name CA
show spheres, resi 6 and name CA
set sphere_scale, 0.0032, resi 6 and name CA
show spheres, resi 17 and name CA
set sphere_scale, 0.0000, resi 17 and name CA
show spheres, resi 20 and name CA
set sphere_scale, 0.0000, resi 20 and name CA
show spheres, resi 38 and name CA
set sphere_scale, 0.0000, resi 38 and name CA
show spheres, resi 44 and name CA
set sphere_scale, 0.0000, resi 44 and name CA
show spheres, resi 45 and name CA
set sphere_scale, 0.0000, resi 45 and name CA
show spheres, resi 52 and name CA
set sphere_scale, 0.0000, resi 52 and name CA
show spheres, resi 61 and name CA
set sphere_scale, 0.0000, resi 61 and name CA
show spheres, resi 67 and name CA
set sphere_scale, 0.0000, resi 67 and name CA
show spheres, resi 75 and name CA
set sphere_scale, 0.0000, resi 75 and name CA
show spheres, resi 85 and name CA
set sphere_scale, 0.0000, resi 85 and name CA
show spheres, resi 92 and name CA
set sphere_scale, 0.0000, resi 92 and name CA
show spheres, resi 98 and name CA
set sphere_scale, 0.0000, resi 98 and name CA
show spheres, resi 119 and name CA
set sphere_scale, 0.0000, resi 119 and name CA
show spheres, resi 149 and name CA
set sphere_scale, 0.0000, resi 149 and name CA
show spheres, resi 157 and name CA
set sphere_scale, 0.0000, resi 157 and name CA
show spheres, resi 161 and name CA
set sphere_scale, 0.0000, resi 161 and name CA
show spheres, resi 202 and name CA
set sphere_scale, 0.0000, resi 202 and name CA
show spheres, resi 203 and name CA
set sphere_scale, 0.0000, resi 203 and name CA
show spheres, resi 204 and name CA
set sphere_scale, 0.0000, resi 204 and name CA
show spheres, resi 213 and name CA
set sphere_scale, 0.0000, resi 213 and name CA
show spheres, resi 225 and name CA
set sphere_scale, 0.0000, resi 225 and name CA
show spheres, resi 227 and name CA
set sphere_scale, 0.0000, resi 227 and name CA
show spheres, resi 228 and name CA
set sphere_scale, 0.0000, resi 228 and name CA
show spheres, resi 256 and name CA
set sphere_scale, 0.0000, resi 256 and name CA
sele All_Spheres, resi 197+196+123+103+137+48+40+47+51+209+113+114+50+168+188+260+18+102+126+117+199+253+195+215+141+165+145+58+218+54+116+135+179+221+46+224+19+101+223+147+233+189+190+186+182+106+220+110+112+198+207+214+234+156+139+107+109+241+210+105+252+99+43+237+22+55+236+146+49+205+192+194+169+174+97+36+222+127+185+12+155+26+239+249+158+81+15+162+248+255+206+134+24+230+42+159+183+151+66+144+111+257+258+37+200+167+124+238+39+152+250+41+7+68+178+254+173+132+208+175+216+4+235+27+94+217+251+160+191+172+166+100+23+154+9+78+242+8+170+211+245+11+232+212+108+231+120+259+71+163+56+64+136+121+181+201+57+262+5+187+84+95+90+60+122+88+3+21+184+243+164+25+80+128+240+13+247+244+153+83+10+180+133+115+142+93+246+16+79+14+130+63+171+35+70+261+219+29+30+148+87+96+143+33+177+89+226+229+31+69+138+86+104+77+34+150+59+118+72+65+131+140+82+73+76+193+28+2+32+53+74+62+129+176+125+91+263+6+17+20+38+44+45+52+61+67+75+85+92+98+119+149+157+161+202+203+204+213+225+227+228+256 and name CA
