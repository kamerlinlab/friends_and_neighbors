# You can run me in several ways, perhaps the easiest way is to:
# 1. Load the PDB file of your system in PyMOL.
# 2. Type: @[FILE_NAME.py] in the command line.
# 3. Make sure the .py file is in the same directory as the pdb.
set sphere_color, red
# The lines below are suggestions for potentially nicer figures.
# You can comment them in if you want.
# bg_color white
# set cartoon_color, grey90
# set ray_opaque_background, 0
# set antialias, 2
# set ray_shadows, 0
show spheres, resi 48 and name CA
set sphere_scale, 1.0000, resi 48 and name CA
show spheres, resi 145 and name CA
set sphere_scale, 0.9765, resi 145 and name CA
show spheres, resi 215 and name CA
set sphere_scale, 0.8036, resi 215 and name CA
show spheres, resi 107 and name CA
set sphere_scale, 0.7111, resi 107 and name CA
show spheres, resi 105 and name CA
set sphere_scale, 0.6520, resi 105 and name CA
show spheres, resi 146 and name CA
set sphere_scale, 0.5663, resi 146 and name CA
show spheres, resi 190 and name CA
set sphere_scale, 0.5141, resi 190 and name CA
show spheres, resi 103 and name CA
set sphere_scale, 0.4842, resi 103 and name CA
show spheres, resi 147 and name CA
set sphere_scale, 0.4820, resi 147 and name CA
show spheres, resi 209 and name CA
set sphere_scale, 0.4436, resi 209 and name CA
show spheres, resi 40 and name CA
set sphere_scale, 0.4414, resi 40 and name CA
show spheres, resi 47 and name CA
set sphere_scale, 0.3940, resi 47 and name CA
show spheres, resi 214 and name CA
set sphere_scale, 0.3820, resi 214 and name CA
show spheres, resi 197 and name CA
set sphere_scale, 0.3563, resi 197 and name CA
show spheres, resi 80 and name CA
set sphere_scale, 0.3402, resi 80 and name CA
show spheres, resi 139 and name CA
set sphere_scale, 0.3246, resi 139 and name CA
show spheres, resi 19 and name CA
set sphere_scale, 0.3242, resi 19 and name CA
show spheres, resi 79 and name CA
set sphere_scale, 0.2981, resi 79 and name CA
show spheres, resi 46 and name CA
set sphere_scale, 0.2906, resi 46 and name CA
show spheres, resi 155 and name CA
set sphere_scale, 0.2884, resi 155 and name CA
show spheres, resi 248 and name CA
set sphere_scale, 0.2786, resi 248 and name CA
show spheres, resi 195 and name CA
set sphere_scale, 0.2776, resi 195 and name CA
show spheres, resi 144 and name CA
set sphere_scale, 0.2737, resi 144 and name CA
show spheres, resi 106 and name CA
set sphere_scale, 0.2718, resi 106 and name CA
show spheres, resi 187 and name CA
set sphere_scale, 0.2641, resi 187 and name CA
show spheres, resi 212 and name CA
set sphere_scale, 0.2634, resi 212 and name CA
show spheres, resi 141 and name CA
set sphere_scale, 0.2392, resi 141 and name CA
show spheres, resi 142 and name CA
set sphere_scale, 0.2326, resi 142 and name CA
show spheres, resi 168 and name CA
set sphere_scale, 0.2311, resi 168 and name CA
show spheres, resi 240 and name CA
set sphere_scale, 0.2269, resi 240 and name CA
show spheres, resi 81 and name CA
set sphere_scale, 0.2265, resi 81 and name CA
show spheres, resi 152 and name CA
set sphere_scale, 0.2251, resi 152 and name CA
show spheres, resi 218 and name CA
set sphere_scale, 0.2173, resi 218 and name CA
show spheres, resi 192 and name CA
set sphere_scale, 0.2119, resi 192 and name CA
show spheres, resi 44 and name CA
set sphere_scale, 0.2114, resi 44 and name CA
show spheres, resi 151 and name CA
set sphere_scale, 0.2106, resi 151 and name CA
show spheres, resi 220 and name CA
set sphere_scale, 0.2031, resi 220 and name CA
show spheres, resi 136 and name CA
set sphere_scale, 0.2010, resi 136 and name CA
show spheres, resi 104 and name CA
set sphere_scale, 0.1990, resi 104 and name CA
show spheres, resi 126 and name CA
set sphere_scale, 0.1959, resi 126 and name CA
show spheres, resi 50 and name CA
set sphere_scale, 0.1944, resi 50 and name CA
show spheres, resi 169 and name CA
set sphere_scale, 0.1943, resi 169 and name CA
show spheres, resi 196 and name CA
set sphere_scale, 0.1932, resi 196 and name CA
show spheres, resi 132 and name CA
set sphere_scale, 0.1917, resi 132 and name CA
show spheres, resi 241 and name CA
set sphere_scale, 0.1915, resi 241 and name CA
show spheres, resi 128 and name CA
set sphere_scale, 0.1907, resi 128 and name CA
show spheres, resi 20 and name CA
set sphere_scale, 0.1901, resi 20 and name CA
show spheres, resi 134 and name CA
set sphere_scale, 0.1891, resi 134 and name CA
show spheres, resi 123 and name CA
set sphere_scale, 0.1853, resi 123 and name CA
show spheres, resi 110 and name CA
set sphere_scale, 0.1789, resi 110 and name CA
show spheres, resi 42 and name CA
set sphere_scale, 0.1727, resi 42 and name CA
show spheres, resi 173 and name CA
set sphere_scale, 0.1727, resi 173 and name CA
show spheres, resi 179 and name CA
set sphere_scale, 0.1693, resi 179 and name CA
show spheres, resi 206 and name CA
set sphere_scale, 0.1611, resi 206 and name CA
show spheres, resi 219 and name CA
set sphere_scale, 0.1605, resi 219 and name CA
show spheres, resi 210 and name CA
set sphere_scale, 0.1582, resi 210 and name CA
show spheres, resi 114 and name CA
set sphere_scale, 0.1568, resi 114 and name CA
show spheres, resi 27 and name CA
set sphere_scale, 0.1541, resi 27 and name CA
show spheres, resi 217 and name CA
set sphere_scale, 0.1540, resi 217 and name CA
show spheres, resi 36 and name CA
set sphere_scale, 0.1509, resi 36 and name CA
show spheres, resi 43 and name CA
set sphere_scale, 0.1505, resi 43 and name CA
show spheres, resi 166 and name CA
set sphere_scale, 0.1492, resi 166 and name CA
show spheres, resi 153 and name CA
set sphere_scale, 0.1483, resi 153 and name CA
show spheres, resi 198 and name CA
set sphere_scale, 0.1480, resi 198 and name CA
show spheres, resi 51 and name CA
set sphere_scale, 0.1456, resi 51 and name CA
show spheres, resi 216 and name CA
set sphere_scale, 0.1436, resi 216 and name CA
show spheres, resi 130 and name CA
set sphere_scale, 0.1377, resi 130 and name CA
show spheres, resi 41 and name CA
set sphere_scale, 0.1374, resi 41 and name CA
show spheres, resi 57 and name CA
set sphere_scale, 0.1361, resi 57 and name CA
show spheres, resi 165 and name CA
set sphere_scale, 0.1350, resi 165 and name CA
show spheres, resi 137 and name CA
set sphere_scale, 0.1336, resi 137 and name CA
show spheres, resi 39 and name CA
set sphere_scale, 0.1299, resi 39 and name CA
show spheres, resi 237 and name CA
set sphere_scale, 0.1262, resi 237 and name CA
show spheres, resi 167 and name CA
set sphere_scale, 0.1255, resi 167 and name CA
show spheres, resi 174 and name CA
set sphere_scale, 0.1237, resi 174 and name CA
show spheres, resi 185 and name CA
set sphere_scale, 0.1224, resi 185 and name CA
show spheres, resi 102 and name CA
set sphere_scale, 0.1221, resi 102 and name CA
show spheres, resi 183 and name CA
set sphere_scale, 0.1165, resi 183 and name CA
show spheres, resi 260 and name CA
set sphere_scale, 0.1153, resi 260 and name CA
show spheres, resi 24 and name CA
set sphere_scale, 0.1123, resi 24 and name CA
show spheres, resi 189 and name CA
set sphere_scale, 0.1111, resi 189 and name CA
show spheres, resi 16 and name CA
set sphere_scale, 0.1060, resi 16 and name CA
show spheres, resi 224 and name CA
set sphere_scale, 0.1049, resi 224 and name CA
show spheres, resi 154 and name CA
set sphere_scale, 0.1036, resi 154 and name CA
show spheres, resi 158 and name CA
set sphere_scale, 0.1029, resi 158 and name CA
show spheres, resi 117 and name CA
set sphere_scale, 0.1025, resi 117 and name CA
show spheres, resi 23 and name CA
set sphere_scale, 0.1009, resi 23 and name CA
show spheres, resi 194 and name CA
set sphere_scale, 0.1006, resi 194 and name CA
show spheres, resi 221 and name CA
set sphere_scale, 0.0990, resi 221 and name CA
show spheres, resi 252 and name CA
set sphere_scale, 0.0985, resi 252 and name CA
show spheres, resi 223 and name CA
set sphere_scale, 0.0979, resi 223 and name CA
show spheres, resi 208 and name CA
set sphere_scale, 0.0934, resi 208 and name CA
show spheres, resi 26 and name CA
set sphere_scale, 0.0929, resi 26 and name CA
show spheres, resi 37 and name CA
set sphere_scale, 0.0920, resi 37 and name CA
show spheres, resi 235 and name CA
set sphere_scale, 0.0903, resi 235 and name CA
show spheres, resi 253 and name CA
set sphere_scale, 0.0891, resi 253 and name CA
show spheres, resi 148 and name CA
set sphere_scale, 0.0890, resi 148 and name CA
show spheres, resi 138 and name CA
set sphere_scale, 0.0886, resi 138 and name CA
show spheres, resi 135 and name CA
set sphere_scale, 0.0847, resi 135 and name CA
show spheres, resi 54 and name CA
set sphere_scale, 0.0838, resi 54 and name CA
show spheres, resi 182 and name CA
set sphere_scale, 0.0832, resi 182 and name CA
show spheres, resi 234 and name CA
set sphere_scale, 0.0805, resi 234 and name CA
show spheres, resi 162 and name CA
set sphere_scale, 0.0781, resi 162 and name CA
show spheres, resi 205 and name CA
set sphere_scale, 0.0778, resi 205 and name CA
show spheres, resi 242 and name CA
set sphere_scale, 0.0755, resi 242 and name CA
show spheres, resi 99 and name CA
set sphere_scale, 0.0753, resi 99 and name CA
show spheres, resi 249 and name CA
set sphere_scale, 0.0738, resi 249 and name CA
show spheres, resi 13 and name CA
set sphere_scale, 0.0724, resi 13 and name CA
show spheres, resi 108 and name CA
set sphere_scale, 0.0721, resi 108 and name CA
show spheres, resi 193 and name CA
set sphere_scale, 0.0717, resi 193 and name CA
show spheres, resi 200 and name CA
set sphere_scale, 0.0715, resi 200 and name CA
show spheres, resi 255 and name CA
set sphere_scale, 0.0697, resi 255 and name CA
show spheres, resi 170 and name CA
set sphere_scale, 0.0676, resi 170 and name CA
show spheres, resi 164 and name CA
set sphere_scale, 0.0674, resi 164 and name CA
show spheres, resi 101 and name CA
set sphere_scale, 0.0673, resi 101 and name CA
show spheres, resi 159 and name CA
set sphere_scale, 0.0658, resi 159 and name CA
show spheres, resi 55 and name CA
set sphere_scale, 0.0651, resi 55 and name CA
show spheres, resi 239 and name CA
set sphere_scale, 0.0646, resi 239 and name CA
show spheres, resi 207 and name CA
set sphere_scale, 0.0640, resi 207 and name CA
show spheres, resi 131 and name CA
set sphere_scale, 0.0637, resi 131 and name CA
show spheres, resi 31 and name CA
set sphere_scale, 0.0636, resi 31 and name CA
show spheres, resi 32 and name CA
set sphere_scale, 0.0635, resi 32 and name CA
show spheres, resi 17 and name CA
set sphere_scale, 0.0634, resi 17 and name CA
show spheres, resi 49 and name CA
set sphere_scale, 0.0632, resi 49 and name CA
show spheres, resi 8 and name CA
set sphere_scale, 0.0630, resi 8 and name CA
show spheres, resi 175 and name CA
set sphere_scale, 0.0614, resi 175 and name CA
show spheres, resi 191 and name CA
set sphere_scale, 0.0581, resi 191 and name CA
show spheres, resi 251 and name CA
set sphere_scale, 0.0572, resi 251 and name CA
show spheres, resi 12 and name CA
set sphere_scale, 0.0545, resi 12 and name CA
show spheres, resi 127 and name CA
set sphere_scale, 0.0518, resi 127 and name CA
show spheres, resi 222 and name CA
set sphere_scale, 0.0517, resi 222 and name CA
show spheres, resi 14 and name CA
set sphere_scale, 0.0498, resi 14 and name CA
show spheres, resi 243 and name CA
set sphere_scale, 0.0478, resi 243 and name CA
show spheres, resi 78 and name CA
set sphere_scale, 0.0459, resi 78 and name CA
show spheres, resi 171 and name CA
set sphere_scale, 0.0458, resi 171 and name CA
show spheres, resi 238 and name CA
set sphere_scale, 0.0447, resi 238 and name CA
show spheres, resi 232 and name CA
set sphere_scale, 0.0446, resi 232 and name CA
show spheres, resi 180 and name CA
set sphere_scale, 0.0436, resi 180 and name CA
show spheres, resi 262 and name CA
set sphere_scale, 0.0430, resi 262 and name CA
show spheres, resi 172 and name CA
set sphere_scale, 0.0426, resi 172 and name CA
show spheres, resi 84 and name CA
set sphere_scale, 0.0415, resi 84 and name CA
show spheres, resi 236 and name CA
set sphere_scale, 0.0413, resi 236 and name CA
show spheres, resi 15 and name CA
set sphere_scale, 0.0411, resi 15 and name CA
show spheres, resi 160 and name CA
set sphere_scale, 0.0410, resi 160 and name CA
show spheres, resi 186 and name CA
set sphere_scale, 0.0403, resi 186 and name CA
show spheres, resi 59 and name CA
set sphere_scale, 0.0401, resi 59 and name CA
show spheres, resi 11 and name CA
set sphere_scale, 0.0381, resi 11 and name CA
show spheres, resi 199 and name CA
set sphere_scale, 0.0379, resi 199 and name CA
show spheres, resi 29 and name CA
set sphere_scale, 0.0374, resi 29 and name CA
show spheres, resi 163 and name CA
set sphere_scale, 0.0373, resi 163 and name CA
show spheres, resi 88 and name CA
set sphere_scale, 0.0365, resi 88 and name CA
show spheres, resi 211 and name CA
set sphere_scale, 0.0365, resi 211 and name CA
show spheres, resi 87 and name CA
set sphere_scale, 0.0361, resi 87 and name CA
show spheres, resi 2 and name CA
set sphere_scale, 0.0339, resi 2 and name CA
show spheres, resi 82 and name CA
set sphere_scale, 0.0339, resi 82 and name CA
show spheres, resi 86 and name CA
set sphere_scale, 0.0339, resi 86 and name CA
show spheres, resi 257 and name CA
set sphere_scale, 0.0336, resi 257 and name CA
show spheres, resi 233 and name CA
set sphere_scale, 0.0336, resi 233 and name CA
show spheres, resi 112 and name CA
set sphere_scale, 0.0330, resi 112 and name CA
show spheres, resi 100 and name CA
set sphere_scale, 0.0329, resi 100 and name CA
show spheres, resi 83 and name CA
set sphere_scale, 0.0325, resi 83 and name CA
show spheres, resi 109 and name CA
set sphere_scale, 0.0324, resi 109 and name CA
show spheres, resi 111 and name CA
set sphere_scale, 0.0323, resi 111 and name CA
show spheres, resi 58 and name CA
set sphere_scale, 0.0323, resi 58 and name CA
show spheres, resi 10 and name CA
set sphere_scale, 0.0321, resi 10 and name CA
show spheres, resi 73 and name CA
set sphere_scale, 0.0321, resi 73 and name CA
show spheres, resi 93 and name CA
set sphere_scale, 0.0319, resi 93 and name CA
show spheres, resi 28 and name CA
set sphere_scale, 0.0318, resi 28 and name CA
show spheres, resi 120 and name CA
set sphere_scale, 0.0317, resi 120 and name CA
show spheres, resi 60 and name CA
set sphere_scale, 0.0306, resi 60 and name CA
show spheres, resi 33 and name CA
set sphere_scale, 0.0276, resi 33 and name CA
show spheres, resi 254 and name CA
set sphere_scale, 0.0273, resi 254 and name CA
show spheres, resi 259 and name CA
set sphere_scale, 0.0271, resi 259 and name CA
show spheres, resi 184 and name CA
set sphere_scale, 0.0267, resi 184 and name CA
show spheres, resi 9 and name CA
set sphere_scale, 0.0264, resi 9 and name CA
show spheres, resi 68 and name CA
set sphere_scale, 0.0262, resi 68 and name CA
show spheres, resi 85 and name CA
set sphere_scale, 0.0247, resi 85 and name CA
show spheres, resi 5 and name CA
set sphere_scale, 0.0244, resi 5 and name CA
show spheres, resi 258 and name CA
set sphere_scale, 0.0244, resi 258 and name CA
show spheres, resi 143 and name CA
set sphere_scale, 0.0233, resi 143 and name CA
show spheres, resi 95 and name CA
set sphere_scale, 0.0226, resi 95 and name CA
show spheres, resi 124 and name CA
set sphere_scale, 0.0224, resi 124 and name CA
show spheres, resi 90 and name CA
set sphere_scale, 0.0224, resi 90 and name CA
show spheres, resi 94 and name CA
set sphere_scale, 0.0223, resi 94 and name CA
show spheres, resi 177 and name CA
set sphere_scale, 0.0215, resi 177 and name CA
show spheres, resi 71 and name CA
set sphere_scale, 0.0212, resi 71 and name CA
show spheres, resi 230 and name CA
set sphere_scale, 0.0209, resi 230 and name CA
show spheres, resi 156 and name CA
set sphere_scale, 0.0207, resi 156 and name CA
show spheres, resi 250 and name CA
set sphere_scale, 0.0207, resi 250 and name CA
show spheres, resi 263 and name CA
set sphere_scale, 0.0206, resi 263 and name CA
show spheres, resi 231 and name CA
set sphere_scale, 0.0205, resi 231 and name CA
show spheres, resi 116 and name CA
set sphere_scale, 0.0198, resi 116 and name CA
show spheres, resi 61 and name CA
set sphere_scale, 0.0194, resi 61 and name CA
show spheres, resi 201 and name CA
set sphere_scale, 0.0189, resi 201 and name CA
show spheres, resi 64 and name CA
set sphere_scale, 0.0184, resi 64 and name CA
show spheres, resi 181 and name CA
set sphere_scale, 0.0173, resi 181 and name CA
show spheres, resi 113 and name CA
set sphere_scale, 0.0171, resi 113 and name CA
show spheres, resi 129 and name CA
set sphere_scale, 0.0166, resi 129 and name CA
show spheres, resi 97 and name CA
set sphere_scale, 0.0161, resi 97 and name CA
show spheres, resi 115 and name CA
set sphere_scale, 0.0158, resi 115 and name CA
show spheres, resi 56 and name CA
set sphere_scale, 0.0155, resi 56 and name CA
show spheres, resi 76 and name CA
set sphere_scale, 0.0151, resi 76 and name CA
show spheres, resi 66 and name CA
set sphere_scale, 0.0141, resi 66 and name CA
show spheres, resi 133 and name CA
set sphere_scale, 0.0139, resi 133 and name CA
show spheres, resi 89 and name CA
set sphere_scale, 0.0137, resi 89 and name CA
show spheres, resi 157 and name CA
set sphere_scale, 0.0131, resi 157 and name CA
show spheres, resi 125 and name CA
set sphere_scale, 0.0127, resi 125 and name CA
show spheres, resi 178 and name CA
set sphere_scale, 0.0124, resi 178 and name CA
show spheres, resi 140 and name CA
set sphere_scale, 0.0121, resi 140 and name CA
show spheres, resi 245 and name CA
set sphere_scale, 0.0111, resi 245 and name CA
show spheres, resi 63 and name CA
set sphere_scale, 0.0101, resi 63 and name CA
show spheres, resi 226 and name CA
set sphere_scale, 0.0099, resi 226 and name CA
show spheres, resi 229 and name CA
set sphere_scale, 0.0099, resi 229 and name CA
show spheres, resi 247 and name CA
set sphere_scale, 0.0099, resi 247 and name CA
show spheres, resi 25 and name CA
set sphere_scale, 0.0098, resi 25 and name CA
show spheres, resi 121 and name CA
set sphere_scale, 0.0097, resi 121 and name CA
show spheres, resi 65 and name CA
set sphere_scale, 0.0096, resi 65 and name CA
show spheres, resi 246 and name CA
set sphere_scale, 0.0092, resi 246 and name CA
show spheres, resi 77 and name CA
set sphere_scale, 0.0088, resi 77 and name CA
show spheres, resi 91 and name CA
set sphere_scale, 0.0078, resi 91 and name CA
show spheres, resi 176 and name CA
set sphere_scale, 0.0062, resi 176 and name CA
show spheres, resi 69 and name CA
set sphere_scale, 0.0061, resi 69 and name CA
show spheres, resi 96 and name CA
set sphere_scale, 0.0059, resi 96 and name CA
show spheres, resi 62 and name CA
set sphere_scale, 0.0057, resi 62 and name CA
show spheres, resi 244 and name CA
set sphere_scale, 0.0055, resi 244 and name CA
show spheres, resi 149 and name CA
set sphere_scale, 0.0043, resi 149 and name CA
show spheres, resi 3 and name CA
set sphere_scale, 0.0043, resi 3 and name CA
show spheres, resi 72 and name CA
set sphere_scale, 0.0040, resi 72 and name CA
show spheres, resi 6 and name CA
set sphere_scale, 0.0034, resi 6 and name CA
show spheres, resi 35 and name CA
set sphere_scale, 0.0025, resi 35 and name CA
show spheres, resi 4 and name CA
set sphere_scale, 0.0000, resi 4 and name CA
show spheres, resi 7 and name CA
set sphere_scale, 0.0000, resi 7 and name CA
show spheres, resi 18 and name CA
set sphere_scale, 0.0000, resi 18 and name CA
show spheres, resi 21 and name CA
set sphere_scale, 0.0000, resi 21 and name CA
show spheres, resi 22 and name CA
set sphere_scale, 0.0000, resi 22 and name CA
show spheres, resi 30 and name CA
set sphere_scale, 0.0000, resi 30 and name CA
show spheres, resi 34 and name CA
set sphere_scale, 0.0000, resi 34 and name CA
show spheres, resi 38 and name CA
set sphere_scale, 0.0000, resi 38 and name CA
show spheres, resi 45 and name CA
set sphere_scale, 0.0000, resi 45 and name CA
show spheres, resi 52 and name CA
set sphere_scale, 0.0000, resi 52 and name CA
show spheres, resi 53 and name CA
set sphere_scale, 0.0000, resi 53 and name CA
show spheres, resi 67 and name CA
set sphere_scale, 0.0000, resi 67 and name CA
show spheres, resi 70 and name CA
set sphere_scale, 0.0000, resi 70 and name CA
show spheres, resi 74 and name CA
set sphere_scale, 0.0000, resi 74 and name CA
show spheres, resi 75 and name CA
set sphere_scale, 0.0000, resi 75 and name CA
show spheres, resi 92 and name CA
set sphere_scale, 0.0000, resi 92 and name CA
show spheres, resi 98 and name CA
set sphere_scale, 0.0000, resi 98 and name CA
show spheres, resi 118 and name CA
set sphere_scale, 0.0000, resi 118 and name CA
show spheres, resi 119 and name CA
set sphere_scale, 0.0000, resi 119 and name CA
show spheres, resi 122 and name CA
set sphere_scale, 0.0000, resi 122 and name CA
show spheres, resi 150 and name CA
set sphere_scale, 0.0000, resi 150 and name CA
show spheres, resi 161 and name CA
set sphere_scale, 0.0000, resi 161 and name CA
show spheres, resi 188 and name CA
set sphere_scale, 0.0000, resi 188 and name CA
show spheres, resi 202 and name CA
set sphere_scale, 0.0000, resi 202 and name CA
show spheres, resi 203 and name CA
set sphere_scale, 0.0000, resi 203 and name CA
show spheres, resi 204 and name CA
set sphere_scale, 0.0000, resi 204 and name CA
show spheres, resi 213 and name CA
set sphere_scale, 0.0000, resi 213 and name CA
show spheres, resi 225 and name CA
set sphere_scale, 0.0000, resi 225 and name CA
show spheres, resi 227 and name CA
set sphere_scale, 0.0000, resi 227 and name CA
show spheres, resi 228 and name CA
set sphere_scale, 0.0000, resi 228 and name CA
show spheres, resi 256 and name CA
set sphere_scale, 0.0000, resi 256 and name CA
show spheres, resi 261 and name CA
set sphere_scale, 0.0000, resi 261 and name CA
sele All_Spheres, resi 48+145+215+107+105+146+190+103+147+209+40+47+214+197+80+139+19+79+46+155+248+195+144+106+187+212+141+142+168+240+81+152+218+192+44+151+220+136+104+126+50+169+196+132+241+128+20+134+123+110+42+173+179+206+219+210+114+27+217+36+43+166+153+198+51+216+130+41+57+165+137+39+237+167+174+185+102+183+260+24+189+16+224+154+158+117+23+194+221+252+223+208+26+37+235+253+148+138+135+54+182+234+162+205+242+99+249+13+108+193+200+255+170+164+101+159+55+239+207+131+31+32+17+49+8+175+191+251+12+127+222+14+243+78+171+238+232+180+262+172+84+236+15+160+186+59+11+199+29+163+88+211+87+2+82+86+257+233+112+100+83+109+111+58+10+73+93+28+120+60+33+254+259+184+9+68+85+5+258+143+95+124+90+94+177+71+230+156+250+263+231+116+61+201+64+181+113+129+97+115+56+76+66+133+89+157+125+178+140+245+63+226+229+247+25+121+65+246+77+91+176+69+96+62+244+149+3+72+6+35+4+7+18+21+22+30+34+38+45+52+53+67+70+74+75+92+98+118+119+122+150+161+188+202+203+204+213+225+227+228+256+261 and name CA
