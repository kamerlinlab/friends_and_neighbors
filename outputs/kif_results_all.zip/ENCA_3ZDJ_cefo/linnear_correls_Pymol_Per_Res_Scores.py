# You can run me in several ways, perhaps the easiest way is to:
# 1. Load the PDB file of your system in PyMOL.
# 2. Type: @[FILE_NAME.py] in the command line.
# 3. Make sure the .py file is in the same directory as the pdb.
set sphere_color, red
# The lines below are suggestions for potentially nicer figures.
# You can comment them in if you want.
# bg_color white
# set cartoon_color, grey90
# set ray_opaque_background, 0
# set antialias, 2
# set ray_shadows, 0
show spheres, resi 103 and name CA
set sphere_scale, 1.0000, resi 103 and name CA
show spheres, resi 209 and name CA
set sphere_scale, 0.8944, resi 209 and name CA
show spheres, resi 48 and name CA
set sphere_scale, 0.6638, resi 48 and name CA
show spheres, resi 105 and name CA
set sphere_scale, 0.6137, resi 105 and name CA
show spheres, resi 80 and name CA
set sphere_scale, 0.5766, resi 80 and name CA
show spheres, resi 192 and name CA
set sphere_scale, 0.5745, resi 192 and name CA
show spheres, resi 40 and name CA
set sphere_scale, 0.5308, resi 40 and name CA
show spheres, resi 102 and name CA
set sphere_scale, 0.5241, resi 102 and name CA
show spheres, resi 195 and name CA
set sphere_scale, 0.5188, resi 195 and name CA
show spheres, resi 107 and name CA
set sphere_scale, 0.5086, resi 107 and name CA
show spheres, resi 146 and name CA
set sphere_scale, 0.5061, resi 146 and name CA
show spheres, resi 145 and name CA
set sphere_scale, 0.5048, resi 145 and name CA
show spheres, resi 47 and name CA
set sphere_scale, 0.4803, resi 47 and name CA
show spheres, resi 101 and name CA
set sphere_scale, 0.4588, resi 101 and name CA
show spheres, resi 215 and name CA
set sphere_scale, 0.4550, resi 215 and name CA
show spheres, resi 198 and name CA
set sphere_scale, 0.4226, resi 198 and name CA
show spheres, resi 182 and name CA
set sphere_scale, 0.4200, resi 182 and name CA
show spheres, resi 196 and name CA
set sphere_scale, 0.4161, resi 196 and name CA
show spheres, resi 141 and name CA
set sphere_scale, 0.4105, resi 141 and name CA
show spheres, resi 197 and name CA
set sphere_scale, 0.4077, resi 197 and name CA
show spheres, resi 104 and name CA
set sphere_scale, 0.3808, resi 104 and name CA
show spheres, resi 137 and name CA
set sphere_scale, 0.3694, resi 137 and name CA
show spheres, resi 117 and name CA
set sphere_scale, 0.3672, resi 117 and name CA
show spheres, resi 113 and name CA
set sphere_scale, 0.3661, resi 113 and name CA
show spheres, resi 168 and name CA
set sphere_scale, 0.3588, resi 168 and name CA
show spheres, resi 169 and name CA
set sphere_scale, 0.3567, resi 169 and name CA
show spheres, resi 194 and name CA
set sphere_scale, 0.3475, resi 194 and name CA
show spheres, resi 99 and name CA
set sphere_scale, 0.3423, resi 99 and name CA
show spheres, resi 20 and name CA
set sphere_scale, 0.3390, resi 20 and name CA
show spheres, resi 220 and name CA
set sphere_scale, 0.3319, resi 220 and name CA
show spheres, resi 134 and name CA
set sphere_scale, 0.3311, resi 134 and name CA
show spheres, resi 110 and name CA
set sphere_scale, 0.3202, resi 110 and name CA
show spheres, resi 214 and name CA
set sphere_scale, 0.3164, resi 214 and name CA
show spheres, resi 179 and name CA
set sphere_scale, 0.3142, resi 179 and name CA
show spheres, resi 51 and name CA
set sphere_scale, 0.3078, resi 51 and name CA
show spheres, resi 58 and name CA
set sphere_scale, 0.3039, resi 58 and name CA
show spheres, resi 23 and name CA
set sphere_scale, 0.3029, resi 23 and name CA
show spheres, resi 106 and name CA
set sphere_scale, 0.3023, resi 106 and name CA
show spheres, resi 166 and name CA
set sphere_scale, 0.3015, resi 166 and name CA
show spheres, resi 81 and name CA
set sphere_scale, 0.2987, resi 81 and name CA
show spheres, resi 116 and name CA
set sphere_scale, 0.2951, resi 116 and name CA
show spheres, resi 235 and name CA
set sphere_scale, 0.2893, resi 235 and name CA
show spheres, resi 155 and name CA
set sphere_scale, 0.2877, resi 155 and name CA
show spheres, resi 190 and name CA
set sphere_scale, 0.2858, resi 190 and name CA
show spheres, resi 189 and name CA
set sphere_scale, 0.2846, resi 189 and name CA
show spheres, resi 54 and name CA
set sphere_scale, 0.2824, resi 54 and name CA
show spheres, resi 139 and name CA
set sphere_scale, 0.2766, resi 139 and name CA
show spheres, resi 27 and name CA
set sphere_scale, 0.2742, resi 27 and name CA
show spheres, resi 223 and name CA
set sphere_scale, 0.2704, resi 223 and name CA
show spheres, resi 114 and name CA
set sphere_scale, 0.2693, resi 114 and name CA
show spheres, resi 165 and name CA
set sphere_scale, 0.2662, resi 165 and name CA
show spheres, resi 158 and name CA
set sphere_scale, 0.2660, resi 158 and name CA
show spheres, resi 185 and name CA
set sphere_scale, 0.2617, resi 185 and name CA
show spheres, resi 50 and name CA
set sphere_scale, 0.2557, resi 50 and name CA
show spheres, resi 255 and name CA
set sphere_scale, 0.2555, resi 255 and name CA
show spheres, resi 112 and name CA
set sphere_scale, 0.2500, resi 112 and name CA
show spheres, resi 252 and name CA
set sphere_scale, 0.2482, resi 252 and name CA
show spheres, resi 173 and name CA
set sphere_scale, 0.2482, resi 173 and name CA
show spheres, resi 16 and name CA
set sphere_scale, 0.2474, resi 16 and name CA
show spheres, resi 233 and name CA
set sphere_scale, 0.2451, resi 233 and name CA
show spheres, resi 49 and name CA
set sphere_scale, 0.2442, resi 49 and name CA
show spheres, resi 174 and name CA
set sphere_scale, 0.2419, resi 174 and name CA
show spheres, resi 153 and name CA
set sphere_scale, 0.2409, resi 153 and name CA
show spheres, resi 97 and name CA
set sphere_scale, 0.2344, resi 97 and name CA
show spheres, resi 240 and name CA
set sphere_scale, 0.2325, resi 240 and name CA
show spheres, resi 123 and name CA
set sphere_scale, 0.2302, resi 123 and name CA
show spheres, resi 221 and name CA
set sphere_scale, 0.2293, resi 221 and name CA
show spheres, resi 36 and name CA
set sphere_scale, 0.2255, resi 36 and name CA
show spheres, resi 41 and name CA
set sphere_scale, 0.2248, resi 41 and name CA
show spheres, resi 253 and name CA
set sphere_scale, 0.2239, resi 253 and name CA
show spheres, resi 162 and name CA
set sphere_scale, 0.2223, resi 162 and name CA
show spheres, resi 66 and name CA
set sphere_scale, 0.2160, resi 66 and name CA
show spheres, resi 55 and name CA
set sphere_scale, 0.2129, resi 55 and name CA
show spheres, resi 126 and name CA
set sphere_scale, 0.2117, resi 126 and name CA
show spheres, resi 46 and name CA
set sphere_scale, 0.2116, resi 46 and name CA
show spheres, resi 57 and name CA
set sphere_scale, 0.2074, resi 57 and name CA
show spheres, resi 183 and name CA
set sphere_scale, 0.2070, resi 183 and name CA
show spheres, resi 19 and name CA
set sphere_scale, 0.2047, resi 19 and name CA
show spheres, resi 109 and name CA
set sphere_scale, 0.2027, resi 109 and name CA
show spheres, resi 42 and name CA
set sphere_scale, 0.1994, resi 42 and name CA
show spheres, resi 237 and name CA
set sphere_scale, 0.1981, resi 237 and name CA
show spheres, resi 2 and name CA
set sphere_scale, 0.1954, resi 2 and name CA
show spheres, resi 218 and name CA
set sphere_scale, 0.1945, resi 218 and name CA
show spheres, resi 43 and name CA
set sphere_scale, 0.1918, resi 43 and name CA
show spheres, resi 128 and name CA
set sphere_scale, 0.1838, resi 128 and name CA
show spheres, resi 258 and name CA
set sphere_scale, 0.1824, resi 258 and name CA
show spheres, resi 39 and name CA
set sphere_scale, 0.1810, resi 39 and name CA
show spheres, resi 222 and name CA
set sphere_scale, 0.1730, resi 222 and name CA
show spheres, resi 238 and name CA
set sphere_scale, 0.1719, resi 238 and name CA
show spheres, resi 254 and name CA
set sphere_scale, 0.1718, resi 254 and name CA
show spheres, resi 191 and name CA
set sphere_scale, 0.1712, resi 191 and name CA
show spheres, resi 206 and name CA
set sphere_scale, 0.1678, resi 206 and name CA
show spheres, resi 9 and name CA
set sphere_scale, 0.1673, resi 9 and name CA
show spheres, resi 175 and name CA
set sphere_scale, 0.1670, resi 175 and name CA
show spheres, resi 193 and name CA
set sphere_scale, 0.1662, resi 193 and name CA
show spheres, resi 247 and name CA
set sphere_scale, 0.1660, resi 247 and name CA
show spheres, resi 26 and name CA
set sphere_scale, 0.1643, resi 26 and name CA
show spheres, resi 79 and name CA
set sphere_scale, 0.1634, resi 79 and name CA
show spheres, resi 124 and name CA
set sphere_scale, 0.1623, resi 124 and name CA
show spheres, resi 111 and name CA
set sphere_scale, 0.1584, resi 111 and name CA
show spheres, resi 130 and name CA
set sphere_scale, 0.1552, resi 130 and name CA
show spheres, resi 167 and name CA
set sphere_scale, 0.1551, resi 167 and name CA
show spheres, resi 120 and name CA
set sphere_scale, 0.1489, resi 120 and name CA
show spheres, resi 160 and name CA
set sphere_scale, 0.1478, resi 160 and name CA
show spheres, resi 151 and name CA
set sphere_scale, 0.1475, resi 151 and name CA
show spheres, resi 248 and name CA
set sphere_scale, 0.1470, resi 248 and name CA
show spheres, resi 207 and name CA
set sphere_scale, 0.1460, resi 207 and name CA
show spheres, resi 15 and name CA
set sphere_scale, 0.1443, resi 15 and name CA
show spheres, resi 251 and name CA
set sphere_scale, 0.1435, resi 251 and name CA
show spheres, resi 127 and name CA
set sphere_scale, 0.1431, resi 127 and name CA
show spheres, resi 242 and name CA
set sphere_scale, 0.1389, resi 242 and name CA
show spheres, resi 147 and name CA
set sphere_scale, 0.1358, resi 147 and name CA
show spheres, resi 241 and name CA
set sphere_scale, 0.1348, resi 241 and name CA
show spheres, resi 234 and name CA
set sphere_scale, 0.1345, resi 234 and name CA
show spheres, resi 205 and name CA
set sphere_scale, 0.1298, resi 205 and name CA
show spheres, resi 59 and name CA
set sphere_scale, 0.1280, resi 59 and name CA
show spheres, resi 188 and name CA
set sphere_scale, 0.1272, resi 188 and name CA
show spheres, resi 239 and name CA
set sphere_scale, 0.1272, resi 239 and name CA
show spheres, resi 95 and name CA
set sphere_scale, 0.1268, resi 95 and name CA
show spheres, resi 8 and name CA
set sphere_scale, 0.1245, resi 8 and name CA
show spheres, resi 13 and name CA
set sphere_scale, 0.1240, resi 13 and name CA
show spheres, resi 25 and name CA
set sphere_scale, 0.1230, resi 25 and name CA
show spheres, resi 132 and name CA
set sphere_scale, 0.1218, resi 132 and name CA
show spheres, resi 152 and name CA
set sphere_scale, 0.1213, resi 152 and name CA
show spheres, resi 93 and name CA
set sphere_scale, 0.1204, resi 93 and name CA
show spheres, resi 136 and name CA
set sphere_scale, 0.1159, resi 136 and name CA
show spheres, resi 187 and name CA
set sphere_scale, 0.1150, resi 187 and name CA
show spheres, resi 71 and name CA
set sphere_scale, 0.1139, resi 71 and name CA
show spheres, resi 33 and name CA
set sphere_scale, 0.1132, resi 33 and name CA
show spheres, resi 3 and name CA
set sphere_scale, 0.1124, resi 3 and name CA
show spheres, resi 224 and name CA
set sphere_scale, 0.1112, resi 224 and name CA
show spheres, resi 260 and name CA
set sphere_scale, 0.1107, resi 260 and name CA
show spheres, resi 164 and name CA
set sphere_scale, 0.1090, resi 164 and name CA
show spheres, resi 94 and name CA
set sphere_scale, 0.1083, resi 94 and name CA
show spheres, resi 29 and name CA
set sphere_scale, 0.1080, resi 29 and name CA
show spheres, resi 159 and name CA
set sphere_scale, 0.1068, resi 159 and name CA
show spheres, resi 249 and name CA
set sphere_scale, 0.1064, resi 249 and name CA
show spheres, resi 135 and name CA
set sphere_scale, 0.1063, resi 135 and name CA
show spheres, resi 257 and name CA
set sphere_scale, 0.1045, resi 257 and name CA
show spheres, resi 236 and name CA
set sphere_scale, 0.1045, resi 236 and name CA
show spheres, resi 100 and name CA
set sphere_scale, 0.1026, resi 100 and name CA
show spheres, resi 17 and name CA
set sphere_scale, 0.1024, resi 17 and name CA
show spheres, resi 85 and name CA
set sphere_scale, 0.1021, resi 85 and name CA
show spheres, resi 121 and name CA
set sphere_scale, 0.1013, resi 121 and name CA
show spheres, resi 37 and name CA
set sphere_scale, 0.1013, resi 37 and name CA
show spheres, resi 6 and name CA
set sphere_scale, 0.1007, resi 6 and name CA
show spheres, resi 211 and name CA
set sphere_scale, 0.1004, resi 211 and name CA
show spheres, resi 56 and name CA
set sphere_scale, 0.0995, resi 56 and name CA
show spheres, resi 60 and name CA
set sphere_scale, 0.0974, resi 60 and name CA
show spheres, resi 259 and name CA
set sphere_scale, 0.0952, resi 259 and name CA
show spheres, resi 142 and name CA
set sphere_scale, 0.0947, resi 142 and name CA
show spheres, resi 163 and name CA
set sphere_scale, 0.0939, resi 163 and name CA
show spheres, resi 125 and name CA
set sphere_scale, 0.0937, resi 125 and name CA
show spheres, resi 199 and name CA
set sphere_scale, 0.0894, resi 199 and name CA
show spheres, resi 83 and name CA
set sphere_scale, 0.0858, resi 83 and name CA
show spheres, resi 216 and name CA
set sphere_scale, 0.0837, resi 216 and name CA
show spheres, resi 230 and name CA
set sphere_scale, 0.0824, resi 230 and name CA
show spheres, resi 172 and name CA
set sphere_scale, 0.0808, resi 172 and name CA
show spheres, resi 243 and name CA
set sphere_scale, 0.0795, resi 243 and name CA
show spheres, resi 250 and name CA
set sphere_scale, 0.0790, resi 250 and name CA
show spheres, resi 144 and name CA
set sphere_scale, 0.0784, resi 144 and name CA
show spheres, resi 10 and name CA
set sphere_scale, 0.0783, resi 10 and name CA
show spheres, resi 11 and name CA
set sphere_scale, 0.0783, resi 11 and name CA
show spheres, resi 217 and name CA
set sphere_scale, 0.0774, resi 217 and name CA
show spheres, resi 186 and name CA
set sphere_scale, 0.0769, resi 186 and name CA
show spheres, resi 12 and name CA
set sphere_scale, 0.0768, resi 12 and name CA
show spheres, resi 154 and name CA
set sphere_scale, 0.0748, resi 154 and name CA
show spheres, resi 129 and name CA
set sphere_scale, 0.0745, resi 129 and name CA
show spheres, resi 24 and name CA
set sphere_scale, 0.0720, resi 24 and name CA
show spheres, resi 131 and name CA
set sphere_scale, 0.0704, resi 131 and name CA
show spheres, resi 87 and name CA
set sphere_scale, 0.0678, resi 87 and name CA
show spheres, resi 170 and name CA
set sphere_scale, 0.0668, resi 170 and name CA
show spheres, resi 65 and name CA
set sphere_scale, 0.0644, resi 65 and name CA
show spheres, resi 31 and name CA
set sphere_scale, 0.0639, resi 31 and name CA
show spheres, resi 178 and name CA
set sphere_scale, 0.0625, resi 178 and name CA
show spheres, resi 68 and name CA
set sphere_scale, 0.0612, resi 68 and name CA
show spheres, resi 28 and name CA
set sphere_scale, 0.0610, resi 28 and name CA
show spheres, resi 64 and name CA
set sphere_scale, 0.0609, resi 64 and name CA
show spheres, resi 180 and name CA
set sphere_scale, 0.0597, resi 180 and name CA
show spheres, resi 89 and name CA
set sphere_scale, 0.0595, resi 89 and name CA
show spheres, resi 14 and name CA
set sphere_scale, 0.0588, resi 14 and name CA
show spheres, resi 63 and name CA
set sphere_scale, 0.0587, resi 63 and name CA
show spheres, resi 35 and name CA
set sphere_scale, 0.0583, resi 35 and name CA
show spheres, resi 108 and name CA
set sphere_scale, 0.0558, resi 108 and name CA
show spheres, resi 7 and name CA
set sphere_scale, 0.0558, resi 7 and name CA
show spheres, resi 70 and name CA
set sphere_scale, 0.0542, resi 70 and name CA
show spheres, resi 5 and name CA
set sphere_scale, 0.0535, resi 5 and name CA
show spheres, resi 208 and name CA
set sphere_scale, 0.0530, resi 208 and name CA
show spheres, resi 232 and name CA
set sphere_scale, 0.0506, resi 232 and name CA
show spheres, resi 78 and name CA
set sphere_scale, 0.0500, resi 78 and name CA
show spheres, resi 4 and name CA
set sphere_scale, 0.0475, resi 4 and name CA
show spheres, resi 200 and name CA
set sphere_scale, 0.0465, resi 200 and name CA
show spheres, resi 156 and name CA
set sphere_scale, 0.0459, resi 156 and name CA
show spheres, resi 88 and name CA
set sphere_scale, 0.0440, resi 88 and name CA
show spheres, resi 176 and name CA
set sphere_scale, 0.0435, resi 176 and name CA
show spheres, resi 212 and name CA
set sphere_scale, 0.0411, resi 212 and name CA
show spheres, resi 157 and name CA
set sphere_scale, 0.0395, resi 157 and name CA
show spheres, resi 138 and name CA
set sphere_scale, 0.0394, resi 138 and name CA
show spheres, resi 84 and name CA
set sphere_scale, 0.0390, resi 84 and name CA
show spheres, resi 73 and name CA
set sphere_scale, 0.0366, resi 73 and name CA
show spheres, resi 76 and name CA
set sphere_scale, 0.0366, resi 76 and name CA
show spheres, resi 201 and name CA
set sphere_scale, 0.0357, resi 201 and name CA
show spheres, resi 115 and name CA
set sphere_scale, 0.0352, resi 115 and name CA
show spheres, resi 245 and name CA
set sphere_scale, 0.0320, resi 245 and name CA
show spheres, resi 184 and name CA
set sphere_scale, 0.0315, resi 184 and name CA
show spheres, resi 261 and name CA
set sphere_scale, 0.0315, resi 261 and name CA
show spheres, resi 181 and name CA
set sphere_scale, 0.0282, resi 181 and name CA
show spheres, resi 210 and name CA
set sphere_scale, 0.0280, resi 210 and name CA
show spheres, resi 90 and name CA
set sphere_scale, 0.0272, resi 90 and name CA
show spheres, resi 62 and name CA
set sphere_scale, 0.0215, resi 62 and name CA
show spheres, resi 22 and name CA
set sphere_scale, 0.0205, resi 22 and name CA
show spheres, resi 34 and name CA
set sphere_scale, 0.0205, resi 34 and name CA
show spheres, resi 262 and name CA
set sphere_scale, 0.0177, resi 262 and name CA
show spheres, resi 133 and name CA
set sphere_scale, 0.0168, resi 133 and name CA
show spheres, resi 72 and name CA
set sphere_scale, 0.0167, resi 72 and name CA
show spheres, resi 246 and name CA
set sphere_scale, 0.0165, resi 246 and name CA
show spheres, resi 67 and name CA
set sphere_scale, 0.0160, resi 67 and name CA
show spheres, resi 143 and name CA
set sphere_scale, 0.0156, resi 143 and name CA
show spheres, resi 86 and name CA
set sphere_scale, 0.0148, resi 86 and name CA
show spheres, resi 244 and name CA
set sphere_scale, 0.0147, resi 244 and name CA
show spheres, resi 177 and name CA
set sphere_scale, 0.0128, resi 177 and name CA
show spheres, resi 263 and name CA
set sphere_scale, 0.0118, resi 263 and name CA
show spheres, resi 61 and name CA
set sphere_scale, 0.0112, resi 61 and name CA
show spheres, resi 171 and name CA
set sphere_scale, 0.0107, resi 171 and name CA
show spheres, resi 96 and name CA
set sphere_scale, 0.0103, resi 96 and name CA
show spheres, resi 91 and name CA
set sphere_scale, 0.0101, resi 91 and name CA
show spheres, resi 32 and name CA
set sphere_scale, 0.0089, resi 32 and name CA
show spheres, resi 226 and name CA
set sphere_scale, 0.0081, resi 226 and name CA
show spheres, resi 229 and name CA
set sphere_scale, 0.0081, resi 229 and name CA
show spheres, resi 69 and name CA
set sphere_scale, 0.0072, resi 69 and name CA
show spheres, resi 38 and name CA
set sphere_scale, 0.0044, resi 38 and name CA
show spheres, resi 82 and name CA
set sphere_scale, 0.0034, resi 82 and name CA
show spheres, resi 231 and name CA
set sphere_scale, 0.0031, resi 231 and name CA
show spheres, resi 148 and name CA
set sphere_scale, 0.0029, resi 148 and name CA
show spheres, resi 77 and name CA
set sphere_scale, 0.0011, resi 77 and name CA
show spheres, resi 18 and name CA
set sphere_scale, 0.0000, resi 18 and name CA
show spheres, resi 21 and name CA
set sphere_scale, 0.0000, resi 21 and name CA
show spheres, resi 30 and name CA
set sphere_scale, 0.0000, resi 30 and name CA
show spheres, resi 44 and name CA
set sphere_scale, 0.0000, resi 44 and name CA
show spheres, resi 45 and name CA
set sphere_scale, 0.0000, resi 45 and name CA
show spheres, resi 52 and name CA
set sphere_scale, 0.0000, resi 52 and name CA
show spheres, resi 53 and name CA
set sphere_scale, 0.0000, resi 53 and name CA
show spheres, resi 74 and name CA
set sphere_scale, 0.0000, resi 74 and name CA
show spheres, resi 75 and name CA
set sphere_scale, 0.0000, resi 75 and name CA
show spheres, resi 92 and name CA
set sphere_scale, 0.0000, resi 92 and name CA
show spheres, resi 98 and name CA
set sphere_scale, 0.0000, resi 98 and name CA
show spheres, resi 118 and name CA
set sphere_scale, 0.0000, resi 118 and name CA
show spheres, resi 119 and name CA
set sphere_scale, 0.0000, resi 119 and name CA
show spheres, resi 122 and name CA
set sphere_scale, 0.0000, resi 122 and name CA
show spheres, resi 140 and name CA
set sphere_scale, 0.0000, resi 140 and name CA
show spheres, resi 149 and name CA
set sphere_scale, 0.0000, resi 149 and name CA
show spheres, resi 150 and name CA
set sphere_scale, 0.0000, resi 150 and name CA
show spheres, resi 161 and name CA
set sphere_scale, 0.0000, resi 161 and name CA
show spheres, resi 202 and name CA
set sphere_scale, 0.0000, resi 202 and name CA
show spheres, resi 203 and name CA
set sphere_scale, 0.0000, resi 203 and name CA
show spheres, resi 204 and name CA
set sphere_scale, 0.0000, resi 204 and name CA
show spheres, resi 213 and name CA
set sphere_scale, 0.0000, resi 213 and name CA
show spheres, resi 219 and name CA
set sphere_scale, 0.0000, resi 219 and name CA
show spheres, resi 225 and name CA
set sphere_scale, 0.0000, resi 225 and name CA
show spheres, resi 227 and name CA
set sphere_scale, 0.0000, resi 227 and name CA
show spheres, resi 228 and name CA
set sphere_scale, 0.0000, resi 228 and name CA
show spheres, resi 256 and name CA
set sphere_scale, 0.0000, resi 256 and name CA
sele All_Spheres, resi 103+209+48+105+80+192+40+102+195+107+146+145+47+101+215+198+182+196+141+197+104+137+117+113+168+169+194+99+20+220+134+110+214+179+51+58+23+106+166+81+116+235+155+190+189+54+139+27+223+114+165+158+185+50+255+112+252+173+16+233+49+174+153+97+240+123+221+36+41+253+162+66+55+126+46+57+183+19+109+42+237+2+218+43+128+258+39+222+238+254+191+206+9+175+193+247+26+79+124+111+130+167+120+160+151+248+207+15+251+127+242+147+241+234+205+59+188+239+95+8+13+25+132+152+93+136+187+71+33+3+224+260+164+94+29+159+249+135+257+236+100+17+85+121+37+6+211+56+60+259+142+163+125+199+83+216+230+172+243+250+144+10+11+217+186+12+154+129+24+131+87+170+65+31+178+68+28+64+180+89+14+63+35+108+7+70+5+208+232+78+4+200+156+88+176+212+157+138+84+73+76+201+115+245+184+261+181+210+90+62+22+34+262+133+72+246+67+143+86+244+177+263+61+171+96+91+32+226+229+69+38+82+231+148+77+18+21+30+44+45+52+53+74+75+92+98+118+119+122+140+149+150+161+202+203+204+213+219+225+227+228+256 and name CA
