# You can run me in several ways, perhaps the easiest way is to:
# 1. Load the PDB file of your system in PyMOL.
# 2. Type: @[FILE_NAME.py] in the command line.
# 3. Make sure the .py file is in the same directory as the pdb.
set sphere_color, red
# The lines below are suggestions for potentially nicer figures.
# You can comment them in if you want.
# bg_color white
# set cartoon_color, grey90
# set ray_opaque_background, 0
# set antialias, 2
# set ray_shadows, 0
show spheres, resi 193 and name CA
set sphere_scale, 1.0000, resi 193 and name CA
show spheres, resi 45 and name CA
set sphere_scale, 0.9842, resi 45 and name CA
show spheres, resi 245 and name CA
set sphere_scale, 0.9515, resi 245 and name CA
show spheres, resi 104 and name CA
set sphere_scale, 0.8523, resi 104 and name CA
show spheres, resi 186 and name CA
set sphere_scale, 0.7899, resi 186 and name CA
show spheres, resi 206 and name CA
set sphere_scale, 0.7550, resi 206 and name CA
show spheres, resi 102 and name CA
set sphere_scale, 0.7089, resi 102 and name CA
show spheres, resi 103 and name CA
set sphere_scale, 0.6914, resi 103 and name CA
show spheres, resi 78 and name CA
set sphere_scale, 0.6587, resi 78 and name CA
show spheres, resi 231 and name CA
set sphere_scale, 0.6425, resi 231 and name CA
show spheres, resi 232 and name CA
set sphere_scale, 0.6319, resi 232 and name CA
show spheres, resi 192 and name CA
set sphere_scale, 0.5991, resi 192 and name CA
show spheres, resi 246 and name CA
set sphere_scale, 0.5652, resi 246 and name CA
show spheres, resi 252 and name CA
set sphere_scale, 0.5264, resi 252 and name CA
show spheres, resi 215 and name CA
set sphere_scale, 0.5180, resi 215 and name CA
show spheres, resi 44 and name CA
set sphere_scale, 0.5049, resi 44 and name CA
show spheres, resi 20 and name CA
set sphere_scale, 0.4969, resi 20 and name CA
show spheres, resi 188 and name CA
set sphere_scale, 0.4958, resi 188 and name CA
show spheres, resi 207 and name CA
set sphere_scale, 0.4889, resi 207 and name CA
show spheres, resi 98 and name CA
set sphere_scale, 0.4460, resi 98 and name CA
show spheres, resi 209 and name CA
set sphere_scale, 0.4415, resi 209 and name CA
show spheres, resi 97 and name CA
set sphere_scale, 0.4248, resi 97 and name CA
show spheres, resi 162 and name CA
set sphere_scale, 0.4201, resi 162 and name CA
show spheres, resi 256 and name CA
set sphere_scale, 0.4106, resi 256 and name CA
show spheres, resi 259 and name CA
set sphere_scale, 0.3984, resi 259 and name CA
show spheres, resi 101 and name CA
set sphere_scale, 0.3910, resi 101 and name CA
show spheres, resi 205 and name CA
set sphere_scale, 0.3904, resi 205 and name CA
show spheres, resi 234 and name CA
set sphere_scale, 0.3775, resi 234 and name CA
show spheres, resi 217 and name CA
set sphere_scale, 0.3774, resi 217 and name CA
show spheres, resi 260 and name CA
set sphere_scale, 0.3739, resi 260 and name CA
show spheres, resi 138 and name CA
set sphere_scale, 0.3725, resi 138 and name CA
show spheres, resi 187 and name CA
set sphere_scale, 0.3724, resi 187 and name CA
show spheres, resi 216 and name CA
set sphere_scale, 0.3688, resi 216 and name CA
show spheres, resi 230 and name CA
set sphere_scale, 0.3634, resi 230 and name CA
show spheres, resi 46 and name CA
set sphere_scale, 0.3609, resi 46 and name CA
show spheres, resi 9 and name CA
set sphere_scale, 0.3562, resi 9 and name CA
show spheres, resi 248 and name CA
set sphere_scale, 0.3539, resi 248 and name CA
show spheres, resi 179 and name CA
set sphere_scale, 0.3446, resi 179 and name CA
show spheres, resi 99 and name CA
set sphere_scale, 0.3424, resi 99 and name CA
show spheres, resi 76 and name CA
set sphere_scale, 0.3387, resi 76 and name CA
show spheres, resi 194 and name CA
set sphere_scale, 0.3352, resi 194 and name CA
show spheres, resi 229 and name CA
set sphere_scale, 0.3311, resi 229 and name CA
show spheres, resi 110 and name CA
set sphere_scale, 0.3285, resi 110 and name CA
show spheres, resi 100 and name CA
set sphere_scale, 0.3145, resi 100 and name CA
show spheres, resi 159 and name CA
set sphere_scale, 0.3141, resi 159 and name CA
show spheres, resi 155 and name CA
set sphere_scale, 0.3105, resi 155 and name CA
show spheres, resi 43 and name CA
set sphere_scale, 0.3101, resi 43 and name CA
show spheres, resi 6 and name CA
set sphere_scale, 0.3062, resi 6 and name CA
show spheres, resi 254 and name CA
set sphere_scale, 0.3044, resi 254 and name CA
show spheres, resi 250 and name CA
set sphere_scale, 0.3022, resi 250 and name CA
show spheres, resi 77 and name CA
set sphere_scale, 0.2917, resi 77 and name CA
show spheres, resi 221 and name CA
set sphere_scale, 0.2901, resi 221 and name CA
show spheres, resi 16 and name CA
set sphere_scale, 0.2775, resi 16 and name CA
show spheres, resi 2 and name CA
set sphere_scale, 0.2773, resi 2 and name CA
show spheres, resi 233 and name CA
set sphere_scale, 0.2771, resi 233 and name CA
show spheres, resi 203 and name CA
set sphere_scale, 0.2716, resi 203 and name CA
show spheres, resi 183 and name CA
set sphere_scale, 0.2665, resi 183 and name CA
show spheres, resi 13 and name CA
set sphere_scale, 0.2629, resi 13 and name CA
show spheres, resi 191 and name CA
set sphere_scale, 0.2606, resi 191 and name CA
show spheres, resi 218 and name CA
set sphere_scale, 0.2537, resi 218 and name CA
show spheres, resi 190 and name CA
set sphere_scale, 0.2499, resi 190 and name CA
show spheres, resi 125 and name CA
set sphere_scale, 0.2491, resi 125 and name CA
show spheres, resi 244 and name CA
set sphere_scale, 0.2487, resi 244 and name CA
show spheres, resi 219 and name CA
set sphere_scale, 0.2486, resi 219 and name CA
show spheres, resi 120 and name CA
set sphere_scale, 0.2453, resi 120 and name CA
show spheres, resi 21 and name CA
set sphere_scale, 0.2442, resi 21 and name CA
show spheres, resi 37 and name CA
set sphere_scale, 0.2399, resi 37 and name CA
show spheres, resi 105 and name CA
set sphere_scale, 0.2365, resi 105 and name CA
show spheres, resi 251 and name CA
set sphere_scale, 0.2299, resi 251 and name CA
show spheres, resi 80 and name CA
set sphere_scale, 0.2298, resi 80 and name CA
show spheres, resi 243 and name CA
set sphere_scale, 0.2236, resi 243 and name CA
show spheres, resi 249 and name CA
set sphere_scale, 0.2185, resi 249 and name CA
show spheres, resi 75 and name CA
set sphere_scale, 0.2171, resi 75 and name CA
show spheres, resi 17 and name CA
set sphere_scale, 0.2113, resi 17 and name CA
show spheres, resi 108 and name CA
set sphere_scale, 0.2106, resi 108 and name CA
show spheres, resi 255 and name CA
set sphere_scale, 0.2099, resi 255 and name CA
show spheres, resi 156 and name CA
set sphere_scale, 0.2042, resi 156 and name CA
show spheres, resi 167 and name CA
set sphere_scale, 0.2003, resi 167 and name CA
show spheres, resi 213 and name CA
set sphere_scale, 0.1992, resi 213 and name CA
show spheres, resi 106 and name CA
set sphere_scale, 0.1973, resi 106 and name CA
show spheres, resi 111 and name CA
set sphere_scale, 0.1958, resi 111 and name CA
show spheres, resi 197 and name CA
set sphere_scale, 0.1922, resi 197 and name CA
show spheres, resi 240 and name CA
set sphere_scale, 0.1910, resi 240 and name CA
show spheres, resi 51 and name CA
set sphere_scale, 0.1892, resi 51 and name CA
show spheres, resi 195 and name CA
set sphere_scale, 0.1890, resi 195 and name CA
show spheres, resi 212 and name CA
set sphere_scale, 0.1887, resi 212 and name CA
show spheres, resi 28 and name CA
set sphere_scale, 0.1823, resi 28 and name CA
show spheres, resi 142 and name CA
set sphere_scale, 0.1818, resi 142 and name CA
show spheres, resi 238 and name CA
set sphere_scale, 0.1815, resi 238 and name CA
show spheres, resi 114 and name CA
set sphere_scale, 0.1798, resi 114 and name CA
show spheres, resi 141 and name CA
set sphere_scale, 0.1779, resi 141 and name CA
show spheres, resi 228 and name CA
set sphere_scale, 0.1742, resi 228 and name CA
show spheres, resi 165 and name CA
set sphere_scale, 0.1727, resi 165 and name CA
show spheres, resi 47 and name CA
set sphere_scale, 0.1719, resi 47 and name CA
show spheres, resi 94 and name CA
set sphere_scale, 0.1712, resi 94 and name CA
show spheres, resi 12 and name CA
set sphere_scale, 0.1706, resi 12 and name CA
show spheres, resi 10 and name CA
set sphere_scale, 0.1616, resi 10 and name CA
show spheres, resi 127 and name CA
set sphere_scale, 0.1604, resi 127 and name CA
show spheres, resi 19 and name CA
set sphere_scale, 0.1593, resi 19 and name CA
show spheres, resi 223 and name CA
set sphere_scale, 0.1567, resi 223 and name CA
show spheres, resi 176 and name CA
set sphere_scale, 0.1554, resi 176 and name CA
show spheres, resi 208 and name CA
set sphere_scale, 0.1535, resi 208 and name CA
show spheres, resi 241 and name CA
set sphere_scale, 0.1479, resi 241 and name CA
show spheres, resi 48 and name CA
set sphere_scale, 0.1449, resi 48 and name CA
show spheres, resi 5 and name CA
set sphere_scale, 0.1401, resi 5 and name CA
show spheres, resi 31 and name CA
set sphere_scale, 0.1391, resi 31 and name CA
show spheres, resi 226 and name CA
set sphere_scale, 0.1385, resi 226 and name CA
show spheres, resi 49 and name CA
set sphere_scale, 0.1353, resi 49 and name CA
show spheres, resi 134 and name CA
set sphere_scale, 0.1350, resi 134 and name CA
show spheres, resi 54 and name CA
set sphere_scale, 0.1326, resi 54 and name CA
show spheres, resi 52 and name CA
set sphere_scale, 0.1313, resi 52 and name CA
show spheres, resi 53 and name CA
set sphere_scale, 0.1275, resi 53 and name CA
show spheres, resi 257 and name CA
set sphere_scale, 0.1274, resi 257 and name CA
show spheres, resi 247 and name CA
set sphere_scale, 0.1266, resi 247 and name CA
show spheres, resi 139 and name CA
set sphere_scale, 0.1236, resi 139 and name CA
show spheres, resi 79 and name CA
set sphere_scale, 0.1216, resi 79 and name CA
show spheres, resi 131 and name CA
set sphere_scale, 0.1212, resi 131 and name CA
show spheres, resi 166 and name CA
set sphere_scale, 0.1198, resi 166 and name CA
show spheres, resi 143 and name CA
set sphere_scale, 0.1189, resi 143 and name CA
show spheres, resi 55 and name CA
set sphere_scale, 0.1187, resi 55 and name CA
show spheres, resi 30 and name CA
set sphere_scale, 0.1160, resi 30 and name CA
show spheres, resi 123 and name CA
set sphere_scale, 0.1144, resi 123 and name CA
show spheres, resi 83 and name CA
set sphere_scale, 0.1143, resi 83 and name CA
show spheres, resi 214 and name CA
set sphere_scale, 0.1126, resi 214 and name CA
show spheres, resi 258 and name CA
set sphere_scale, 0.1093, resi 258 and name CA
show spheres, resi 196 and name CA
set sphere_scale, 0.1077, resi 196 and name CA
show spheres, resi 8 and name CA
set sphere_scale, 0.1068, resi 8 and name CA
show spheres, resi 40 and name CA
set sphere_scale, 0.1064, resi 40 and name CA
show spheres, resi 109 and name CA
set sphere_scale, 0.1057, resi 109 and name CA
show spheres, resi 144 and name CA
set sphere_scale, 0.1048, resi 144 and name CA
show spheres, resi 239 and name CA
set sphere_scale, 0.1042, resi 239 and name CA
show spheres, resi 107 and name CA
set sphere_scale, 0.1037, resi 107 and name CA
show spheres, resi 33 and name CA
set sphere_scale, 0.1035, resi 33 and name CA
show spheres, resi 36 and name CA
set sphere_scale, 0.1024, resi 36 and name CA
show spheres, resi 164 and name CA
set sphere_scale, 0.1018, resi 164 and name CA
show spheres, resi 22 and name CA
set sphere_scale, 0.0931, resi 22 and name CA
show spheres, resi 220 and name CA
set sphere_scale, 0.0918, resi 220 and name CA
show spheres, resi 96 and name CA
set sphere_scale, 0.0880, resi 96 and name CA
show spheres, resi 14 and name CA
set sphere_scale, 0.0862, resi 14 and name CA
show spheres, resi 68 and name CA
set sphere_scale, 0.0862, resi 68 and name CA
show spheres, resi 227 and name CA
set sphere_scale, 0.0860, resi 227 and name CA
show spheres, resi 81 and name CA
set sphere_scale, 0.0857, resi 81 and name CA
show spheres, resi 236 and name CA
set sphere_scale, 0.0848, resi 236 and name CA
show spheres, resi 163 and name CA
set sphere_scale, 0.0840, resi 163 and name CA
show spheres, resi 23 and name CA
set sphere_scale, 0.0804, resi 23 and name CA
show spheres, resi 86 and name CA
set sphere_scale, 0.0782, resi 86 and name CA
show spheres, resi 136 and name CA
set sphere_scale, 0.0765, resi 136 and name CA
show spheres, resi 237 and name CA
set sphere_scale, 0.0763, resi 237 and name CA
show spheres, resi 3 and name CA
set sphere_scale, 0.0756, resi 3 and name CA
show spheres, resi 157 and name CA
set sphere_scale, 0.0712, resi 157 and name CA
show spheres, resi 184 and name CA
set sphere_scale, 0.0708, resi 184 and name CA
show spheres, resi 87 and name CA
set sphere_scale, 0.0707, resi 87 and name CA
show spheres, resi 160 and name CA
set sphere_scale, 0.0707, resi 160 and name CA
show spheres, resi 50 and name CA
set sphere_scale, 0.0700, resi 50 and name CA
show spheres, resi 129 and name CA
set sphere_scale, 0.0683, resi 129 and name CA
show spheres, resi 171 and name CA
set sphere_scale, 0.0676, resi 171 and name CA
show spheres, resi 132 and name CA
set sphere_scale, 0.0673, resi 132 and name CA
show spheres, resi 56 and name CA
set sphere_scale, 0.0651, resi 56 and name CA
show spheres, resi 130 and name CA
set sphere_scale, 0.0647, resi 130 and name CA
show spheres, resi 119 and name CA
set sphere_scale, 0.0633, resi 119 and name CA
show spheres, resi 177 and name CA
set sphere_scale, 0.0631, resi 177 and name CA
show spheres, resi 63 and name CA
set sphere_scale, 0.0628, resi 63 and name CA
show spheres, resi 242 and name CA
set sphere_scale, 0.0623, resi 242 and name CA
show spheres, resi 38 and name CA
set sphere_scale, 0.0621, resi 38 and name CA
show spheres, resi 128 and name CA
set sphere_scale, 0.0615, resi 128 and name CA
show spheres, resi 11 and name CA
set sphere_scale, 0.0610, resi 11 and name CA
show spheres, resi 25 and name CA
set sphere_scale, 0.0610, resi 25 and name CA
show spheres, resi 235 and name CA
set sphere_scale, 0.0609, resi 235 and name CA
show spheres, resi 152 and name CA
set sphere_scale, 0.0578, resi 152 and name CA
show spheres, resi 175 and name CA
set sphere_scale, 0.0566, resi 175 and name CA
show spheres, resi 91 and name CA
set sphere_scale, 0.0558, resi 91 and name CA
show spheres, resi 113 and name CA
set sphere_scale, 0.0557, resi 113 and name CA
show spheres, resi 182 and name CA
set sphere_scale, 0.0556, resi 182 and name CA
show spheres, resi 121 and name CA
set sphere_scale, 0.0552, resi 121 and name CA
show spheres, resi 39 and name CA
set sphere_scale, 0.0537, resi 39 and name CA
show spheres, resi 66 and name CA
set sphere_scale, 0.0529, resi 66 and name CA
show spheres, resi 29 and name CA
set sphere_scale, 0.0515, resi 29 and name CA
show spheres, resi 150 and name CA
set sphere_scale, 0.0503, resi 150 and name CA
show spheres, resi 154 and name CA
set sphere_scale, 0.0499, resi 154 and name CA
show spheres, resi 181 and name CA
set sphere_scale, 0.0470, resi 181 and name CA
show spheres, resi 161 and name CA
set sphere_scale, 0.0457, resi 161 and name CA
show spheres, resi 122 and name CA
set sphere_scale, 0.0455, resi 122 and name CA
show spheres, resi 211 and name CA
set sphere_scale, 0.0454, resi 211 and name CA
show spheres, resi 170 and name CA
set sphere_scale, 0.0451, resi 170 and name CA
show spheres, resi 34 and name CA
set sphere_scale, 0.0450, resi 34 and name CA
show spheres, resi 180 and name CA
set sphere_scale, 0.0450, resi 180 and name CA
show spheres, resi 67 and name CA
set sphere_scale, 0.0450, resi 67 and name CA
show spheres, resi 57 and name CA
set sphere_scale, 0.0406, resi 57 and name CA
show spheres, resi 61 and name CA
set sphere_scale, 0.0403, resi 61 and name CA
show spheres, resi 90 and name CA
set sphere_scale, 0.0397, resi 90 and name CA
show spheres, resi 24 and name CA
set sphere_scale, 0.0397, resi 24 and name CA
show spheres, resi 58 and name CA
set sphere_scale, 0.0363, resi 58 and name CA
show spheres, resi 73 and name CA
set sphere_scale, 0.0345, resi 73 and name CA
show spheres, resi 69 and name CA
set sphere_scale, 0.0330, resi 69 and name CA
show spheres, resi 172 and name CA
set sphere_scale, 0.0328, resi 172 and name CA
show spheres, resi 173 and name CA
set sphere_scale, 0.0323, resi 173 and name CA
show spheres, resi 124 and name CA
set sphere_scale, 0.0300, resi 124 and name CA
show spheres, resi 118 and name CA
set sphere_scale, 0.0294, resi 118 and name CA
show spheres, resi 65 and name CA
set sphere_scale, 0.0278, resi 65 and name CA
show spheres, resi 4 and name CA
set sphere_scale, 0.0277, resi 4 and name CA
show spheres, resi 168 and name CA
set sphere_scale, 0.0272, resi 168 and name CA
show spheres, resi 135 and name CA
set sphere_scale, 0.0264, resi 135 and name CA
show spheres, resi 174 and name CA
set sphere_scale, 0.0262, resi 174 and name CA
show spheres, resi 178 and name CA
set sphere_scale, 0.0250, resi 178 and name CA
show spheres, resi 153 and name CA
set sphere_scale, 0.0249, resi 153 and name CA
show spheres, resi 32 and name CA
set sphere_scale, 0.0233, resi 32 and name CA
show spheres, resi 117 and name CA
set sphere_scale, 0.0229, resi 117 and name CA
show spheres, resi 198 and name CA
set sphere_scale, 0.0229, resi 198 and name CA
show spheres, resi 169 and name CA
set sphere_scale, 0.0227, resi 169 and name CA
show spheres, resi 112 and name CA
set sphere_scale, 0.0225, resi 112 and name CA
show spheres, resi 88 and name CA
set sphere_scale, 0.0217, resi 88 and name CA
show spheres, resi 84 and name CA
set sphere_scale, 0.0175, resi 84 and name CA
show spheres, resi 148 and name CA
set sphere_scale, 0.0160, resi 148 and name CA
show spheres, resi 60 and name CA
set sphere_scale, 0.0155, resi 60 and name CA
show spheres, resi 140 and name CA
set sphere_scale, 0.0139, resi 140 and name CA
show spheres, resi 199 and name CA
set sphere_scale, 0.0137, resi 199 and name CA
show spheres, resi 202 and name CA
set sphere_scale, 0.0137, resi 202 and name CA
show spheres, resi 92 and name CA
set sphere_scale, 0.0125, resi 92 and name CA
show spheres, resi 151 and name CA
set sphere_scale, 0.0120, resi 151 and name CA
show spheres, resi 7 and name CA
set sphere_scale, 0.0091, resi 7 and name CA
show spheres, resi 62 and name CA
set sphere_scale, 0.0085, resi 62 and name CA
show spheres, resi 27 and name CA
set sphere_scale, 0.0083, resi 27 and name CA
show spheres, resi 93 and name CA
set sphere_scale, 0.0074, resi 93 and name CA
show spheres, resi 149 and name CA
set sphere_scale, 0.0063, resi 149 and name CA
show spheres, resi 74 and name CA
set sphere_scale, 0.0057, resi 74 and name CA
show spheres, resi 85 and name CA
set sphere_scale, 0.0057, resi 85 and name CA
show spheres, resi 126 and name CA
set sphere_scale, 0.0043, resi 126 and name CA
show spheres, resi 26 and name CA
set sphere_scale, 0.0038, resi 26 and name CA
show spheres, resi 35 and name CA
set sphere_scale, 0.0032, resi 35 and name CA
show spheres, resi 64 and name CA
set sphere_scale, 0.0009, resi 64 and name CA
show spheres, resi 133 and name CA
set sphere_scale, 0.0005, resi 133 and name CA
show spheres, resi 15 and name CA
set sphere_scale, 0.0000, resi 15 and name CA
show spheres, resi 18 and name CA
set sphere_scale, 0.0000, resi 18 and name CA
show spheres, resi 41 and name CA
set sphere_scale, 0.0000, resi 41 and name CA
show spheres, resi 42 and name CA
set sphere_scale, 0.0000, resi 42 and name CA
show spheres, resi 59 and name CA
set sphere_scale, 0.0000, resi 59 and name CA
show spheres, resi 70 and name CA
set sphere_scale, 0.0000, resi 70 and name CA
show spheres, resi 71 and name CA
set sphere_scale, 0.0000, resi 71 and name CA
show spheres, resi 72 and name CA
set sphere_scale, 0.0000, resi 72 and name CA
show spheres, resi 82 and name CA
set sphere_scale, 0.0000, resi 82 and name CA
show spheres, resi 89 and name CA
set sphere_scale, 0.0000, resi 89 and name CA
show spheres, resi 95 and name CA
set sphere_scale, 0.0000, resi 95 and name CA
show spheres, resi 115 and name CA
set sphere_scale, 0.0000, resi 115 and name CA
show spheres, resi 116 and name CA
set sphere_scale, 0.0000, resi 116 and name CA
show spheres, resi 137 and name CA
set sphere_scale, 0.0000, resi 137 and name CA
show spheres, resi 145 and name CA
set sphere_scale, 0.0000, resi 145 and name CA
show spheres, resi 146 and name CA
set sphere_scale, 0.0000, resi 146 and name CA
show spheres, resi 147 and name CA
set sphere_scale, 0.0000, resi 147 and name CA
show spheres, resi 158 and name CA
set sphere_scale, 0.0000, resi 158 and name CA
show spheres, resi 185 and name CA
set sphere_scale, 0.0000, resi 185 and name CA
show spheres, resi 189 and name CA
set sphere_scale, 0.0000, resi 189 and name CA
show spheres, resi 200 and name CA
set sphere_scale, 0.0000, resi 200 and name CA
show spheres, resi 201 and name CA
set sphere_scale, 0.0000, resi 201 and name CA
show spheres, resi 204 and name CA
set sphere_scale, 0.0000, resi 204 and name CA
show spheres, resi 210 and name CA
set sphere_scale, 0.0000, resi 210 and name CA
show spheres, resi 222 and name CA
set sphere_scale, 0.0000, resi 222 and name CA
show spheres, resi 224 and name CA
set sphere_scale, 0.0000, resi 224 and name CA
show spheres, resi 225 and name CA
set sphere_scale, 0.0000, resi 225 and name CA
show spheres, resi 253 and name CA
set sphere_scale, 0.0000, resi 253 and name CA
sele All_Spheres, resi 193+45+245+104+186+206+102+103+78+231+232+192+246+252+215+44+20+188+207+98+209+97+162+256+259+101+205+234+217+260+138+187+216+230+46+9+248+179+99+76+194+229+110+100+159+155+43+6+254+250+77+221+16+2+233+203+183+13+191+218+190+125+244+219+120+21+37+105+251+80+243+249+75+17+108+255+156+167+213+106+111+197+240+51+195+212+28+142+238+114+141+228+165+47+94+12+10+127+19+223+176+208+241+48+5+31+226+49+134+54+52+53+257+247+139+79+131+166+143+55+30+123+83+214+258+196+8+40+109+144+239+107+33+36+164+22+220+96+14+68+227+81+236+163+23+86+136+237+3+157+184+87+160+50+129+171+132+56+130+119+177+63+242+38+128+11+25+235+152+175+91+113+182+121+39+66+29+150+154+181+161+122+211+170+34+180+67+57+61+90+24+58+73+69+172+173+124+118+65+4+168+135+174+178+153+32+117+198+169+112+88+84+148+60+140+199+202+92+151+7+62+27+93+149+74+85+126+26+35+64+133+15+18+41+42+59+70+71+72+82+89+95+115+116+137+145+146+147+158+185+189+200+201+204+210+222+224+225+253 and name CA
