# You can run me in several ways, perhaps the easiest way is to:
# 1. Load the PDB file of your system in PyMOL.
# 2. Type: @[FILE_NAME.py] in the command line.
# 3. Make sure the .py file is in the same directory as the pdb.
set sphere_color, red
# The lines below are suggestions for potentially nicer figures.
# You can comment them in if you want.
# bg_color white
# set cartoon_color, grey90
# set ray_opaque_background, 0
# set antialias, 2
# set ray_shadows, 0
show spheres, resi 45 and name CA
set sphere_scale, 1.0000, resi 45 and name CA
show spheres, resi 104 and name CA
set sphere_scale, 0.7839, resi 104 and name CA
show spheres, resi 206 and name CA
set sphere_scale, 0.7386, resi 206 and name CA
show spheres, resi 102 and name CA
set sphere_scale, 0.7173, resi 102 and name CA
show spheres, resi 186 and name CA
set sphere_scale, 0.5222, resi 186 and name CA
show spheres, resi 193 and name CA
set sphere_scale, 0.5107, resi 193 and name CA
show spheres, resi 245 and name CA
set sphere_scale, 0.4692, resi 245 and name CA
show spheres, resi 188 and name CA
set sphere_scale, 0.4369, resi 188 and name CA
show spheres, resi 103 and name CA
set sphere_scale, 0.3913, resi 103 and name CA
show spheres, resi 246 and name CA
set sphere_scale, 0.3828, resi 246 and name CA
show spheres, resi 100 and name CA
set sphere_scale, 0.3589, resi 100 and name CA
show spheres, resi 192 and name CA
set sphere_scale, 0.3533, resi 192 and name CA
show spheres, resi 215 and name CA
set sphere_scale, 0.3224, resi 215 and name CA
show spheres, resi 78 and name CA
set sphere_scale, 0.3222, resi 78 and name CA
show spheres, resi 207 and name CA
set sphere_scale, 0.3034, resi 207 and name CA
show spheres, resi 231 and name CA
set sphere_scale, 0.2937, resi 231 and name CA
show spheres, resi 232 and name CA
set sphere_scale, 0.2628, resi 232 and name CA
show spheres, resi 194 and name CA
set sphere_scale, 0.2525, resi 194 and name CA
show spheres, resi 76 and name CA
set sphere_scale, 0.2417, resi 76 and name CA
show spheres, resi 260 and name CA
set sphere_scale, 0.2410, resi 260 and name CA
show spheres, resi 205 and name CA
set sphere_scale, 0.2329, resi 205 and name CA
show spheres, resi 98 and name CA
set sphere_scale, 0.2312, resi 98 and name CA
show spheres, resi 252 and name CA
set sphere_scale, 0.2141, resi 252 and name CA
show spheres, resi 187 and name CA
set sphere_scale, 0.2124, resi 187 and name CA
show spheres, resi 259 and name CA
set sphere_scale, 0.2068, resi 259 and name CA
show spheres, resi 77 and name CA
set sphere_scale, 0.2041, resi 77 and name CA
show spheres, resi 209 and name CA
set sphere_scale, 0.1910, resi 209 and name CA
show spheres, resi 217 and name CA
set sphere_scale, 0.1798, resi 217 and name CA
show spheres, resi 233 and name CA
set sphere_scale, 0.1635, resi 233 and name CA
show spheres, resi 191 and name CA
set sphere_scale, 0.1558, resi 191 and name CA
show spheres, resi 221 and name CA
set sphere_scale, 0.1507, resi 221 and name CA
show spheres, resi 44 and name CA
set sphere_scale, 0.1481, resi 44 and name CA
show spheres, resi 134 and name CA
set sphere_scale, 0.1458, resi 134 and name CA
show spheres, resi 20 and name CA
set sphere_scale, 0.1425, resi 20 and name CA
show spheres, resi 250 and name CA
set sphere_scale, 0.1379, resi 250 and name CA
show spheres, resi 97 and name CA
set sphere_scale, 0.1372, resi 97 and name CA
show spheres, resi 138 and name CA
set sphere_scale, 0.1366, resi 138 and name CA
show spheres, resi 212 and name CA
set sphere_scale, 0.1321, resi 212 and name CA
show spheres, resi 125 and name CA
set sphere_scale, 0.1294, resi 125 and name CA
show spheres, resi 155 and name CA
set sphere_scale, 0.1254, resi 155 and name CA
show spheres, resi 163 and name CA
set sphere_scale, 0.1247, resi 163 and name CA
show spheres, resi 105 and name CA
set sphere_scale, 0.1214, resi 105 and name CA
show spheres, resi 183 and name CA
set sphere_scale, 0.1203, resi 183 and name CA
show spheres, resi 203 and name CA
set sphere_scale, 0.1191, resi 203 and name CA
show spheres, resi 195 and name CA
set sphere_scale, 0.1183, resi 195 and name CA
show spheres, resi 21 and name CA
set sphere_scale, 0.1113, resi 21 and name CA
show spheres, resi 99 and name CA
set sphere_scale, 0.1112, resi 99 and name CA
show spheres, resi 179 and name CA
set sphere_scale, 0.1073, resi 179 and name CA
show spheres, resi 101 and name CA
set sphere_scale, 0.1067, resi 101 and name CA
show spheres, resi 162 and name CA
set sphere_scale, 0.1053, resi 162 and name CA
show spheres, resi 229 and name CA
set sphere_scale, 0.1051, resi 229 and name CA
show spheres, resi 47 and name CA
set sphere_scale, 0.1049, resi 47 and name CA
show spheres, resi 240 and name CA
set sphere_scale, 0.1014, resi 240 and name CA
show spheres, resi 143 and name CA
set sphere_scale, 0.1007, resi 143 and name CA
show spheres, resi 43 and name CA
set sphere_scale, 0.0987, resi 43 and name CA
show spheres, resi 249 and name CA
set sphere_scale, 0.0973, resi 249 and name CA
show spheres, resi 216 and name CA
set sphere_scale, 0.0972, resi 216 and name CA
show spheres, resi 142 and name CA
set sphere_scale, 0.0970, resi 142 and name CA
show spheres, resi 50 and name CA
set sphere_scale, 0.0966, resi 50 and name CA
show spheres, resi 30 and name CA
set sphere_scale, 0.0956, resi 30 and name CA
show spheres, resi 94 and name CA
set sphere_scale, 0.0936, resi 94 and name CA
show spheres, resi 13 and name CA
set sphere_scale, 0.0916, resi 13 and name CA
show spheres, resi 256 and name CA
set sphere_scale, 0.0907, resi 256 and name CA
show spheres, resi 244 and name CA
set sphere_scale, 0.0903, resi 244 and name CA
show spheres, resi 190 and name CA
set sphere_scale, 0.0896, resi 190 and name CA
show spheres, resi 19 and name CA
set sphere_scale, 0.0884, resi 19 and name CA
show spheres, resi 2 and name CA
set sphere_scale, 0.0871, resi 2 and name CA
show spheres, resi 46 and name CA
set sphere_scale, 0.0866, resi 46 and name CA
show spheres, resi 141 and name CA
set sphere_scale, 0.0851, resi 141 and name CA
show spheres, resi 213 and name CA
set sphere_scale, 0.0846, resi 213 and name CA
show spheres, resi 254 and name CA
set sphere_scale, 0.0845, resi 254 and name CA
show spheres, resi 160 and name CA
set sphere_scale, 0.0830, resi 160 and name CA
show spheres, resi 255 and name CA
set sphere_scale, 0.0825, resi 255 and name CA
show spheres, resi 235 and name CA
set sphere_scale, 0.0819, resi 235 and name CA
show spheres, resi 28 and name CA
set sphere_scale, 0.0792, resi 28 and name CA
show spheres, resi 226 and name CA
set sphere_scale, 0.0790, resi 226 and name CA
show spheres, resi 248 and name CA
set sphere_scale, 0.0750, resi 248 and name CA
show spheres, resi 214 and name CA
set sphere_scale, 0.0747, resi 214 and name CA
show spheres, resi 238 and name CA
set sphere_scale, 0.0739, resi 238 and name CA
show spheres, resi 17 and name CA
set sphere_scale, 0.0734, resi 17 and name CA
show spheres, resi 9 and name CA
set sphere_scale, 0.0732, resi 9 and name CA
show spheres, resi 208 and name CA
set sphere_scale, 0.0717, resi 208 and name CA
show spheres, resi 234 and name CA
set sphere_scale, 0.0712, resi 234 and name CA
show spheres, resi 131 and name CA
set sphere_scale, 0.0707, resi 131 and name CA
show spheres, resi 129 and name CA
set sphere_scale, 0.0707, resi 129 and name CA
show spheres, resi 165 and name CA
set sphere_scale, 0.0706, resi 165 and name CA
show spheres, resi 161 and name CA
set sphere_scale, 0.0706, resi 161 and name CA
show spheres, resi 23 and name CA
set sphere_scale, 0.0695, resi 23 and name CA
show spheres, resi 218 and name CA
set sphere_scale, 0.0693, resi 218 and name CA
show spheres, resi 114 and name CA
set sphere_scale, 0.0678, resi 114 and name CA
show spheres, resi 24 and name CA
set sphere_scale, 0.0664, resi 24 and name CA
show spheres, resi 108 and name CA
set sphere_scale, 0.0664, resi 108 and name CA
show spheres, resi 167 and name CA
set sphere_scale, 0.0652, resi 167 and name CA
show spheres, resi 106 and name CA
set sphere_scale, 0.0637, resi 106 and name CA
show spheres, resi 156 and name CA
set sphere_scale, 0.0637, resi 156 and name CA
show spheres, resi 230 and name CA
set sphere_scale, 0.0626, resi 230 and name CA
show spheres, resi 123 and name CA
set sphere_scale, 0.0623, resi 123 and name CA
show spheres, resi 132 and name CA
set sphere_scale, 0.0622, resi 132 and name CA
show spheres, resi 117 and name CA
set sphere_scale, 0.0612, resi 117 and name CA
show spheres, resi 151 and name CA
set sphere_scale, 0.0593, resi 151 and name CA
show spheres, resi 90 and name CA
set sphere_scale, 0.0590, resi 90 and name CA
show spheres, resi 22 and name CA
set sphere_scale, 0.0590, resi 22 and name CA
show spheres, resi 110 and name CA
set sphere_scale, 0.0590, resi 110 and name CA
show spheres, resi 37 and name CA
set sphere_scale, 0.0587, resi 37 and name CA
show spheres, resi 120 and name CA
set sphere_scale, 0.0585, resi 120 and name CA
show spheres, resi 136 and name CA
set sphere_scale, 0.0576, resi 136 and name CA
show spheres, resi 53 and name CA
set sphere_scale, 0.0568, resi 53 and name CA
show spheres, resi 139 and name CA
set sphere_scale, 0.0564, resi 139 and name CA
show spheres, resi 6 and name CA
set sphere_scale, 0.0561, resi 6 and name CA
show spheres, resi 237 and name CA
set sphere_scale, 0.0547, resi 237 and name CA
show spheres, resi 247 and name CA
set sphere_scale, 0.0545, resi 247 and name CA
show spheres, resi 12 and name CA
set sphere_scale, 0.0525, resi 12 and name CA
show spheres, resi 8 and name CA
set sphere_scale, 0.0517, resi 8 and name CA
show spheres, resi 197 and name CA
set sphere_scale, 0.0508, resi 197 and name CA
show spheres, resi 177 and name CA
set sphere_scale, 0.0503, resi 177 and name CA
show spheres, resi 111 and name CA
set sphere_scale, 0.0493, resi 111 and name CA
show spheres, resi 10 and name CA
set sphere_scale, 0.0492, resi 10 and name CA
show spheres, resi 258 and name CA
set sphere_scale, 0.0491, resi 258 and name CA
show spheres, resi 251 and name CA
set sphere_scale, 0.0469, resi 251 and name CA
show spheres, resi 121 and name CA
set sphere_scale, 0.0465, resi 121 and name CA
show spheres, resi 164 and name CA
set sphere_scale, 0.0462, resi 164 and name CA
show spheres, resi 159 and name CA
set sphere_scale, 0.0462, resi 159 and name CA
show spheres, resi 184 and name CA
set sphere_scale, 0.0440, resi 184 and name CA
show spheres, resi 241 and name CA
set sphere_scale, 0.0432, resi 241 and name CA
show spheres, resi 243 and name CA
set sphere_scale, 0.0429, resi 243 and name CA
show spheres, resi 124 and name CA
set sphere_scale, 0.0426, resi 124 and name CA
show spheres, resi 75 and name CA
set sphere_scale, 0.0421, resi 75 and name CA
show spheres, resi 5 and name CA
set sphere_scale, 0.0418, resi 5 and name CA
show spheres, resi 16 and name CA
set sphere_scale, 0.0408, resi 16 and name CA
show spheres, resi 257 and name CA
set sphere_scale, 0.0408, resi 257 and name CA
show spheres, resi 219 and name CA
set sphere_scale, 0.0404, resi 219 and name CA
show spheres, resi 211 and name CA
set sphere_scale, 0.0386, resi 211 and name CA
show spheres, resi 223 and name CA
set sphere_scale, 0.0381, resi 223 and name CA
show spheres, resi 198 and name CA
set sphere_scale, 0.0376, resi 198 and name CA
show spheres, resi 107 and name CA
set sphere_scale, 0.0376, resi 107 and name CA
show spheres, resi 196 and name CA
set sphere_scale, 0.0371, resi 196 and name CA
show spheres, resi 144 and name CA
set sphere_scale, 0.0364, resi 144 and name CA
show spheres, resi 130 and name CA
set sphere_scale, 0.0362, resi 130 and name CA
show spheres, resi 48 and name CA
set sphere_scale, 0.0358, resi 48 and name CA
show spheres, resi 181 and name CA
set sphere_scale, 0.0358, resi 181 and name CA
show spheres, resi 133 and name CA
set sphere_scale, 0.0355, resi 133 and name CA
show spheres, resi 176 and name CA
set sphere_scale, 0.0353, resi 176 and name CA
show spheres, resi 4 and name CA
set sphere_scale, 0.0338, resi 4 and name CA
show spheres, resi 109 and name CA
set sphere_scale, 0.0337, resi 109 and name CA
show spheres, resi 220 and name CA
set sphere_scale, 0.0322, resi 220 and name CA
show spheres, resi 80 and name CA
set sphere_scale, 0.0320, resi 80 and name CA
show spheres, resi 96 and name CA
set sphere_scale, 0.0318, resi 96 and name CA
show spheres, resi 52 and name CA
set sphere_scale, 0.0314, resi 52 and name CA
show spheres, resi 74 and name CA
set sphere_scale, 0.0303, resi 74 and name CA
show spheres, resi 85 and name CA
set sphere_scale, 0.0303, resi 85 and name CA
show spheres, resi 81 and name CA
set sphere_scale, 0.0302, resi 81 and name CA
show spheres, resi 31 and name CA
set sphere_scale, 0.0290, resi 31 and name CA
show spheres, resi 182 and name CA
set sphere_scale, 0.0288, resi 182 and name CA
show spheres, resi 227 and name CA
set sphere_scale, 0.0273, resi 227 and name CA
show spheres, resi 91 and name CA
set sphere_scale, 0.0266, resi 91 and name CA
show spheres, resi 166 and name CA
set sphere_scale, 0.0264, resi 166 and name CA
show spheres, resi 63 and name CA
set sphere_scale, 0.0262, resi 63 and name CA
show spheres, resi 39 and name CA
set sphere_scale, 0.0254, resi 39 and name CA
show spheres, resi 152 and name CA
set sphere_scale, 0.0254, resi 152 and name CA
show spheres, resi 83 and name CA
set sphere_scale, 0.0246, resi 83 and name CA
show spheres, resi 87 and name CA
set sphere_scale, 0.0245, resi 87 and name CA
show spheres, resi 25 and name CA
set sphere_scale, 0.0244, resi 25 and name CA
show spheres, resi 122 and name CA
set sphere_scale, 0.0238, resi 122 and name CA
show spheres, resi 68 and name CA
set sphere_scale, 0.0222, resi 68 and name CA
show spheres, resi 86 and name CA
set sphere_scale, 0.0222, resi 86 and name CA
show spheres, resi 119 and name CA
set sphere_scale, 0.0222, resi 119 and name CA
show spheres, resi 172 and name CA
set sphere_scale, 0.0222, resi 172 and name CA
show spheres, resi 93 and name CA
set sphere_scale, 0.0217, resi 93 and name CA
show spheres, resi 149 and name CA
set sphere_scale, 0.0216, resi 149 and name CA
show spheres, resi 173 and name CA
set sphere_scale, 0.0202, resi 173 and name CA
show spheres, resi 56 and name CA
set sphere_scale, 0.0200, resi 56 and name CA
show spheres, resi 69 and name CA
set sphere_scale, 0.0200, resi 69 and name CA
show spheres, resi 33 and name CA
set sphere_scale, 0.0200, resi 33 and name CA
show spheres, resi 36 and name CA
set sphere_scale, 0.0200, resi 36 and name CA
show spheres, resi 242 and name CA
set sphere_scale, 0.0199, resi 242 and name CA
show spheres, resi 171 and name CA
set sphere_scale, 0.0192, resi 171 and name CA
show spheres, resi 66 and name CA
set sphere_scale, 0.0189, resi 66 and name CA
show spheres, resi 88 and name CA
set sphere_scale, 0.0189, resi 88 and name CA
show spheres, resi 40 and name CA
set sphere_scale, 0.0187, resi 40 and name CA
show spheres, resi 57 and name CA
set sphere_scale, 0.0177, resi 57 and name CA
show spheres, resi 228 and name CA
set sphere_scale, 0.0176, resi 228 and name CA
show spheres, resi 65 and name CA
set sphere_scale, 0.0176, resi 65 and name CA
show spheres, resi 51 and name CA
set sphere_scale, 0.0174, resi 51 and name CA
show spheres, resi 54 and name CA
set sphere_scale, 0.0172, resi 54 and name CA
show spheres, resi 35 and name CA
set sphere_scale, 0.0171, resi 35 and name CA
show spheres, resi 154 and name CA
set sphere_scale, 0.0171, resi 154 and name CA
show spheres, resi 127 and name CA
set sphere_scale, 0.0169, resi 127 and name CA
show spheres, resi 157 and name CA
set sphere_scale, 0.0169, resi 157 and name CA
show spheres, resi 236 and name CA
set sphere_scale, 0.0165, resi 236 and name CA
show spheres, resi 3 and name CA
set sphere_scale, 0.0161, resi 3 and name CA
show spheres, resi 150 and name CA
set sphere_scale, 0.0147, resi 150 and name CA
show spheres, resi 174 and name CA
set sphere_scale, 0.0146, resi 174 and name CA
show spheres, resi 49 and name CA
set sphere_scale, 0.0143, resi 49 and name CA
show spheres, resi 170 and name CA
set sphere_scale, 0.0142, resi 170 and name CA
show spheres, resi 118 and name CA
set sphere_scale, 0.0140, resi 118 and name CA
show spheres, resi 175 and name CA
set sphere_scale, 0.0133, resi 175 and name CA
show spheres, resi 14 and name CA
set sphere_scale, 0.0123, resi 14 and name CA
show spheres, resi 112 and name CA
set sphere_scale, 0.0105, resi 112 and name CA
show spheres, resi 126 and name CA
set sphere_scale, 0.0097, resi 126 and name CA
show spheres, resi 27 and name CA
set sphere_scale, 0.0077, resi 27 and name CA
show spheres, resi 73 and name CA
set sphere_scale, 0.0077, resi 73 and name CA
show spheres, resi 11 and name CA
set sphere_scale, 0.0044, resi 11 and name CA
show spheres, resi 239 and name CA
set sphere_scale, 0.0028, resi 239 and name CA
show spheres, resi 79 and name CA
set sphere_scale, 0.0022, resi 79 and name CA
show spheres, resi 169 and name CA
set sphere_scale, 0.0012, resi 169 and name CA
show spheres, resi 61 and name CA
set sphere_scale, 0.0009, resi 61 and name CA
show spheres, resi 67 and name CA
set sphere_scale, 0.0001, resi 67 and name CA
show spheres, resi 7 and name CA
set sphere_scale, 0.0000, resi 7 and name CA
show spheres, resi 15 and name CA
set sphere_scale, 0.0000, resi 15 and name CA
show spheres, resi 18 and name CA
set sphere_scale, 0.0000, resi 18 and name CA
show spheres, resi 26 and name CA
set sphere_scale, 0.0000, resi 26 and name CA
show spheres, resi 29 and name CA
set sphere_scale, 0.0000, resi 29 and name CA
show spheres, resi 32 and name CA
set sphere_scale, 0.0000, resi 32 and name CA
show spheres, resi 34 and name CA
set sphere_scale, 0.0000, resi 34 and name CA
show spheres, resi 38 and name CA
set sphere_scale, 0.0000, resi 38 and name CA
show spheres, resi 41 and name CA
set sphere_scale, 0.0000, resi 41 and name CA
show spheres, resi 42 and name CA
set sphere_scale, 0.0000, resi 42 and name CA
show spheres, resi 55 and name CA
set sphere_scale, 0.0000, resi 55 and name CA
show spheres, resi 58 and name CA
set sphere_scale, 0.0000, resi 58 and name CA
show spheres, resi 59 and name CA
set sphere_scale, 0.0000, resi 59 and name CA
show spheres, resi 60 and name CA
set sphere_scale, 0.0000, resi 60 and name CA
show spheres, resi 62 and name CA
set sphere_scale, 0.0000, resi 62 and name CA
show spheres, resi 64 and name CA
set sphere_scale, 0.0000, resi 64 and name CA
show spheres, resi 70 and name CA
set sphere_scale, 0.0000, resi 70 and name CA
show spheres, resi 71 and name CA
set sphere_scale, 0.0000, resi 71 and name CA
show spheres, resi 72 and name CA
set sphere_scale, 0.0000, resi 72 and name CA
show spheres, resi 82 and name CA
set sphere_scale, 0.0000, resi 82 and name CA
show spheres, resi 84 and name CA
set sphere_scale, 0.0000, resi 84 and name CA
show spheres, resi 89 and name CA
set sphere_scale, 0.0000, resi 89 and name CA
show spheres, resi 92 and name CA
set sphere_scale, 0.0000, resi 92 and name CA
show spheres, resi 95 and name CA
set sphere_scale, 0.0000, resi 95 and name CA
show spheres, resi 113 and name CA
set sphere_scale, 0.0000, resi 113 and name CA
show spheres, resi 115 and name CA
set sphere_scale, 0.0000, resi 115 and name CA
show spheres, resi 116 and name CA
set sphere_scale, 0.0000, resi 116 and name CA
show spheres, resi 128 and name CA
set sphere_scale, 0.0000, resi 128 and name CA
show spheres, resi 135 and name CA
set sphere_scale, 0.0000, resi 135 and name CA
show spheres, resi 137 and name CA
set sphere_scale, 0.0000, resi 137 and name CA
show spheres, resi 140 and name CA
set sphere_scale, 0.0000, resi 140 and name CA
show spheres, resi 145 and name CA
set sphere_scale, 0.0000, resi 145 and name CA
show spheres, resi 146 and name CA
set sphere_scale, 0.0000, resi 146 and name CA
show spheres, resi 147 and name CA
set sphere_scale, 0.0000, resi 147 and name CA
show spheres, resi 148 and name CA
set sphere_scale, 0.0000, resi 148 and name CA
show spheres, resi 153 and name CA
set sphere_scale, 0.0000, resi 153 and name CA
show spheres, resi 158 and name CA
set sphere_scale, 0.0000, resi 158 and name CA
show spheres, resi 168 and name CA
set sphere_scale, 0.0000, resi 168 and name CA
show spheres, resi 178 and name CA
set sphere_scale, 0.0000, resi 178 and name CA
show spheres, resi 180 and name CA
set sphere_scale, 0.0000, resi 180 and name CA
show spheres, resi 185 and name CA
set sphere_scale, 0.0000, resi 185 and name CA
show spheres, resi 189 and name CA
set sphere_scale, 0.0000, resi 189 and name CA
show spheres, resi 199 and name CA
set sphere_scale, 0.0000, resi 199 and name CA
show spheres, resi 200 and name CA
set sphere_scale, 0.0000, resi 200 and name CA
show spheres, resi 201 and name CA
set sphere_scale, 0.0000, resi 201 and name CA
show spheres, resi 202 and name CA
set sphere_scale, 0.0000, resi 202 and name CA
show spheres, resi 204 and name CA
set sphere_scale, 0.0000, resi 204 and name CA
show spheres, resi 210 and name CA
set sphere_scale, 0.0000, resi 210 and name CA
show spheres, resi 222 and name CA
set sphere_scale, 0.0000, resi 222 and name CA
show spheres, resi 224 and name CA
set sphere_scale, 0.0000, resi 224 and name CA
show spheres, resi 225 and name CA
set sphere_scale, 0.0000, resi 225 and name CA
show spheres, resi 253 and name CA
set sphere_scale, 0.0000, resi 253 and name CA
sele All_Spheres, resi 45+104+206+102+186+193+245+188+103+246+100+192+215+78+207+231+232+194+76+260+205+98+252+187+259+77+209+217+233+191+221+44+134+20+250+97+138+212+125+155+163+105+183+203+195+21+99+179+101+162+229+47+240+143+43+249+216+142+50+30+94+13+256+244+190+19+2+46+141+213+254+160+255+235+28+226+248+214+238+17+9+208+234+131+129+165+161+23+218+114+24+108+167+106+156+230+123+132+117+151+90+22+110+37+120+136+53+139+6+237+247+12+8+197+177+111+10+258+251+121+164+159+184+241+243+124+75+5+16+257+219+211+223+198+107+196+144+130+48+181+133+176+4+109+220+80+96+52+74+85+81+31+182+227+91+166+63+39+152+83+87+25+122+68+86+119+172+93+149+173+56+69+33+36+242+171+66+88+40+57+228+65+51+54+35+154+127+157+236+3+150+174+49+170+118+175+14+112+126+27+73+11+239+79+169+61+67+7+15+18+26+29+32+34+38+41+42+55+58+59+60+62+64+70+71+72+82+84+89+92+95+113+115+116+128+135+137+140+145+146+147+148+153+158+168+178+180+185+189+199+200+201+202+204+210+222+224+225+253 and name CA
