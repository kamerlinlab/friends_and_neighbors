# You can run me in several ways, perhaps the easiest way is to:
# 1. Load the PDB file of your system in PyMOL.
# 2. Type: @[FILE_NAME.py] in the command line.
# 3. Make sure the .py file is in the same directory as the pdb.
set sphere_color, red
# The lines below are suggestions for potentially nicer figures.
# You can comment them in if you want.
# bg_color white
# set cartoon_color, grey90
# set ray_opaque_background, 0
# set antialias, 2
# set ray_shadows, 0
show spheres, resi 104 and name CA
set sphere_scale, 1.0000, resi 104 and name CA
show spheres, resi 190 and name CA
set sphere_scale, 0.8559, resi 190 and name CA
show spheres, resi 194 and name CA
set sphere_scale, 0.8020, resi 194 and name CA
show spheres, resi 208 and name CA
set sphere_scale, 0.7427, resi 208 and name CA
show spheres, resi 103 and name CA
set sphere_scale, 0.7393, resi 103 and name CA
show spheres, resi 188 and name CA
set sphere_scale, 0.7118, resi 188 and name CA
show spheres, resi 47 and name CA
set sphere_scale, 0.7029, resi 47 and name CA
show spheres, resi 102 and name CA
set sphere_scale, 0.7014, resi 102 and name CA
show spheres, resi 189 and name CA
set sphere_scale, 0.6420, resi 189 and name CA
show spheres, resi 207 and name CA
set sphere_scale, 0.5732, resi 207 and name CA
show spheres, resi 209 and name CA
set sphere_scale, 0.5525, resi 209 and name CA
show spheres, resi 196 and name CA
set sphere_scale, 0.5272, resi 196 and name CA
show spheres, resi 98 and name CA
set sphere_scale, 0.4794, resi 98 and name CA
show spheres, resi 106 and name CA
set sphere_scale, 0.4643, resi 106 and name CA
show spheres, resi 100 and name CA
set sphere_scale, 0.4093, resi 100 and name CA
show spheres, resi 210 and name CA
set sphere_scale, 0.3962, resi 210 and name CA
show spheres, resi 140 and name CA
set sphere_scale, 0.3443, resi 140 and name CA
show spheres, resi 219 and name CA
set sphere_scale, 0.3367, resi 219 and name CA
show spheres, resi 218 and name CA
set sphere_scale, 0.3157, resi 218 and name CA
show spheres, resi 262 and name CA
set sphere_scale, 0.3104, resi 262 and name CA
show spheres, resi 247 and name CA
set sphere_scale, 0.2785, resi 247 and name CA
show spheres, resi 254 and name CA
set sphere_scale, 0.2733, resi 254 and name CA
show spheres, resi 220 and name CA
set sphere_scale, 0.2713, resi 220 and name CA
show spheres, resi 235 and name CA
set sphere_scale, 0.2652, resi 235 and name CA
show spheres, resi 112 and name CA
set sphere_scale, 0.2530, resi 112 and name CA
show spheres, resi 217 and name CA
set sphere_scale, 0.2414, resi 217 and name CA
show spheres, resi 24 and name CA
set sphere_scale, 0.2399, resi 24 and name CA
show spheres, resi 164 and name CA
set sphere_scale, 0.2361, resi 164 and name CA
show spheres, resi 184 and name CA
set sphere_scale, 0.2357, resi 184 and name CA
show spheres, resi 127 and name CA
set sphere_scale, 0.2306, resi 127 and name CA
show spheres, resi 231 and name CA
set sphere_scale, 0.2164, resi 231 and name CA
show spheres, resi 195 and name CA
set sphere_scale, 0.2063, resi 195 and name CA
show spheres, resi 55 and name CA
set sphere_scale, 0.1954, resi 55 and name CA
show spheres, resi 101 and name CA
set sphere_scale, 0.1869, resi 101 and name CA
show spheres, resi 79 and name CA
set sphere_scale, 0.1866, resi 79 and name CA
show spheres, resi 50 and name CA
set sphere_scale, 0.1825, resi 50 and name CA
show spheres, resi 144 and name CA
set sphere_scale, 0.1801, resi 144 and name CA
show spheres, resi 222 and name CA
set sphere_scale, 0.1797, resi 222 and name CA
show spheres, resi 216 and name CA
set sphere_scale, 0.1763, resi 216 and name CA
show spheres, resi 185 and name CA
set sphere_scale, 0.1743, resi 185 and name CA
show spheres, resi 21 and name CA
set sphere_scale, 0.1691, resi 21 and name CA
show spheres, resi 173 and name CA
set sphere_scale, 0.1681, resi 173 and name CA
show spheres, resi 105 and name CA
set sphere_scale, 0.1667, resi 105 and name CA
show spheres, resi 122 and name CA
set sphere_scale, 0.1659, resi 122 and name CA
show spheres, resi 93 and name CA
set sphere_scale, 0.1645, resi 93 and name CA
show spheres, resi 233 and name CA
set sphere_scale, 0.1575, resi 233 and name CA
show spheres, resi 257 and name CA
set sphere_scale, 0.1560, resi 257 and name CA
show spheres, resi 124 and name CA
set sphere_scale, 0.1552, resi 124 and name CA
show spheres, resi 168 and name CA
set sphere_scale, 0.1524, resi 168 and name CA
show spheres, resi 211 and name CA
set sphere_scale, 0.1505, resi 211 and name CA
show spheres, resi 22 and name CA
set sphere_scale, 0.1478, resi 22 and name CA
show spheres, resi 23 and name CA
set sphere_scale, 0.1450, resi 23 and name CA
show spheres, resi 42 and name CA
set sphere_scale, 0.1409, resi 42 and name CA
show spheres, resi 261 and name CA
set sphere_scale, 0.1403, resi 261 and name CA
show spheres, resi 136 and name CA
set sphere_scale, 0.1392, resi 136 and name CA
show spheres, resi 113 and name CA
set sphere_scale, 0.1368, resi 113 and name CA
show spheres, resi 158 and name CA
set sphere_scale, 0.1349, resi 158 and name CA
show spheres, resi 221 and name CA
set sphere_scale, 0.1311, resi 221 and name CA
show spheres, resi 30 and name CA
set sphere_scale, 0.1295, resi 30 and name CA
show spheres, resi 53 and name CA
set sphere_scale, 0.1280, resi 53 and name CA
show spheres, resi 181 and name CA
set sphere_scale, 0.1268, resi 181 and name CA
show spheres, resi 138 and name CA
set sphere_scale, 0.1224, resi 138 and name CA
show spheres, resi 110 and name CA
set sphere_scale, 0.1202, resi 110 and name CA
show spheres, resi 258 and name CA
set sphere_scale, 0.1193, resi 258 and name CA
show spheres, resi 48 and name CA
set sphere_scale, 0.1188, resi 48 and name CA
show spheres, resi 19 and name CA
set sphere_scale, 0.1154, resi 19 and name CA
show spheres, resi 108 and name CA
set sphere_scale, 0.1148, resi 108 and name CA
show spheres, resi 167 and name CA
set sphere_scale, 0.1143, resi 167 and name CA
show spheres, resi 131 and name CA
set sphere_scale, 0.1109, resi 131 and name CA
show spheres, resi 186 and name CA
set sphere_scale, 0.1103, resi 186 and name CA
show spheres, resi 178 and name CA
set sphere_scale, 0.1077, resi 178 and name CA
show spheres, resi 52 and name CA
set sphere_scale, 0.1049, resi 52 and name CA
show spheres, resi 246 and name CA
set sphere_scale, 0.1047, resi 246 and name CA
show spheres, resi 134 and name CA
set sphere_scale, 0.0993, resi 134 and name CA
show spheres, resi 54 and name CA
set sphere_scale, 0.0981, resi 54 and name CA
show spheres, resi 32 and name CA
set sphere_scale, 0.0977, resi 32 and name CA
show spheres, resi 4 and name CA
set sphere_scale, 0.0977, resi 4 and name CA
show spheres, resi 25 and name CA
set sphere_scale, 0.0973, resi 25 and name CA
show spheres, resi 163 and name CA
set sphere_scale, 0.0947, resi 163 and name CA
show spheres, resi 232 and name CA
set sphere_scale, 0.0918, resi 232 and name CA
show spheres, resi 33 and name CA
set sphere_scale, 0.0908, resi 33 and name CA
show spheres, resi 177 and name CA
set sphere_scale, 0.0907, resi 177 and name CA
show spheres, resi 223 and name CA
set sphere_scale, 0.0903, resi 223 and name CA
show spheres, resi 65 and name CA
set sphere_scale, 0.0901, resi 65 and name CA
show spheres, resi 31 and name CA
set sphere_scale, 0.0879, resi 31 and name CA
show spheres, resi 141 and name CA
set sphere_scale, 0.0873, resi 141 and name CA
show spheres, resi 69 and name CA
set sphere_scale, 0.0870, resi 69 and name CA
show spheres, resi 111 and name CA
set sphere_scale, 0.0848, resi 111 and name CA
show spheres, resi 145 and name CA
set sphere_scale, 0.0848, resi 145 and name CA
show spheres, resi 230 and name CA
set sphere_scale, 0.0838, resi 230 and name CA
show spheres, resi 40 and name CA
set sphere_scale, 0.0837, resi 40 and name CA
show spheres, resi 205 and name CA
set sphere_scale, 0.0836, resi 205 and name CA
show spheres, resi 39 and name CA
set sphere_scale, 0.0833, resi 39 and name CA
show spheres, resi 109 and name CA
set sphere_scale, 0.0828, resi 109 and name CA
show spheres, resi 78 and name CA
set sphere_scale, 0.0814, resi 78 and name CA
show spheres, resi 240 and name CA
set sphere_scale, 0.0808, resi 240 and name CA
show spheres, resi 129 and name CA
set sphere_scale, 0.0802, resi 129 and name CA
show spheres, resi 214 and name CA
set sphere_scale, 0.0799, resi 214 and name CA
show spheres, resi 35 and name CA
set sphere_scale, 0.0780, resi 35 and name CA
show spheres, resi 251 and name CA
set sphere_scale, 0.0780, resi 251 and name CA
show spheres, resi 37 and name CA
set sphere_scale, 0.0778, resi 37 and name CA
show spheres, resi 157 and name CA
set sphere_scale, 0.0762, resi 157 and name CA
show spheres, resi 249 and name CA
set sphere_scale, 0.0741, resi 249 and name CA
show spheres, resi 125 and name CA
set sphere_scale, 0.0726, resi 125 and name CA
show spheres, resi 8 and name CA
set sphere_scale, 0.0722, resi 8 and name CA
show spheres, resi 239 and name CA
set sphere_scale, 0.0715, resi 239 and name CA
show spheres, resi 133 and name CA
set sphere_scale, 0.0707, resi 133 and name CA
show spheres, resi 225 and name CA
set sphere_scale, 0.0684, resi 225 and name CA
show spheres, resi 77 and name CA
set sphere_scale, 0.0646, resi 77 and name CA
show spheres, resi 143 and name CA
set sphere_scale, 0.0644, resi 143 and name CA
show spheres, resi 161 and name CA
set sphere_scale, 0.0636, resi 161 and name CA
show spheres, resi 86 and name CA
set sphere_scale, 0.0635, resi 86 and name CA
show spheres, resi 250 and name CA
set sphere_scale, 0.0634, resi 250 and name CA
show spheres, resi 252 and name CA
set sphere_scale, 0.0630, resi 252 and name CA
show spheres, resi 89 and name CA
set sphere_scale, 0.0629, resi 89 and name CA
show spheres, resi 75 and name CA
set sphere_scale, 0.0628, resi 75 and name CA
show spheres, resi 107 and name CA
set sphere_scale, 0.0628, resi 107 and name CA
show spheres, resi 51 and name CA
set sphere_scale, 0.0627, resi 51 and name CA
show spheres, resi 41 and name CA
set sphere_scale, 0.0626, resi 41 and name CA
show spheres, resi 116 and name CA
set sphere_scale, 0.0609, resi 116 and name CA
show spheres, resi 12 and name CA
set sphere_scale, 0.0602, resi 12 and name CA
show spheres, resi 228 and name CA
set sphere_scale, 0.0602, resi 228 and name CA
show spheres, resi 192 and name CA
set sphere_scale, 0.0602, resi 192 and name CA
show spheres, resi 120 and name CA
set sphere_scale, 0.0600, resi 120 and name CA
show spheres, resi 10 and name CA
set sphere_scale, 0.0587, resi 10 and name CA
show spheres, resi 71 and name CA
set sphere_scale, 0.0585, resi 71 and name CA
show spheres, resi 174 and name CA
set sphere_scale, 0.0557, resi 174 and name CA
show spheres, resi 159 and name CA
set sphere_scale, 0.0554, resi 159 and name CA
show spheres, resi 83 and name CA
set sphere_scale, 0.0545, resi 83 and name CA
show spheres, resi 256 and name CA
set sphere_scale, 0.0542, resi 256 and name CA
show spheres, resi 213 and name CA
set sphere_scale, 0.0539, resi 213 and name CA
show spheres, resi 68 and name CA
set sphere_scale, 0.0533, resi 68 and name CA
show spheres, resi 80 and name CA
set sphere_scale, 0.0518, resi 80 and name CA
show spheres, resi 90 and name CA
set sphere_scale, 0.0518, resi 90 and name CA
show spheres, resi 96 and name CA
set sphere_scale, 0.0509, resi 96 and name CA
show spheres, resi 130 and name CA
set sphere_scale, 0.0509, resi 130 and name CA
show spheres, resi 38 and name CA
set sphere_scale, 0.0501, resi 38 and name CA
show spheres, resi 49 and name CA
set sphere_scale, 0.0490, resi 49 and name CA
show spheres, resi 215 and name CA
set sphere_scale, 0.0490, resi 215 and name CA
show spheres, resi 15 and name CA
set sphere_scale, 0.0482, resi 15 and name CA
show spheres, resi 197 and name CA
set sphere_scale, 0.0482, resi 197 and name CA
show spheres, resi 18 and name CA
set sphere_scale, 0.0476, resi 18 and name CA
show spheres, resi 153 and name CA
set sphere_scale, 0.0464, resi 153 and name CA
show spheres, resi 260 and name CA
set sphere_scale, 0.0464, resi 260 and name CA
show spheres, resi 56 and name CA
set sphere_scale, 0.0460, resi 56 and name CA
show spheres, resi 212 and name CA
set sphere_scale, 0.0460, resi 212 and name CA
show spheres, resi 126 and name CA
set sphere_scale, 0.0459, resi 126 and name CA
show spheres, resi 70 and name CA
set sphere_scale, 0.0456, resi 70 and name CA
show spheres, resi 11 and name CA
set sphere_scale, 0.0447, resi 11 and name CA
show spheres, resi 14 and name CA
set sphere_scale, 0.0446, resi 14 and name CA
show spheres, resi 7 and name CA
set sphere_scale, 0.0430, resi 7 and name CA
show spheres, resi 243 and name CA
set sphere_scale, 0.0429, resi 243 and name CA
show spheres, resi 236 and name CA
set sphere_scale, 0.0419, resi 236 and name CA
show spheres, resi 119 and name CA
set sphere_scale, 0.0413, resi 119 and name CA
show spheres, resi 259 and name CA
set sphere_scale, 0.0413, resi 259 and name CA
show spheres, resi 154 and name CA
set sphere_scale, 0.0413, resi 154 and name CA
show spheres, resi 162 and name CA
set sphere_scale, 0.0393, resi 162 and name CA
show spheres, resi 81 and name CA
set sphere_scale, 0.0384, resi 81 and name CA
show spheres, resi 85 and name CA
set sphere_scale, 0.0384, resi 85 and name CA
show spheres, resi 142 and name CA
set sphere_scale, 0.0378, resi 142 and name CA
show spheres, resi 132 and name CA
set sphere_scale, 0.0376, resi 132 and name CA
show spheres, resi 128 and name CA
set sphere_scale, 0.0372, resi 128 and name CA
show spheres, resi 99 and name CA
set sphere_scale, 0.0357, resi 99 and name CA
show spheres, resi 237 and name CA
set sphere_scale, 0.0357, resi 237 and name CA
show spheres, resi 204 and name CA
set sphere_scale, 0.0331, resi 204 and name CA
show spheres, resi 46 and name CA
set sphere_scale, 0.0321, resi 46 and name CA
show spheres, resi 94 and name CA
set sphere_scale, 0.0304, resi 94 and name CA
show spheres, resi 115 and name CA
set sphere_scale, 0.0293, resi 115 and name CA
show spheres, resi 57 and name CA
set sphere_scale, 0.0289, resi 57 and name CA
show spheres, resi 3 and name CA
set sphere_scale, 0.0283, resi 3 and name CA
show spheres, resi 82 and name CA
set sphere_scale, 0.0279, resi 82 and name CA
show spheres, resi 176 and name CA
set sphere_scale, 0.0273, resi 176 and name CA
show spheres, resi 180 and name CA
set sphere_scale, 0.0273, resi 180 and name CA
show spheres, resi 123 and name CA
set sphere_scale, 0.0251, resi 123 and name CA
show spheres, resi 13 and name CA
set sphere_scale, 0.0241, resi 13 and name CA
show spheres, resi 59 and name CA
set sphere_scale, 0.0227, resi 59 and name CA
show spheres, resi 182 and name CA
set sphere_scale, 0.0227, resi 182 and name CA
show spheres, resi 66 and name CA
set sphere_scale, 0.0221, resi 66 and name CA
show spheres, resi 92 and name CA
set sphere_scale, 0.0221, resi 92 and name CA
show spheres, resi 172 and name CA
set sphere_scale, 0.0220, resi 172 and name CA
show spheres, resi 238 and name CA
set sphere_scale, 0.0215, resi 238 and name CA
show spheres, resi 155 and name CA
set sphere_scale, 0.0215, resi 155 and name CA
show spheres, resi 166 and name CA
set sphere_scale, 0.0211, resi 166 and name CA
show spheres, resi 114 and name CA
set sphere_scale, 0.0211, resi 114 and name CA
show spheres, resi 45 and name CA
set sphere_scale, 0.0204, resi 45 and name CA
show spheres, resi 229 and name CA
set sphere_scale, 0.0202, resi 229 and name CA
show spheres, resi 137 and name CA
set sphere_scale, 0.0176, resi 137 and name CA
show spheres, resi 152 and name CA
set sphere_scale, 0.0176, resi 152 and name CA
show spheres, resi 16 and name CA
set sphere_scale, 0.0170, resi 16 and name CA
show spheres, resi 34 and name CA
set sphere_scale, 0.0166, resi 34 and name CA
show spheres, resi 146 and name CA
set sphere_scale, 0.0162, resi 146 and name CA
show spheres, resi 242 and name CA
set sphere_scale, 0.0128, resi 242 and name CA
show spheres, resi 76 and name CA
set sphere_scale, 0.0125, resi 76 and name CA
show spheres, resi 87 and name CA
set sphere_scale, 0.0125, resi 87 and name CA
show spheres, resi 224 and name CA
set sphere_scale, 0.0120, resi 224 and name CA
show spheres, resi 88 and name CA
set sphere_scale, 0.0114, resi 88 and name CA
show spheres, resi 60 and name CA
set sphere_scale, 0.0101, resi 60 and name CA
show spheres, resi 9 and name CA
set sphere_scale, 0.0100, resi 9 and name CA
show spheres, resi 248 and name CA
set sphere_scale, 0.0073, resi 248 and name CA
show spheres, resi 27 and name CA
set sphere_scale, 0.0059, resi 27 and name CA
show spheres, resi 5 and name CA
set sphere_scale, 0.0043, resi 5 and name CA
show spheres, resi 170 and name CA
set sphere_scale, 0.0030, resi 170 and name CA
show spheres, resi 150 and name CA
set sphere_scale, 0.0028, resi 150 and name CA
show spheres, resi 28 and name CA
set sphere_scale, 0.0020, resi 28 and name CA
show spheres, resi 26 and name CA
set sphere_scale, 0.0019, resi 26 and name CA
show spheres, resi 2 and name CA
set sphere_scale, 0.0000, resi 2 and name CA
show spheres, resi 6 and name CA
set sphere_scale, 0.0000, resi 6 and name CA
show spheres, resi 17 and name CA
set sphere_scale, 0.0000, resi 17 and name CA
show spheres, resi 20 and name CA
set sphere_scale, 0.0000, resi 20 and name CA
show spheres, resi 29 and name CA
set sphere_scale, 0.0000, resi 29 and name CA
show spheres, resi 36 and name CA
set sphere_scale, 0.0000, resi 36 and name CA
show spheres, resi 43 and name CA
set sphere_scale, 0.0000, resi 43 and name CA
show spheres, resi 44 and name CA
set sphere_scale, 0.0000, resi 44 and name CA
show spheres, resi 58 and name CA
set sphere_scale, 0.0000, resi 58 and name CA
show spheres, resi 61 and name CA
set sphere_scale, 0.0000, resi 61 and name CA
show spheres, resi 62 and name CA
set sphere_scale, 0.0000, resi 62 and name CA
show spheres, resi 63 and name CA
set sphere_scale, 0.0000, resi 63 and name CA
show spheres, resi 64 and name CA
set sphere_scale, 0.0000, resi 64 and name CA
show spheres, resi 67 and name CA
set sphere_scale, 0.0000, resi 67 and name CA
show spheres, resi 72 and name CA
set sphere_scale, 0.0000, resi 72 and name CA
show spheres, resi 73 and name CA
set sphere_scale, 0.0000, resi 73 and name CA
show spheres, resi 74 and name CA
set sphere_scale, 0.0000, resi 74 and name CA
show spheres, resi 84 and name CA
set sphere_scale, 0.0000, resi 84 and name CA
show spheres, resi 91 and name CA
set sphere_scale, 0.0000, resi 91 and name CA
show spheres, resi 95 and name CA
set sphere_scale, 0.0000, resi 95 and name CA
show spheres, resi 97 and name CA
set sphere_scale, 0.0000, resi 97 and name CA
show spheres, resi 117 and name CA
set sphere_scale, 0.0000, resi 117 and name CA
show spheres, resi 118 and name CA
set sphere_scale, 0.0000, resi 118 and name CA
show spheres, resi 121 and name CA
set sphere_scale, 0.0000, resi 121 and name CA
show spheres, resi 135 and name CA
set sphere_scale, 0.0000, resi 135 and name CA
show spheres, resi 139 and name CA
set sphere_scale, 0.0000, resi 139 and name CA
show spheres, resi 147 and name CA
set sphere_scale, 0.0000, resi 147 and name CA
show spheres, resi 148 and name CA
set sphere_scale, 0.0000, resi 148 and name CA
show spheres, resi 149 and name CA
set sphere_scale, 0.0000, resi 149 and name CA
show spheres, resi 151 and name CA
set sphere_scale, 0.0000, resi 151 and name CA
show spheres, resi 156 and name CA
set sphere_scale, 0.0000, resi 156 and name CA
show spheres, resi 160 and name CA
set sphere_scale, 0.0000, resi 160 and name CA
show spheres, resi 165 and name CA
set sphere_scale, 0.0000, resi 165 and name CA
show spheres, resi 169 and name CA
set sphere_scale, 0.0000, resi 169 and name CA
show spheres, resi 171 and name CA
set sphere_scale, 0.0000, resi 171 and name CA
show spheres, resi 175 and name CA
set sphere_scale, 0.0000, resi 175 and name CA
show spheres, resi 179 and name CA
set sphere_scale, 0.0000, resi 179 and name CA
show spheres, resi 183 and name CA
set sphere_scale, 0.0000, resi 183 and name CA
show spheres, resi 187 and name CA
set sphere_scale, 0.0000, resi 187 and name CA
show spheres, resi 191 and name CA
set sphere_scale, 0.0000, resi 191 and name CA
show spheres, resi 193 and name CA
set sphere_scale, 0.0000, resi 193 and name CA
show spheres, resi 198 and name CA
set sphere_scale, 0.0000, resi 198 and name CA
show spheres, resi 199 and name CA
set sphere_scale, 0.0000, resi 199 and name CA
show spheres, resi 200 and name CA
set sphere_scale, 0.0000, resi 200 and name CA
show spheres, resi 201 and name CA
set sphere_scale, 0.0000, resi 201 and name CA
show spheres, resi 202 and name CA
set sphere_scale, 0.0000, resi 202 and name CA
show spheres, resi 203 and name CA
set sphere_scale, 0.0000, resi 203 and name CA
show spheres, resi 206 and name CA
set sphere_scale, 0.0000, resi 206 and name CA
show spheres, resi 226 and name CA
set sphere_scale, 0.0000, resi 226 and name CA
show spheres, resi 227 and name CA
set sphere_scale, 0.0000, resi 227 and name CA
show spheres, resi 234 and name CA
set sphere_scale, 0.0000, resi 234 and name CA
show spheres, resi 241 and name CA
set sphere_scale, 0.0000, resi 241 and name CA
show spheres, resi 244 and name CA
set sphere_scale, 0.0000, resi 244 and name CA
show spheres, resi 245 and name CA
set sphere_scale, 0.0000, resi 245 and name CA
show spheres, resi 253 and name CA
set sphere_scale, 0.0000, resi 253 and name CA
show spheres, resi 255 and name CA
set sphere_scale, 0.0000, resi 255 and name CA
sele All_Spheres, resi 104+190+194+208+103+188+47+102+189+207+209+196+98+106+100+210+140+219+218+262+247+254+220+235+112+217+24+164+184+127+231+195+55+101+79+50+144+222+216+185+21+173+105+122+93+233+257+124+168+211+22+23+42+261+136+113+158+221+30+53+181+138+110+258+48+19+108+167+131+186+178+52+246+134+54+32+4+25+163+232+33+177+223+65+31+141+69+111+145+230+40+205+39+109+78+240+129+214+35+251+37+157+249+125+8+239+133+225+77+143+161+86+250+252+89+75+107+51+41+116+12+228+192+120+10+71+174+159+83+256+213+68+80+90+96+130+38+49+215+15+197+18+153+260+56+212+126+70+11+14+7+243+236+119+259+154+162+81+85+142+132+128+99+237+204+46+94+115+57+3+82+176+180+123+13+59+182+66+92+172+238+155+166+114+45+229+137+152+16+34+146+242+76+87+224+88+60+9+248+27+5+170+150+28+26+2+6+17+20+29+36+43+44+58+61+62+63+64+67+72+73+74+84+91+95+97+117+118+121+135+139+147+148+149+151+156+160+165+169+171+175+179+183+187+191+193+198+199+200+201+202+203+206+226+227+234+241+244+245+253+255 and name CA
