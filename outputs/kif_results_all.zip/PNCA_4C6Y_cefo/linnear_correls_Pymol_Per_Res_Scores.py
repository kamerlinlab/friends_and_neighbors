# You can run me in several ways, perhaps the easiest way is to:
# 1. Load the PDB file of your system in PyMOL.
# 2. Type: @[FILE_NAME.py] in the command line.
# 3. Make sure the .py file is in the same directory as the pdb.
set sphere_color, red
# The lines below are suggestions for potentially nicer figures.
# You can comment them in if you want.
# bg_color white
# set cartoon_color, grey90
# set ray_opaque_background, 0
# set antialias, 2
# set ray_shadows, 0
show spheres, resi 194 and name CA
set sphere_scale, 1.0000, resi 194 and name CA
show spheres, resi 102 and name CA
set sphere_scale, 0.9606, resi 102 and name CA
show spheres, resi 104 and name CA
set sphere_scale, 0.8700, resi 104 and name CA
show spheres, resi 190 and name CA
set sphere_scale, 0.8123, resi 190 and name CA
show spheres, resi 189 and name CA
set sphere_scale, 0.7252, resi 189 and name CA
show spheres, resi 196 and name CA
set sphere_scale, 0.6783, resi 196 and name CA
show spheres, resi 103 and name CA
set sphere_scale, 0.6446, resi 103 and name CA
show spheres, resi 210 and name CA
set sphere_scale, 0.6298, resi 210 and name CA
show spheres, resi 208 and name CA
set sphere_scale, 0.6099, resi 208 and name CA
show spheres, resi 140 and name CA
set sphere_scale, 0.5825, resi 140 and name CA
show spheres, resi 98 and name CA
set sphere_scale, 0.5772, resi 98 and name CA
show spheres, resi 106 and name CA
set sphere_scale, 0.5767, resi 106 and name CA
show spheres, resi 209 and name CA
set sphere_scale, 0.5311, resi 209 and name CA
show spheres, resi 207 and name CA
set sphere_scale, 0.5288, resi 207 and name CA
show spheres, resi 47 and name CA
set sphere_scale, 0.5211, resi 47 and name CA
show spheres, resi 164 and name CA
set sphere_scale, 0.5071, resi 164 and name CA
show spheres, resi 100 and name CA
set sphere_scale, 0.5022, resi 100 and name CA
show spheres, resi 217 and name CA
set sphere_scale, 0.4856, resi 217 and name CA
show spheres, resi 218 and name CA
set sphere_scale, 0.4727, resi 218 and name CA
show spheres, resi 178 and name CA
set sphere_scale, 0.4629, resi 178 and name CA
show spheres, resi 221 and name CA
set sphere_scale, 0.4618, resi 221 and name CA
show spheres, resi 188 and name CA
set sphere_scale, 0.4523, resi 188 and name CA
show spheres, resi 101 and name CA
set sphere_scale, 0.4287, resi 101 and name CA
show spheres, resi 219 and name CA
set sphere_scale, 0.4260, resi 219 and name CA
show spheres, resi 195 and name CA
set sphere_scale, 0.4255, resi 195 and name CA
show spheres, resi 131 and name CA
set sphere_scale, 0.4240, resi 131 and name CA
show spheres, resi 220 and name CA
set sphere_scale, 0.4218, resi 220 and name CA
show spheres, resi 184 and name CA
set sphere_scale, 0.3908, resi 184 and name CA
show spheres, resi 205 and name CA
set sphere_scale, 0.3688, resi 205 and name CA
show spheres, resi 233 and name CA
set sphere_scale, 0.3584, resi 233 and name CA
show spheres, resi 127 and name CA
set sphere_scale, 0.3459, resi 127 and name CA
show spheres, resi 125 and name CA
set sphere_scale, 0.3378, resi 125 and name CA
show spheres, resi 181 and name CA
set sphere_scale, 0.3345, resi 181 and name CA
show spheres, resi 254 and name CA
set sphere_scale, 0.3176, resi 254 and name CA
show spheres, resi 234 and name CA
set sphere_scale, 0.3153, resi 234 and name CA
show spheres, resi 232 and name CA
set sphere_scale, 0.3117, resi 232 and name CA
show spheres, resi 169 and name CA
set sphere_scale, 0.3022, resi 169 and name CA
show spheres, resi 80 and name CA
set sphere_scale, 0.3000, resi 80 and name CA
show spheres, resi 46 and name CA
set sphere_scale, 0.2883, resi 46 and name CA
show spheres, resi 144 and name CA
set sphere_scale, 0.2812, resi 144 and name CA
show spheres, resi 262 and name CA
set sphere_scale, 0.2796, resi 262 and name CA
show spheres, resi 167 and name CA
set sphere_scale, 0.2772, resi 167 and name CA
show spheres, resi 112 and name CA
set sphere_scale, 0.2769, resi 112 and name CA
show spheres, resi 185 and name CA
set sphere_scale, 0.2701, resi 185 and name CA
show spheres, resi 240 and name CA
set sphere_scale, 0.2700, resi 240 and name CA
show spheres, resi 108 and name CA
set sphere_scale, 0.2597, resi 108 and name CA
show spheres, resi 23 and name CA
set sphere_scale, 0.2547, resi 23 and name CA
show spheres, resi 107 and name CA
set sphere_scale, 0.2536, resi 107 and name CA
show spheres, resi 166 and name CA
set sphere_scale, 0.2518, resi 166 and name CA
show spheres, resi 22 and name CA
set sphere_scale, 0.2496, resi 22 and name CA
show spheres, resi 258 and name CA
set sphere_scale, 0.2485, resi 258 and name CA
show spheres, resi 105 and name CA
set sphere_scale, 0.2450, resi 105 and name CA
show spheres, resi 161 and name CA
set sphere_scale, 0.2407, resi 161 and name CA
show spheres, resi 186 and name CA
set sphere_scale, 0.2372, resi 186 and name CA
show spheres, resi 110 and name CA
set sphere_scale, 0.2317, resi 110 and name CA
show spheres, resi 235 and name CA
set sphere_scale, 0.2308, resi 235 and name CA
show spheres, resi 48 and name CA
set sphere_scale, 0.2238, resi 48 and name CA
show spheres, resi 248 and name CA
set sphere_scale, 0.2235, resi 248 and name CA
show spheres, resi 247 and name CA
set sphere_scale, 0.2221, resi 247 and name CA
show spheres, resi 122 and name CA
set sphere_scale, 0.2219, resi 122 and name CA
show spheres, resi 261 and name CA
set sphere_scale, 0.2215, resi 261 and name CA
show spheres, resi 222 and name CA
set sphere_scale, 0.2167, resi 222 and name CA
show spheres, resi 173 and name CA
set sphere_scale, 0.2128, resi 173 and name CA
show spheres, resi 4 and name CA
set sphere_scale, 0.2068, resi 4 and name CA
show spheres, resi 49 and name CA
set sphere_scale, 0.2064, resi 49 and name CA
show spheres, resi 231 and name CA
set sphere_scale, 0.2038, resi 231 and name CA
show spheres, resi 134 and name CA
set sphere_scale, 0.2029, resi 134 and name CA
show spheres, resi 163 and name CA
set sphere_scale, 0.2023, resi 163 and name CA
show spheres, resi 79 and name CA
set sphere_scale, 0.1994, resi 79 and name CA
show spheres, resi 133 and name CA
set sphere_scale, 0.1983, resi 133 and name CA
show spheres, resi 216 and name CA
set sphere_scale, 0.1946, resi 216 and name CA
show spheres, resi 53 and name CA
set sphere_scale, 0.1928, resi 53 and name CA
show spheres, resi 52 and name CA
set sphere_scale, 0.1921, resi 52 and name CA
show spheres, resi 54 and name CA
set sphere_scale, 0.1895, resi 54 and name CA
show spheres, resi 99 and name CA
set sphere_scale, 0.1872, resi 99 and name CA
show spheres, resi 199 and name CA
set sphere_scale, 0.1856, resi 199 and name CA
show spheres, resi 86 and name CA
set sphere_scale, 0.1839, resi 86 and name CA
show spheres, resi 168 and name CA
set sphere_scale, 0.1812, resi 168 and name CA
show spheres, resi 41 and name CA
set sphere_scale, 0.1809, resi 41 and name CA
show spheres, resi 109 and name CA
set sphere_scale, 0.1786, resi 109 and name CA
show spheres, resi 113 and name CA
set sphere_scale, 0.1779, resi 113 and name CA
show spheres, resi 211 and name CA
set sphere_scale, 0.1701, resi 211 and name CA
show spheres, resi 136 and name CA
set sphere_scale, 0.1691, resi 136 and name CA
show spheres, resi 42 and name CA
set sphere_scale, 0.1678, resi 42 and name CA
show spheres, resi 25 and name CA
set sphere_scale, 0.1675, resi 25 and name CA
show spheres, resi 96 and name CA
set sphere_scale, 0.1646, resi 96 and name CA
show spheres, resi 116 and name CA
set sphere_scale, 0.1623, resi 116 and name CA
show spheres, resi 230 and name CA
set sphere_scale, 0.1622, resi 230 and name CA
show spheres, resi 39 and name CA
set sphere_scale, 0.1596, resi 39 and name CA
show spheres, resi 159 and name CA
set sphere_scale, 0.1591, resi 159 and name CA
show spheres, resi 257 and name CA
set sphere_scale, 0.1577, resi 257 and name CA
show spheres, resi 7 and name CA
set sphere_scale, 0.1564, resi 7 and name CA
show spheres, resi 8 and name CA
set sphere_scale, 0.1537, resi 8 and name CA
show spheres, resi 77 and name CA
set sphere_scale, 0.1524, resi 77 and name CA
show spheres, resi 51 and name CA
set sphere_scale, 0.1500, resi 51 and name CA
show spheres, resi 55 and name CA
set sphere_scale, 0.1488, resi 55 and name CA
show spheres, resi 129 and name CA
set sphere_scale, 0.1477, resi 129 and name CA
show spheres, resi 24 and name CA
set sphere_scale, 0.1441, resi 24 and name CA
show spheres, resi 124 and name CA
set sphere_scale, 0.1419, resi 124 and name CA
show spheres, resi 21 and name CA
set sphere_scale, 0.1396, resi 21 and name CA
show spheres, resi 141 and name CA
set sphere_scale, 0.1380, resi 141 and name CA
show spheres, resi 30 and name CA
set sphere_scale, 0.1329, resi 30 and name CA
show spheres, resi 143 and name CA
set sphere_scale, 0.1324, resi 143 and name CA
show spheres, resi 126 and name CA
set sphere_scale, 0.1315, resi 126 and name CA
show spheres, resi 157 and name CA
set sphere_scale, 0.1300, resi 157 and name CA
show spheres, resi 82 and name CA
set sphere_scale, 0.1290, resi 82 and name CA
show spheres, resi 56 and name CA
set sphere_scale, 0.1273, resi 56 and name CA
show spheres, resi 228 and name CA
set sphere_scale, 0.1257, resi 228 and name CA
show spheres, resi 252 and name CA
set sphere_scale, 0.1239, resi 252 and name CA
show spheres, resi 50 and name CA
set sphere_scale, 0.1216, resi 50 and name CA
show spheres, resi 93 and name CA
set sphere_scale, 0.1197, resi 93 and name CA
show spheres, resi 156 and name CA
set sphere_scale, 0.1190, resi 156 and name CA
show spheres, resi 223 and name CA
set sphere_scale, 0.1167, resi 223 and name CA
show spheres, resi 111 and name CA
set sphere_scale, 0.1157, resi 111 and name CA
show spheres, resi 138 and name CA
set sphere_scale, 0.1145, resi 138 and name CA
show spheres, resi 123 and name CA
set sphere_scale, 0.1140, resi 123 and name CA
show spheres, resi 15 and name CA
set sphere_scale, 0.1125, resi 15 and name CA
show spheres, resi 251 and name CA
set sphere_scale, 0.1118, resi 251 and name CA
show spheres, resi 145 and name CA
set sphere_scale, 0.1098, resi 145 and name CA
show spheres, resi 92 and name CA
set sphere_scale, 0.1082, resi 92 and name CA
show spheres, resi 158 and name CA
set sphere_scale, 0.1081, resi 158 and name CA
show spheres, resi 65 and name CA
set sphere_scale, 0.1073, resi 65 and name CA
show spheres, resi 237 and name CA
set sphere_scale, 0.1054, resi 237 and name CA
show spheres, resi 193 and name CA
set sphere_scale, 0.1046, resi 193 and name CA
show spheres, resi 18 and name CA
set sphere_scale, 0.1043, resi 18 and name CA
show spheres, resi 16 and name CA
set sphere_scale, 0.1037, resi 16 and name CA
show spheres, resi 78 and name CA
set sphere_scale, 0.1034, resi 78 and name CA
show spheres, resi 83 and name CA
set sphere_scale, 0.1012, resi 83 and name CA
show spheres, resi 214 and name CA
set sphere_scale, 0.0999, resi 214 and name CA
show spheres, resi 192 and name CA
set sphere_scale, 0.0992, resi 192 and name CA
show spheres, resi 32 and name CA
set sphere_scale, 0.0967, resi 32 and name CA
show spheres, resi 162 and name CA
set sphere_scale, 0.0960, resi 162 and name CA
show spheres, resi 11 and name CA
set sphere_scale, 0.0955, resi 11 and name CA
show spheres, resi 119 and name CA
set sphere_scale, 0.0911, resi 119 and name CA
show spheres, resi 250 and name CA
set sphere_scale, 0.0895, resi 250 and name CA
show spheres, resi 12 and name CA
set sphere_scale, 0.0887, resi 12 and name CA
show spheres, resi 171 and name CA
set sphere_scale, 0.0883, resi 171 and name CA
show spheres, resi 130 and name CA
set sphere_scale, 0.0834, resi 130 and name CA
show spheres, resi 154 and name CA
set sphere_scale, 0.0833, resi 154 and name CA
show spheres, resi 26 and name CA
set sphere_scale, 0.0822, resi 26 and name CA
show spheres, resi 137 and name CA
set sphere_scale, 0.0814, resi 137 and name CA
show spheres, resi 152 and name CA
set sphere_scale, 0.0814, resi 152 and name CA
show spheres, resi 177 and name CA
set sphere_scale, 0.0803, resi 177 and name CA
show spheres, resi 36 and name CA
set sphere_scale, 0.0770, resi 36 and name CA
show spheres, resi 2 and name CA
set sphere_scale, 0.0744, resi 2 and name CA
show spheres, resi 155 and name CA
set sphere_scale, 0.0738, resi 155 and name CA
show spheres, resi 121 and name CA
set sphere_scale, 0.0736, resi 121 and name CA
show spheres, resi 236 and name CA
set sphere_scale, 0.0733, resi 236 and name CA
show spheres, resi 37 and name CA
set sphere_scale, 0.0712, resi 37 and name CA
show spheres, resi 10 and name CA
set sphere_scale, 0.0703, resi 10 and name CA
show spheres, resi 90 and name CA
set sphere_scale, 0.0700, resi 90 and name CA
show spheres, resi 19 and name CA
set sphere_scale, 0.0695, resi 19 and name CA
show spheres, resi 27 and name CA
set sphere_scale, 0.0688, resi 27 and name CA
show spheres, resi 225 and name CA
set sphere_scale, 0.0681, resi 225 and name CA
show spheres, resi 182 and name CA
set sphere_scale, 0.0647, resi 182 and name CA
show spheres, resi 95 and name CA
set sphere_scale, 0.0644, resi 95 and name CA
show spheres, resi 128 and name CA
set sphere_scale, 0.0638, resi 128 and name CA
show spheres, resi 238 and name CA
set sphere_scale, 0.0618, resi 238 and name CA
show spheres, resi 85 and name CA
set sphere_scale, 0.0616, resi 85 and name CA
show spheres, resi 35 and name CA
set sphere_scale, 0.0611, resi 35 and name CA
show spheres, resi 229 and name CA
set sphere_scale, 0.0609, resi 229 and name CA
show spheres, resi 170 and name CA
set sphere_scale, 0.0603, resi 170 and name CA
show spheres, resi 71 and name CA
set sphere_scale, 0.0602, resi 71 and name CA
show spheres, resi 215 and name CA
set sphere_scale, 0.0581, resi 215 and name CA
show spheres, resi 165 and name CA
set sphere_scale, 0.0578, resi 165 and name CA
show spheres, resi 31 and name CA
set sphere_scale, 0.0578, resi 31 and name CA
show spheres, resi 68 and name CA
set sphere_scale, 0.0576, resi 68 and name CA
show spheres, resi 150 and name CA
set sphere_scale, 0.0553, resi 150 and name CA
show spheres, resi 115 and name CA
set sphere_scale, 0.0550, resi 115 and name CA
show spheres, resi 246 and name CA
set sphere_scale, 0.0550, resi 246 and name CA
show spheres, resi 38 and name CA
set sphere_scale, 0.0530, resi 38 and name CA
show spheres, resi 81 and name CA
set sphere_scale, 0.0527, resi 81 and name CA
show spheres, resi 63 and name CA
set sphere_scale, 0.0516, resi 63 and name CA
show spheres, resi 67 and name CA
set sphere_scale, 0.0516, resi 67 and name CA
show spheres, resi 213 and name CA
set sphere_scale, 0.0495, resi 213 and name CA
show spheres, resi 70 and name CA
set sphere_scale, 0.0495, resi 70 and name CA
show spheres, resi 120 and name CA
set sphere_scale, 0.0482, resi 120 and name CA
show spheres, resi 242 and name CA
set sphere_scale, 0.0480, resi 242 and name CA
show spheres, resi 57 and name CA
set sphere_scale, 0.0478, resi 57 and name CA
show spheres, resi 204 and name CA
set sphere_scale, 0.0477, resi 204 and name CA
show spheres, resi 249 and name CA
set sphere_scale, 0.0473, resi 249 and name CA
show spheres, resi 76 and name CA
set sphere_scale, 0.0470, resi 76 and name CA
show spheres, resi 87 and name CA
set sphere_scale, 0.0470, resi 87 and name CA
show spheres, resi 88 and name CA
set sphere_scale, 0.0468, resi 88 and name CA
show spheres, resi 58 and name CA
set sphere_scale, 0.0446, resi 58 and name CA
show spheres, resi 3 and name CA
set sphere_scale, 0.0441, resi 3 and name CA
show spheres, resi 14 and name CA
set sphere_scale, 0.0436, resi 14 and name CA
show spheres, resi 174 and name CA
set sphere_scale, 0.0402, resi 174 and name CA
show spheres, resi 34 and name CA
set sphere_scale, 0.0390, resi 34 and name CA
show spheres, resi 33 and name CA
set sphere_scale, 0.0381, resi 33 and name CA
show spheres, resi 239 and name CA
set sphere_scale, 0.0380, resi 239 and name CA
show spheres, resi 241 and name CA
set sphere_scale, 0.0339, resi 241 and name CA
show spheres, resi 224 and name CA
set sphere_scale, 0.0337, resi 224 and name CA
show spheres, resi 153 and name CA
set sphere_scale, 0.0337, resi 153 and name CA
show spheres, resi 259 and name CA
set sphere_scale, 0.0325, resi 259 and name CA
show spheres, resi 13 and name CA
set sphere_scale, 0.0322, resi 13 and name CA
show spheres, resi 75 and name CA
set sphere_scale, 0.0321, resi 75 and name CA
show spheres, resi 28 and name CA
set sphere_scale, 0.0317, resi 28 and name CA
show spheres, resi 45 and name CA
set sphere_scale, 0.0313, resi 45 and name CA
show spheres, resi 245 and name CA
set sphere_scale, 0.0312, resi 245 and name CA
show spheres, resi 256 and name CA
set sphere_scale, 0.0310, resi 256 and name CA
show spheres, resi 243 and name CA
set sphere_scale, 0.0309, resi 243 and name CA
show spheres, resi 197 and name CA
set sphere_scale, 0.0288, resi 197 and name CA
show spheres, resi 132 and name CA
set sphere_scale, 0.0284, resi 132 and name CA
show spheres, resi 89 and name CA
set sphere_scale, 0.0284, resi 89 and name CA
show spheres, resi 253 and name CA
set sphere_scale, 0.0263, resi 253 and name CA
show spheres, resi 60 and name CA
set sphere_scale, 0.0258, resi 60 and name CA
show spheres, resi 59 and name CA
set sphere_scale, 0.0247, resi 59 and name CA
show spheres, resi 180 and name CA
set sphere_scale, 0.0236, resi 180 and name CA
show spheres, resi 176 and name CA
set sphere_scale, 0.0225, resi 176 and name CA
show spheres, resi 172 and name CA
set sphere_scale, 0.0184, resi 172 and name CA
show spheres, resi 69 and name CA
set sphere_scale, 0.0177, resi 69 and name CA
show spheres, resi 9 and name CA
set sphere_scale, 0.0175, resi 9 and name CA
show spheres, resi 5 and name CA
set sphere_scale, 0.0166, resi 5 and name CA
show spheres, resi 135 and name CA
set sphere_scale, 0.0148, resi 135 and name CA
show spheres, resi 66 and name CA
set sphere_scale, 0.0140, resi 66 and name CA
show spheres, resi 94 and name CA
set sphere_scale, 0.0116, resi 94 and name CA
show spheres, resi 40 and name CA
set sphere_scale, 0.0102, resi 40 and name CA
show spheres, resi 62 and name CA
set sphere_scale, 0.0097, resi 62 and name CA
show spheres, resi 151 and name CA
set sphere_scale, 0.0096, resi 151 and name CA
show spheres, resi 146 and name CA
set sphere_scale, 0.0094, resi 146 and name CA
show spheres, resi 198 and name CA
set sphere_scale, 0.0080, resi 198 and name CA
show spheres, resi 72 and name CA
set sphere_scale, 0.0080, resi 72 and name CA
show spheres, resi 114 and name CA
set sphere_scale, 0.0078, resi 114 and name CA
show spheres, resi 260 and name CA
set sphere_scale, 0.0068, resi 260 and name CA
show spheres, resi 200 and name CA
set sphere_scale, 0.0017, resi 200 and name CA
show spheres, resi 142 and name CA
set sphere_scale, 0.0017, resi 142 and name CA
show spheres, resi 212 and name CA
set sphere_scale, 0.0013, resi 212 and name CA
show spheres, resi 183 and name CA
set sphere_scale, 0.0011, resi 183 and name CA
show spheres, resi 6 and name CA
set sphere_scale, 0.0000, resi 6 and name CA
show spheres, resi 17 and name CA
set sphere_scale, 0.0000, resi 17 and name CA
show spheres, resi 20 and name CA
set sphere_scale, 0.0000, resi 20 and name CA
show spheres, resi 29 and name CA
set sphere_scale, 0.0000, resi 29 and name CA
show spheres, resi 43 and name CA
set sphere_scale, 0.0000, resi 43 and name CA
show spheres, resi 44 and name CA
set sphere_scale, 0.0000, resi 44 and name CA
show spheres, resi 61 and name CA
set sphere_scale, 0.0000, resi 61 and name CA
show spheres, resi 64 and name CA
set sphere_scale, 0.0000, resi 64 and name CA
show spheres, resi 73 and name CA
set sphere_scale, 0.0000, resi 73 and name CA
show spheres, resi 74 and name CA
set sphere_scale, 0.0000, resi 74 and name CA
show spheres, resi 84 and name CA
set sphere_scale, 0.0000, resi 84 and name CA
show spheres, resi 91 and name CA
set sphere_scale, 0.0000, resi 91 and name CA
show spheres, resi 97 and name CA
set sphere_scale, 0.0000, resi 97 and name CA
show spheres, resi 117 and name CA
set sphere_scale, 0.0000, resi 117 and name CA
show spheres, resi 118 and name CA
set sphere_scale, 0.0000, resi 118 and name CA
show spheres, resi 139 and name CA
set sphere_scale, 0.0000, resi 139 and name CA
show spheres, resi 147 and name CA
set sphere_scale, 0.0000, resi 147 and name CA
show spheres, resi 148 and name CA
set sphere_scale, 0.0000, resi 148 and name CA
show spheres, resi 149 and name CA
set sphere_scale, 0.0000, resi 149 and name CA
show spheres, resi 160 and name CA
set sphere_scale, 0.0000, resi 160 and name CA
show spheres, resi 175 and name CA
set sphere_scale, 0.0000, resi 175 and name CA
show spheres, resi 179 and name CA
set sphere_scale, 0.0000, resi 179 and name CA
show spheres, resi 187 and name CA
set sphere_scale, 0.0000, resi 187 and name CA
show spheres, resi 191 and name CA
set sphere_scale, 0.0000, resi 191 and name CA
show spheres, resi 201 and name CA
set sphere_scale, 0.0000, resi 201 and name CA
show spheres, resi 202 and name CA
set sphere_scale, 0.0000, resi 202 and name CA
show spheres, resi 203 and name CA
set sphere_scale, 0.0000, resi 203 and name CA
show spheres, resi 206 and name CA
set sphere_scale, 0.0000, resi 206 and name CA
show spheres, resi 226 and name CA
set sphere_scale, 0.0000, resi 226 and name CA
show spheres, resi 227 and name CA
set sphere_scale, 0.0000, resi 227 and name CA
show spheres, resi 244 and name CA
set sphere_scale, 0.0000, resi 244 and name CA
show spheres, resi 255 and name CA
set sphere_scale, 0.0000, resi 255 and name CA
sele All_Spheres, resi 194+102+104+190+189+196+103+210+208+140+98+106+209+207+47+164+100+217+218+178+221+188+101+219+195+131+220+184+205+233+127+125+181+254+234+232+169+80+46+144+262+167+112+185+240+108+23+107+166+22+258+105+161+186+110+235+48+248+247+122+261+222+173+4+49+231+134+163+79+133+216+53+52+54+99+199+86+168+41+109+113+211+136+42+25+96+116+230+39+159+257+7+8+77+51+55+129+24+124+21+141+30+143+126+157+82+56+228+252+50+93+156+223+111+138+123+15+251+145+92+158+65+237+193+18+16+78+83+214+192+32+162+11+119+250+12+171+130+154+26+137+152+177+36+2+155+121+236+37+10+90+19+27+225+182+95+128+238+85+35+229+170+71+215+165+31+68+150+115+246+38+81+63+67+213+70+120+242+57+204+249+76+87+88+58+3+14+174+34+33+239+241+224+153+259+13+75+28+45+245+256+243+197+132+89+253+60+59+180+176+172+69+9+5+135+66+94+40+62+151+146+198+72+114+260+200+142+212+183+6+17+20+29+43+44+61+64+73+74+84+91+97+117+118+139+147+148+149+160+175+179+187+191+201+202+203+206+226+227+244+255 and name CA
