# You can run me in several ways, perhaps the easiest way is to:
# 1. Load the PDB file of your system in PyMOL.
# 2. Type: @[FILE_NAME.py] in the command line.
# 3. Make sure the .py file is in the same directory as the pdb.
set sphere_color, red
# The lines below are suggestions for potentially nicer figures.
# You can comment them in if you want.
# bg_color white
# set cartoon_color, grey90
# set ray_opaque_background, 0
# set antialias, 2
# set ray_shadows, 0
show spheres, resi 47 and name CA
set sphere_scale, 1.0000, resi 47 and name CA
show spheres, resi 194 and name CA
set sphere_scale, 0.8437, resi 194 and name CA
show spheres, resi 100 and name CA
set sphere_scale, 0.7792, resi 100 and name CA
show spheres, resi 104 and name CA
set sphere_scale, 0.7664, resi 104 and name CA
show spheres, resi 262 and name CA
set sphere_scale, 0.7273, resi 262 and name CA
show spheres, resi 208 and name CA
set sphere_scale, 0.5985, resi 208 and name CA
show spheres, resi 188 and name CA
set sphere_scale, 0.5454, resi 188 and name CA
show spheres, resi 102 and name CA
set sphere_scale, 0.5398, resi 102 and name CA
show spheres, resi 98 and name CA
set sphere_scale, 0.5252, resi 98 and name CA
show spheres, resi 106 and name CA
set sphere_scale, 0.5250, resi 106 and name CA
show spheres, resi 217 and name CA
set sphere_scale, 0.5114, resi 217 and name CA
show spheres, resi 261 and name CA
set sphere_scale, 0.4824, resi 261 and name CA
show spheres, resi 103 and name CA
set sphere_scale, 0.4462, resi 103 and name CA
show spheres, resi 164 and name CA
set sphere_scale, 0.4365, resi 164 and name CA
show spheres, resi 101 and name CA
set sphere_scale, 0.4339, resi 101 and name CA
show spheres, resi 211 and name CA
set sphere_scale, 0.4069, resi 211 and name CA
show spheres, resi 207 and name CA
set sphere_scale, 0.3920, resi 207 and name CA
show spheres, resi 209 and name CA
set sphere_scale, 0.3920, resi 209 and name CA
show spheres, resi 219 and name CA
set sphere_scale, 0.3813, resi 219 and name CA
show spheres, resi 122 and name CA
set sphere_scale, 0.3718, resi 122 and name CA
show spheres, resi 218 and name CA
set sphere_scale, 0.3672, resi 218 and name CA
show spheres, resi 113 and name CA
set sphere_scale, 0.3624, resi 113 and name CA
show spheres, resi 109 and name CA
set sphere_scale, 0.3551, resi 109 and name CA
show spheres, resi 167 and name CA
set sphere_scale, 0.3547, resi 167 and name CA
show spheres, resi 108 and name CA
set sphere_scale, 0.3496, resi 108 and name CA
show spheres, resi 161 and name CA
set sphere_scale, 0.3407, resi 161 and name CA
show spheres, resi 258 and name CA
set sphere_scale, 0.3356, resi 258 and name CA
show spheres, resi 140 and name CA
set sphere_scale, 0.3311, resi 140 and name CA
show spheres, resi 196 and name CA
set sphere_scale, 0.3301, resi 196 and name CA
show spheres, resi 233 and name CA
set sphere_scale, 0.3290, resi 233 and name CA
show spheres, resi 190 and name CA
set sphere_scale, 0.3220, resi 190 and name CA
show spheres, resi 125 and name CA
set sphere_scale, 0.3177, resi 125 and name CA
show spheres, resi 105 and name CA
set sphere_scale, 0.3167, resi 105 and name CA
show spheres, resi 221 and name CA
set sphere_scale, 0.3143, resi 221 and name CA
show spheres, resi 257 and name CA
set sphere_scale, 0.3065, resi 257 and name CA
show spheres, resi 230 and name CA
set sphere_scale, 0.3007, resi 230 and name CA
show spheres, resi 24 and name CA
set sphere_scale, 0.2831, resi 24 and name CA
show spheres, resi 80 and name CA
set sphere_scale, 0.2814, resi 80 and name CA
show spheres, resi 25 and name CA
set sphere_scale, 0.2792, resi 25 and name CA
show spheres, resi 228 and name CA
set sphere_scale, 0.2780, resi 228 and name CA
show spheres, resi 50 and name CA
set sphere_scale, 0.2773, resi 50 and name CA
show spheres, resi 232 and name CA
set sphere_scale, 0.2701, resi 232 and name CA
show spheres, resi 32 and name CA
set sphere_scale, 0.2629, resi 32 and name CA
show spheres, resi 222 and name CA
set sphere_scale, 0.2572, resi 222 and name CA
show spheres, resi 46 and name CA
set sphere_scale, 0.2560, resi 46 and name CA
show spheres, resi 181 and name CA
set sphere_scale, 0.2469, resi 181 and name CA
show spheres, resi 116 and name CA
set sphere_scale, 0.2418, resi 116 and name CA
show spheres, resi 112 and name CA
set sphere_scale, 0.2404, resi 112 and name CA
show spheres, resi 4 and name CA
set sphere_scale, 0.2376, resi 4 and name CA
show spheres, resi 195 and name CA
set sphere_scale, 0.2374, resi 195 and name CA
show spheres, resi 79 and name CA
set sphere_scale, 0.2332, resi 79 and name CA
show spheres, resi 127 and name CA
set sphere_scale, 0.2286, resi 127 and name CA
show spheres, resi 30 and name CA
set sphere_scale, 0.2280, resi 30 and name CA
show spheres, resi 22 and name CA
set sphere_scale, 0.2218, resi 22 and name CA
show spheres, resi 136 and name CA
set sphere_scale, 0.2082, resi 136 and name CA
show spheres, resi 52 and name CA
set sphere_scale, 0.2061, resi 52 and name CA
show spheres, resi 169 and name CA
set sphere_scale, 0.2029, resi 169 and name CA
show spheres, resi 225 and name CA
set sphere_scale, 0.2028, resi 225 and name CA
show spheres, resi 55 and name CA
set sphere_scale, 0.2009, resi 55 and name CA
show spheres, resi 39 and name CA
set sphere_scale, 0.2008, resi 39 and name CA
show spheres, resi 234 and name CA
set sphere_scale, 0.1960, resi 234 and name CA
show spheres, resi 58 and name CA
set sphere_scale, 0.1904, resi 58 and name CA
show spheres, resi 185 and name CA
set sphere_scale, 0.1898, resi 185 and name CA
show spheres, resi 159 and name CA
set sphere_scale, 0.1882, resi 159 and name CA
show spheres, resi 236 and name CA
set sphere_scale, 0.1858, resi 236 and name CA
show spheres, resi 77 and name CA
set sphere_scale, 0.1855, resi 77 and name CA
show spheres, resi 162 and name CA
set sphere_scale, 0.1790, resi 162 and name CA
show spheres, resi 205 and name CA
set sphere_scale, 0.1775, resi 205 and name CA
show spheres, resi 78 and name CA
set sphere_scale, 0.1740, resi 78 and name CA
show spheres, resi 99 and name CA
set sphere_scale, 0.1724, resi 99 and name CA
show spheres, resi 124 and name CA
set sphere_scale, 0.1722, resi 124 and name CA
show spheres, resi 254 and name CA
set sphere_scale, 0.1690, resi 254 and name CA
show spheres, resi 248 and name CA
set sphere_scale, 0.1686, resi 248 and name CA
show spheres, resi 53 and name CA
set sphere_scale, 0.1681, resi 53 and name CA
show spheres, resi 23 and name CA
set sphere_scale, 0.1609, resi 23 and name CA
show spheres, resi 191 and name CA
set sphere_scale, 0.1608, resi 191 and name CA
show spheres, resi 141 and name CA
set sphere_scale, 0.1600, resi 141 and name CA
show spheres, resi 247 and name CA
set sphere_scale, 0.1547, resi 247 and name CA
show spheres, resi 133 and name CA
set sphere_scale, 0.1520, resi 133 and name CA
show spheres, resi 156 and name CA
set sphere_scale, 0.1514, resi 156 and name CA
show spheres, resi 128 and name CA
set sphere_scale, 0.1502, resi 128 and name CA
show spheres, resi 56 and name CA
set sphere_scale, 0.1483, resi 56 and name CA
show spheres, resi 49 and name CA
set sphere_scale, 0.1452, resi 49 and name CA
show spheres, resi 216 and name CA
set sphere_scale, 0.1420, resi 216 and name CA
show spheres, resi 189 and name CA
set sphere_scale, 0.1390, resi 189 and name CA
show spheres, resi 259 and name CA
set sphere_scale, 0.1364, resi 259 and name CA
show spheres, resi 65 and name CA
set sphere_scale, 0.1361, resi 65 and name CA
show spheres, resi 45 and name CA
set sphere_scale, 0.1348, resi 45 and name CA
show spheres, resi 144 and name CA
set sphere_scale, 0.1323, resi 144 and name CA
show spheres, resi 177 and name CA
set sphere_scale, 0.1315, resi 177 and name CA
show spheres, resi 229 and name CA
set sphere_scale, 0.1290, resi 229 and name CA
show spheres, resi 51 and name CA
set sphere_scale, 0.1277, resi 51 and name CA
show spheres, resi 59 and name CA
set sphere_scale, 0.1275, resi 59 and name CA
show spheres, resi 111 and name CA
set sphere_scale, 0.1258, resi 111 and name CA
show spheres, resi 184 and name CA
set sphere_scale, 0.1254, resi 184 and name CA
show spheres, resi 168 and name CA
set sphere_scale, 0.1244, resi 168 and name CA
show spheres, resi 41 and name CA
set sphere_scale, 0.1239, resi 41 and name CA
show spheres, resi 231 and name CA
set sphere_scale, 0.1239, resi 231 and name CA
show spheres, resi 223 and name CA
set sphere_scale, 0.1235, resi 223 and name CA
show spheres, resi 186 and name CA
set sphere_scale, 0.1234, resi 186 and name CA
show spheres, resi 220 and name CA
set sphere_scale, 0.1234, resi 220 and name CA
show spheres, resi 193 and name CA
set sphere_scale, 0.1177, resi 193 and name CA
show spheres, resi 96 and name CA
set sphere_scale, 0.1157, resi 96 and name CA
show spheres, resi 110 and name CA
set sphere_scale, 0.1153, resi 110 and name CA
show spheres, resi 54 and name CA
set sphere_scale, 0.1152, resi 54 and name CA
show spheres, resi 199 and name CA
set sphere_scale, 0.1149, resi 199 and name CA
show spheres, resi 21 and name CA
set sphere_scale, 0.1122, resi 21 and name CA
show spheres, resi 129 and name CA
set sphere_scale, 0.1114, resi 129 and name CA
show spheres, resi 157 and name CA
set sphere_scale, 0.1102, resi 157 and name CA
show spheres, resi 131 and name CA
set sphere_scale, 0.1097, resi 131 and name CA
show spheres, resi 252 and name CA
set sphere_scale, 0.1053, resi 252 and name CA
show spheres, resi 107 and name CA
set sphere_scale, 0.1029, resi 107 and name CA
show spheres, resi 57 and name CA
set sphere_scale, 0.1013, resi 57 and name CA
show spheres, resi 174 and name CA
set sphere_scale, 0.1009, resi 174 and name CA
show spheres, resi 38 and name CA
set sphere_scale, 0.0999, resi 38 and name CA
show spheres, resi 256 and name CA
set sphere_scale, 0.0956, resi 256 and name CA
show spheres, resi 134 and name CA
set sphere_scale, 0.0946, resi 134 and name CA
show spheres, resi 173 and name CA
set sphere_scale, 0.0924, resi 173 and name CA
show spheres, resi 27 and name CA
set sphere_scale, 0.0892, resi 27 and name CA
show spheres, resi 119 and name CA
set sphere_scale, 0.0892, resi 119 and name CA
show spheres, resi 120 and name CA
set sphere_scale, 0.0884, resi 120 and name CA
show spheres, resi 178 and name CA
set sphere_scale, 0.0874, resi 178 and name CA
show spheres, resi 138 and name CA
set sphere_scale, 0.0829, resi 138 and name CA
show spheres, resi 251 and name CA
set sphere_scale, 0.0820, resi 251 and name CA
show spheres, resi 235 and name CA
set sphere_scale, 0.0819, resi 235 and name CA
show spheres, resi 187 and name CA
set sphere_scale, 0.0812, resi 187 and name CA
show spheres, resi 33 and name CA
set sphere_scale, 0.0806, resi 33 and name CA
show spheres, resi 210 and name CA
set sphere_scale, 0.0804, resi 210 and name CA
show spheres, resi 48 and name CA
set sphere_scale, 0.0787, resi 48 and name CA
show spheres, resi 8 and name CA
set sphere_scale, 0.0761, resi 8 and name CA
show spheres, resi 92 and name CA
set sphere_scale, 0.0747, resi 92 and name CA
show spheres, resi 18 and name CA
set sphere_scale, 0.0744, resi 18 and name CA
show spheres, resi 36 and name CA
set sphere_scale, 0.0744, resi 36 and name CA
show spheres, resi 60 and name CA
set sphere_scale, 0.0735, resi 60 and name CA
show spheres, resi 250 and name CA
set sphere_scale, 0.0705, resi 250 and name CA
show spheres, resi 149 and name CA
set sphere_scale, 0.0705, resi 149 and name CA
show spheres, resi 166 and name CA
set sphere_scale, 0.0689, resi 166 and name CA
show spheres, resi 82 and name CA
set sphere_scale, 0.0687, resi 82 and name CA
show spheres, resi 68 and name CA
set sphere_scale, 0.0687, resi 68 and name CA
show spheres, resi 93 and name CA
set sphere_scale, 0.0673, resi 93 and name CA
show spheres, resi 123 and name CA
set sphere_scale, 0.0656, resi 123 and name CA
show spheres, resi 10 and name CA
set sphere_scale, 0.0654, resi 10 and name CA
show spheres, resi 83 and name CA
set sphere_scale, 0.0642, resi 83 and name CA
show spheres, resi 64 and name CA
set sphere_scale, 0.0638, resi 64 and name CA
show spheres, resi 239 and name CA
set sphere_scale, 0.0633, resi 239 and name CA
show spheres, resi 11 and name CA
set sphere_scale, 0.0631, resi 11 and name CA
show spheres, resi 90 and name CA
set sphere_scale, 0.0603, resi 90 and name CA
show spheres, resi 171 and name CA
set sphere_scale, 0.0600, resi 171 and name CA
show spheres, resi 26 and name CA
set sphere_scale, 0.0591, resi 26 and name CA
show spheres, resi 7 and name CA
set sphere_scale, 0.0586, resi 7 and name CA
show spheres, resi 165 and name CA
set sphere_scale, 0.0577, resi 165 and name CA
show spheres, resi 158 and name CA
set sphere_scale, 0.0576, resi 158 and name CA
show spheres, resi 154 and name CA
set sphere_scale, 0.0573, resi 154 and name CA
show spheres, resi 19 and name CA
set sphere_scale, 0.0572, resi 19 and name CA
show spheres, resi 2 and name CA
set sphere_scale, 0.0553, resi 2 and name CA
show spheres, resi 245 and name CA
set sphere_scale, 0.0552, resi 245 and name CA
show spheres, resi 12 and name CA
set sphere_scale, 0.0545, resi 12 and name CA
show spheres, resi 142 and name CA
set sphere_scale, 0.0531, resi 142 and name CA
show spheres, resi 121 and name CA
set sphere_scale, 0.0511, resi 121 and name CA
show spheres, resi 16 and name CA
set sphere_scale, 0.0481, resi 16 and name CA
show spheres, resi 260 and name CA
set sphere_scale, 0.0469, resi 260 and name CA
show spheres, resi 163 and name CA
set sphere_scale, 0.0458, resi 163 and name CA
show spheres, resi 62 and name CA
set sphere_scale, 0.0445, resi 62 and name CA
show spheres, resi 172 and name CA
set sphere_scale, 0.0445, resi 172 and name CA
show spheres, resi 214 and name CA
set sphere_scale, 0.0441, resi 214 and name CA
show spheres, resi 14 and name CA
set sphere_scale, 0.0423, resi 14 and name CA
show spheres, resi 143 and name CA
set sphere_scale, 0.0419, resi 143 and name CA
show spheres, resi 86 and name CA
set sphere_scale, 0.0416, resi 86 and name CA
show spheres, resi 241 and name CA
set sphere_scale, 0.0378, resi 241 and name CA
show spheres, resi 69 and name CA
set sphere_scale, 0.0375, resi 69 and name CA
show spheres, resi 28 and name CA
set sphere_scale, 0.0365, resi 28 and name CA
show spheres, resi 31 and name CA
set sphere_scale, 0.0362, resi 31 and name CA
show spheres, resi 40 and name CA
set sphere_scale, 0.0353, resi 40 and name CA
show spheres, resi 5 and name CA
set sphere_scale, 0.0340, resi 5 and name CA
show spheres, resi 42 and name CA
set sphere_scale, 0.0333, resi 42 and name CA
show spheres, resi 75 and name CA
set sphere_scale, 0.0323, resi 75 and name CA
show spheres, resi 153 and name CA
set sphere_scale, 0.0316, resi 153 and name CA
show spheres, resi 197 and name CA
set sphere_scale, 0.0313, resi 197 and name CA
show spheres, resi 192 and name CA
set sphere_scale, 0.0312, resi 192 and name CA
show spheres, resi 244 and name CA
set sphere_scale, 0.0307, resi 244 and name CA
show spheres, resi 15 and name CA
set sphere_scale, 0.0306, resi 15 and name CA
show spheres, resi 180 and name CA
set sphere_scale, 0.0299, resi 180 and name CA
show spheres, resi 37 and name CA
set sphere_scale, 0.0295, resi 37 and name CA
show spheres, resi 34 and name CA
set sphere_scale, 0.0293, resi 34 and name CA
show spheres, resi 240 and name CA
set sphere_scale, 0.0286, resi 240 and name CA
show spheres, resi 204 and name CA
set sphere_scale, 0.0285, resi 204 and name CA
show spheres, resi 126 and name CA
set sphere_scale, 0.0284, resi 126 and name CA
show spheres, resi 70 and name CA
set sphere_scale, 0.0284, resi 70 and name CA
show spheres, resi 249 and name CA
set sphere_scale, 0.0278, resi 249 and name CA
show spheres, resi 146 and name CA
set sphere_scale, 0.0277, resi 146 and name CA
show spheres, resi 35 and name CA
set sphere_scale, 0.0269, resi 35 and name CA
show spheres, resi 213 and name CA
set sphere_scale, 0.0260, resi 213 and name CA
show spheres, resi 237 and name CA
set sphere_scale, 0.0250, resi 237 and name CA
show spheres, resi 253 and name CA
set sphere_scale, 0.0246, resi 253 and name CA
show spheres, resi 115 and name CA
set sphere_scale, 0.0244, resi 115 and name CA
show spheres, resi 13 and name CA
set sphere_scale, 0.0241, resi 13 and name CA
show spheres, resi 176 and name CA
set sphere_scale, 0.0214, resi 176 and name CA
show spheres, resi 89 and name CA
set sphere_scale, 0.0200, resi 89 and name CA
show spheres, resi 94 and name CA
set sphere_scale, 0.0197, resi 94 and name CA
show spheres, resi 95 and name CA
set sphere_scale, 0.0193, resi 95 and name CA
show spheres, resi 88 and name CA
set sphere_scale, 0.0180, resi 88 and name CA
show spheres, resi 215 and name CA
set sphere_scale, 0.0178, resi 215 and name CA
show spheres, resi 182 and name CA
set sphere_scale, 0.0173, resi 182 and name CA
show spheres, resi 242 and name CA
set sphere_scale, 0.0164, resi 242 and name CA
show spheres, resi 63 and name CA
set sphere_scale, 0.0158, resi 63 and name CA
show spheres, resi 67 and name CA
set sphere_scale, 0.0158, resi 67 and name CA
show spheres, resi 243 and name CA
set sphere_scale, 0.0137, resi 243 and name CA
show spheres, resi 71 and name CA
set sphere_scale, 0.0135, resi 71 and name CA
show spheres, resi 246 and name CA
set sphere_scale, 0.0126, resi 246 and name CA
show spheres, resi 81 and name CA
set sphere_scale, 0.0119, resi 81 and name CA
show spheres, resi 85 and name CA
set sphere_scale, 0.0119, resi 85 and name CA
show spheres, resi 151 and name CA
set sphere_scale, 0.0107, resi 151 and name CA
show spheres, resi 132 and name CA
set sphere_scale, 0.0099, resi 132 and name CA
show spheres, resi 170 and name CA
set sphere_scale, 0.0093, resi 170 and name CA
show spheres, resi 183 and name CA
set sphere_scale, 0.0085, resi 183 and name CA
show spheres, resi 137 and name CA
set sphere_scale, 0.0077, resi 137 and name CA
show spheres, resi 152 and name CA
set sphere_scale, 0.0077, resi 152 and name CA
show spheres, resi 72 and name CA
set sphere_scale, 0.0066, resi 72 and name CA
show spheres, resi 130 and name CA
set sphere_scale, 0.0059, resi 130 and name CA
show spheres, resi 135 and name CA
set sphere_scale, 0.0054, resi 135 and name CA
show spheres, resi 3 and name CA
set sphere_scale, 0.0039, resi 3 and name CA
show spheres, resi 150 and name CA
set sphere_scale, 0.0036, resi 150 and name CA
show spheres, resi 9 and name CA
set sphere_scale, 0.0027, resi 9 and name CA
show spheres, resi 145 and name CA
set sphere_scale, 0.0022, resi 145 and name CA
show spheres, resi 238 and name CA
set sphere_scale, 0.0019, resi 238 and name CA
show spheres, resi 198 and name CA
set sphere_scale, 0.0016, resi 198 and name CA
show spheres, resi 155 and name CA
set sphere_scale, 0.0013, resi 155 and name CA
show spheres, resi 76 and name CA
set sphere_scale, 0.0012, resi 76 and name CA
show spheres, resi 87 and name CA
set sphere_scale, 0.0012, resi 87 and name CA
show spheres, resi 200 and name CA
set sphere_scale, 0.0006, resi 200 and name CA
show spheres, resi 6 and name CA
set sphere_scale, 0.0000, resi 6 and name CA
show spheres, resi 17 and name CA
set sphere_scale, 0.0000, resi 17 and name CA
show spheres, resi 20 and name CA
set sphere_scale, 0.0000, resi 20 and name CA
show spheres, resi 29 and name CA
set sphere_scale, 0.0000, resi 29 and name CA
show spheres, resi 43 and name CA
set sphere_scale, 0.0000, resi 43 and name CA
show spheres, resi 44 and name CA
set sphere_scale, 0.0000, resi 44 and name CA
show spheres, resi 61 and name CA
set sphere_scale, 0.0000, resi 61 and name CA
show spheres, resi 66 and name CA
set sphere_scale, 0.0000, resi 66 and name CA
show spheres, resi 73 and name CA
set sphere_scale, 0.0000, resi 73 and name CA
show spheres, resi 74 and name CA
set sphere_scale, 0.0000, resi 74 and name CA
show spheres, resi 84 and name CA
set sphere_scale, 0.0000, resi 84 and name CA
show spheres, resi 91 and name CA
set sphere_scale, 0.0000, resi 91 and name CA
show spheres, resi 97 and name CA
set sphere_scale, 0.0000, resi 97 and name CA
show spheres, resi 114 and name CA
set sphere_scale, 0.0000, resi 114 and name CA
show spheres, resi 117 and name CA
set sphere_scale, 0.0000, resi 117 and name CA
show spheres, resi 118 and name CA
set sphere_scale, 0.0000, resi 118 and name CA
show spheres, resi 139 and name CA
set sphere_scale, 0.0000, resi 139 and name CA
show spheres, resi 147 and name CA
set sphere_scale, 0.0000, resi 147 and name CA
show spheres, resi 148 and name CA
set sphere_scale, 0.0000, resi 148 and name CA
show spheres, resi 160 and name CA
set sphere_scale, 0.0000, resi 160 and name CA
show spheres, resi 175 and name CA
set sphere_scale, 0.0000, resi 175 and name CA
show spheres, resi 179 and name CA
set sphere_scale, 0.0000, resi 179 and name CA
show spheres, resi 201 and name CA
set sphere_scale, 0.0000, resi 201 and name CA
show spheres, resi 202 and name CA
set sphere_scale, 0.0000, resi 202 and name CA
show spheres, resi 203 and name CA
set sphere_scale, 0.0000, resi 203 and name CA
show spheres, resi 206 and name CA
set sphere_scale, 0.0000, resi 206 and name CA
show spheres, resi 212 and name CA
set sphere_scale, 0.0000, resi 212 and name CA
show spheres, resi 224 and name CA
set sphere_scale, 0.0000, resi 224 and name CA
show spheres, resi 226 and name CA
set sphere_scale, 0.0000, resi 226 and name CA
show spheres, resi 227 and name CA
set sphere_scale, 0.0000, resi 227 and name CA
show spheres, resi 255 and name CA
set sphere_scale, 0.0000, resi 255 and name CA
sele All_Spheres, resi 47+194+100+104+262+208+188+102+98+106+217+261+103+164+101+211+207+209+219+122+218+113+109+167+108+161+258+140+196+233+190+125+105+221+257+230+24+80+25+228+50+232+32+222+46+181+116+112+4+195+79+127+30+22+136+52+169+225+55+39+234+58+185+159+236+77+162+205+78+99+124+254+248+53+23+191+141+247+133+156+128+56+49+216+189+259+65+45+144+177+229+51+59+111+184+168+41+231+223+186+220+193+96+110+54+199+21+129+157+131+252+107+57+174+38+256+134+173+27+119+120+178+138+251+235+187+33+210+48+8+92+18+36+60+250+149+166+82+68+93+123+10+83+64+239+11+90+171+26+7+165+158+154+19+2+245+12+142+121+16+260+163+62+172+214+14+143+86+241+69+28+31+40+5+42+75+153+197+192+244+15+180+37+34+240+204+126+70+249+146+35+213+237+253+115+13+176+89+94+95+88+215+182+242+63+67+243+71+246+81+85+151+132+170+183+137+152+72+130+135+3+150+9+145+238+198+155+76+87+200+6+17+20+29+43+44+61+66+73+74+84+91+97+114+117+118+139+147+148+160+175+179+201+202+203+206+212+224+226+227+255 and name CA
